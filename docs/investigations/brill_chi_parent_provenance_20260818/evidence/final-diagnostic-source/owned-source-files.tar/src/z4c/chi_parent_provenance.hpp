//========================================================================================
//! \file chi_parent_provenance.hpp
//! \brief Default-off, state-preserving provenance audit for invalid coarse Z4c chi.

#ifndef Z4C_CHI_PARENT_PROVENANCE_HPP_
#define Z4C_CHI_PARENT_PROVENANCE_HPP_

#include <cstddef>
#include <string>

#include "athena.hpp"

class MeshBlockPack;
class MeshBoundaryValuesCC;
class ParameterInput;

namespace z4c {

enum class ChiProvenanceCheckpoint : int {
  s0_after_rk = 0,
  s1_after_restriction = 1,
  s2_after_receive = 2,
  s3_after_boundary = 3,
  s4_before_parent_gate = 4,
};

enum class ChiWriterProvenance : int {
  local_restriction_centered = 0,
  local_restriction_radial_edge = 1,
  local_restriction_z_edge = 2,
  local_restriction_corner = 3,
  same_level_owner_receive = 4,
  coarser_neighbor_receive = 5,
  axis_boundary_fill = 6,
  outer_physical_boundary_fill = 7,
  preexisting_unchanged_cache = 8,
  unknown = 9,
};

const char *ChiWriterProvenanceName(ChiWriterProvenance writer);

struct ChiParentProvenanceConfig {
  bool enabled = false;
  Real start_time = 0.0;
  std::string output_basename = "chi_parent_provenance";
};

ChiParentProvenanceConfig ReadChiParentProvenanceConfig(ParameterInput *pin);

class ChiParentProvenanceRuntime {
 public:
  struct HostSnapshot;

  ChiParentProvenanceRuntime(MeshBlockPack *pack,
                             const ChiParentProvenanceConfig &config);
  ~ChiParentProvenanceRuntime();

  void RecordCheckpoint(ChiProvenanceCheckpoint checkpoint, int stage,
                        MeshBoundaryValuesCC *boundary);
  void AnalyzeBoundaryFailure(MeshBoundaryValuesCC *boundary,
                              unsigned long long invalid_parent_stencils,
                              unsigned long long first_rejected_key);
  void RecordShadowAMRRequests(std::size_t next_event,
                               const std::string &next_event_time_hex,
                               const std::string &tree_checksum);
  void RecordReplayAlignment(std::size_t event,
                             const std::string &authority_time_hex,
                             const std::string &actual_time_hex,
                             double signed_difference, long long ulp_difference,
                             bool preceding_timestep_clipped);

 private:
  MeshBlockPack *pack_ = nullptr;
  ChiParentProvenanceConfig config_;
  std::string output_root_;
  int cycle_ = -1;
  int stage_ = -1;
  HostSnapshot *fine_s0_ = nullptr;
  HostSnapshot *coarse_s1_ = nullptr;
  HostSnapshot *coarse_s2_ = nullptr;
  HostSnapshot *coarse_s3_ = nullptr;
};

}  // namespace z4c

#endif  // Z4C_CHI_PARENT_PROVENANCE_HPP_
