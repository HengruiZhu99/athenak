//========================================================================================
//! \file chi_parent_provenance.cpp
//! \brief Default-off, state-preserving provenance audit for invalid coarse Z4c chi.

#include "z4c/chi_parent_provenance.hpp"

#include <sys/stat.h>

#include <algorithm>
#include <array>
#include <cctype>
#include <cstdint>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

#include "athena.hpp"
#include "bvals/bvals.hpp"
#include "globals.hpp"
#include "mesh/amr_history_format.hpp"
#include "mesh/mesh.hpp"
#include "mesh/mesh_refinement.hpp"
#include "parameter_input.hpp"
#include "z4c/z4c.hpp"
#include "z4c/z4c_amr.hpp"

namespace z4c {
namespace {

[[noreturn]] void DiagnosticFatal(const std::string &message) {
  std::cerr << "### FATAL ERROR: chi parent provenance diagnostic: " << message
            << std::endl;
  std::exit(EXIT_FAILURE);
}

bool SafeBasename(const std::string &value) {
  if (value.empty() || value == "." || value == ".." || value.front() == '.') {
    return false;
  }
  return std::all_of(value.begin(), value.end(), [](const unsigned char c) {
    return std::isalnum(c) != 0 || c == '_' || c == '-' || c == '.';
  });
}

bool InvalidChi(const Real value) {
  return !std::isfinite(value) || !(value > 0.0);
}

const char *Classification(const Real value) {
  if (std::isnan(value)) return "NaN";
  if (std::isinf(value)) return std::signbit(value) ? "-Inf" : "+Inf";
  if (value == 0.0) return "zero";
  if (value < 0.0) return "negative";
  return "finite_positive";
}

const char *CheckpointName(const ChiProvenanceCheckpoint checkpoint) {
  switch (checkpoint) {
    case ChiProvenanceCheckpoint::s0_after_rk: return "S0_AFTER_EXP_RK_UPDATE";
    case ChiProvenanceCheckpoint::s1_after_restriction:
      return "S1_AFTER_RESTRICT_U";
    case ChiProvenanceCheckpoint::s2_after_receive: return "S2_AFTER_RECV_U";
    case ChiProvenanceCheckpoint::s3_after_boundary:
      return "S3_AFTER_PHYSICAL_AXIS_BC";
    case ChiProvenanceCheckpoint::s4_before_parent_gate:
      return "S4_BEFORE_PARENT_STENCIL_GATE";
  }
  return "UNKNOWN";
}

std::string TreeChecksum(const Mesh *mesh) {
  std::vector<amr_history::Location> leaves;
  leaves.reserve(mesh->nmb_total);
  for (int gid = 0; gid < mesh->nmb_total; ++gid) {
    const auto &loc = mesh->lloc_eachmb[gid];
    leaves.push_back({loc.level, loc.lx1, loc.lx2, loc.lx3});
  }
  std::sort(leaves.begin(), leaves.end());
  return amr_history::TreeChecksum(leaves);
}

struct CellIndex {
  int m = 0;
  int k = 0;
  int j = 0;
  int i = 0;
  bool operator<(const CellIndex &other) const {
    return std::tie(m, k, j, i) < std::tie(other.m, other.k, other.j, other.i);
  }
};

struct MinimumSummary {
  Real minimum = std::numeric_limits<Real>::infinity();
  CellIndex cell;
  std::uint64_t count = 0;
  std::uint64_t nonpositive = 0;
  std::uint64_t nonfinite = 0;
};

bool Inside(const MeshBufferIndcs &range, const CellIndex &cell) {
  return cell.i >= range.bis && cell.i <= range.bie &&
         cell.j >= range.bjs && cell.j <= range.bje &&
         cell.k >= range.bks && cell.k <= range.bke;
}

std::set<CellIndex> ConsumedCoarseCells(MeshBlockPack *pack,
                                        MeshBoundaryValuesCC *boundary) {
  std::set<CellIndex> cells;
  const auto &indcs = pack->pmesh->mb_indcs;
  const int stencil = pack->pz4c->opt.fd_stencil;
  const int lower = stencil / 2;
  const int nk = indcs.nx3 == 1 ? 1 : stencil + 1;
  auto &neighbors = pack->pmb->nghbr;
  auto &levels = pack->pmb->mb_lev;
  for (int m = 0; m < pack->nmb_thispack; ++m) {
    for (int n = 0; n < pack->pmb->nnghbr; ++n) {
      if (neighbors.h_view(m, n).gid < 0 ||
          neighbors.h_view(m, n).lev >= levels.h_view(m)) {
        continue;
      }
      const auto &range = boundary->recvbuf[n].iprol[0];
      for (int k = range.bks; k <= range.bke; ++k) {
        for (int j = range.bjs; j <= range.bje; ++j) {
          for (int i = range.bis; i <= range.bie; ++i) {
            for (int kk = 0; kk < nk; ++kk) {
              const int ck = indcs.nx3 == 1 ? k : k - lower + kk;
              for (int jj = 0; jj <= stencil; ++jj) {
                for (int ii = 0; ii <= stencil; ++ii) {
                  cells.insert({m, ck, j - lower + jj, i - lower + ii});
                }
              }
            }
          }
        }
      }
    }
  }
  return cells;
}

std::string Join(const std::vector<Real> &values) {
  std::ostringstream output;
  output << std::setprecision(17);
  for (std::size_t index = 0; index < values.size(); ++index) {
    if (index != 0) output << ';';
    output << values[index];
  }
  return output.str();
}

std::string JsonReal(const Real value) {
  if (!std::isfinite(value)) return "null";
  std::ostringstream output;
  output << std::setprecision(17) << value;
  return output.str();
}

}  // namespace

struct ChiParentProvenanceRuntime::HostSnapshot {
  int nmb = 0;
  int n3 = 0;
  int n2 = 0;
  int n1 = 0;
  std::vector<Real> values;

  Real at(const CellIndex &cell) const {
    if (cell.m < 0 || cell.m >= nmb || cell.k < 0 || cell.k >= n3 ||
        cell.j < 0 || cell.j >= n2 || cell.i < 0 || cell.i >= n1) {
      return std::numeric_limits<Real>::quiet_NaN();
    }
    const std::size_t index = static_cast<std::size_t>(cell.i) +
        static_cast<std::size_t>(n1) *
            (static_cast<std::size_t>(cell.j) +
             static_cast<std::size_t>(n2) *
                 (static_cast<std::size_t>(cell.k) +
                  static_cast<std::size_t>(n3) * cell.m));
    return values[index];
  }
};

const char *ChiWriterProvenanceName(const ChiWriterProvenance writer) {
  switch (writer) {
    case ChiWriterProvenance::local_restriction_centered:
      return "LOCAL_RESTRICTION_CENTERED";
    case ChiWriterProvenance::local_restriction_radial_edge:
      return "LOCAL_RESTRICTION_RADIAL_EDGE";
    case ChiWriterProvenance::local_restriction_z_edge:
      return "LOCAL_RESTRICTION_Z_EDGE";
    case ChiWriterProvenance::local_restriction_corner:
      return "LOCAL_RESTRICTION_CORNER";
    case ChiWriterProvenance::same_level_owner_receive:
      return "SAME_LEVEL_OWNER_RECEIVE";
    case ChiWriterProvenance::coarser_neighbor_receive:
      return "COARSER_NEIGHBOR_RECEIVE";
    case ChiWriterProvenance::axis_boundary_fill: return "AXIS_BOUNDARY_FILL";
    case ChiWriterProvenance::outer_physical_boundary_fill:
      return "OUTER_PHYSICAL_BOUNDARY_FILL";
    case ChiWriterProvenance::preexisting_unchanged_cache:
      return "PREEXISTING_UNCHANGED_CACHE";
    case ChiWriterProvenance::unknown: return "UNKNOWN";
  }
  return "UNKNOWN";
}

ChiParentProvenanceConfig ReadChiParentProvenanceConfig(ParameterInput *pin) {
  ChiParentProvenanceConfig config;
  config.enabled =
      pin->GetOrAddBoolean("z4c", "chi_parent_provenance_diagnostic", false);
  config.start_time =
      pin->GetOrAddReal("z4c", "chi_parent_provenance_start_time", 0.0);
  config.output_basename = pin->GetOrAddString(
      "z4c", "chi_parent_provenance_output", "chi_parent_provenance");
  // Restart files produced by the uninstrumented source do not contain the new
  // keys, and Athena's command-line layer only overrides pre-existing keys.
  // Exact environment overrides therefore provide the bounded diagnostic seam
  // without rewriting an authenticated restart. They are ignored unless set.
  if (const char *enabled = std::getenv("ATHENA_CHI_PARENT_PROVENANCE_DIAGNOSTIC")) {
    if (std::strcmp(enabled, "1") != 0) {
      DiagnosticFatal("ATHENA_CHI_PARENT_PROVENANCE_DIAGNOSTIC must equal 1");
    }
    config.enabled = true;
  }
  if (const char *start = std::getenv("ATHENA_CHI_PARENT_PROVENANCE_START_TIME")) {
    char *end = nullptr;
    const double parsed = std::strtod(start, &end);
    if (end == start || *end != '\0' || !std::isfinite(parsed) || parsed < 0.0) {
      DiagnosticFatal("ATHENA_CHI_PARENT_PROVENANCE_START_TIME is invalid");
    }
    config.start_time = parsed;
  }
  if (const char *output = std::getenv("ATHENA_CHI_PARENT_PROVENANCE_OUTPUT")) {
    config.output_basename = output;
  }
  if (config.enabled && !SafeBasename(config.output_basename)) {
    DiagnosticFatal("output basename is not a safe relative path");
  }
  return config;
}

namespace {

ChiParentProvenanceRuntime::HostSnapshot CaptureChi(
    MeshBlockPack *pack, const DvceArray5D<Real> &source,
    const std::string &label) {
  ChiParentProvenanceRuntime::HostSnapshot result;
  const int nmb = pack->nmb_thispack;
  result.nmb = nmb;
  result.n3 = source.extent_int(2);
  result.n2 = source.extent_int(3);
  result.n1 = source.extent_int(4);
  // Fixing the variable index directly creates a LayoutStride subview, for
  // which Kokkos has no portable Cuda-to-Host deep-copy mechanism.  Pack only
  // chi into a contiguous device view first; this also avoids copying the other
  // 24 evolved variables at every diagnostic checkpoint.
  DvceArray4D<Real> packed(label, result.nmb, result.n3, result.n2, result.n1);
  par_for(label + "_kernel", DevExeSpace(), 0, result.nmb - 1,
          0, result.n3 - 1, 0, result.n2 - 1, 0, result.n1 - 1,
          KOKKOS_LAMBDA(const int m, const int k, const int j, const int i) {
    packed(m, k, j, i) = source(m, Z4c::I_Z4C_CHI, k, j, i);
  });
  auto host = Kokkos::create_mirror_view_and_copy(HostMemSpace(), packed);
  result.values.resize(static_cast<std::size_t>(result.nmb) * result.n3 *
                       result.n2 * result.n1);
  for (int m = 0; m < result.nmb; ++m) {
    for (int k = 0; k < result.n3; ++k) {
      for (int j = 0; j < result.n2; ++j) {
        for (int i = 0; i < result.n1; ++i) {
          const CellIndex cell{m, k, j, i};
          const std::size_t index = static_cast<std::size_t>(i) +
              static_cast<std::size_t>(result.n1) *
                  (static_cast<std::size_t>(j) +
                   static_cast<std::size_t>(result.n2) *
                       (static_cast<std::size_t>(k) +
                        static_cast<std::size_t>(result.n3) * m));
          result.values[index] = host(m, k, j, i);
        }
      }
    }
  }
  return result;
}

ChiParentProvenanceRuntime::HostSnapshot CaptureFineChi(MeshBlockPack *pack) {
  return CaptureChi(pack, pack->pz4c->u0, "chi_parent_provenance_fine_pack");
}

ChiParentProvenanceRuntime::HostSnapshot CaptureCoarseChi(MeshBlockPack *pack) {
  return CaptureChi(pack, pack->pz4c->coarse_u0,
                    "chi_parent_provenance_coarse_pack");
}

MinimumSummary ActiveFineMinimum(MeshBlockPack *pack,
                                 const ChiParentProvenanceRuntime::HostSnapshot &state) {
  MinimumSummary result;
  const auto &indcs = pack->pmesh->mb_indcs;
  for (int m = 0; m < state.nmb; ++m) {
    for (int k = indcs.ks; k <= indcs.ke; ++k) {
      for (int j = indcs.js; j <= indcs.je; ++j) {
        for (int i = indcs.is; i <= indcs.ie; ++i) {
          const CellIndex cell{m, k, j, i};
          const Real value = state.at(cell);
          ++result.count;
          if (!std::isfinite(value)) ++result.nonfinite;
          else if (!(value > 0.0)) ++result.nonpositive;
          if (std::isfinite(value) && value < result.minimum) {
            result.minimum = value;
            result.cell = cell;
          }
        }
      }
    }
  }
  return result;
}

MinimumSummary ConsumedCoarseMinimum(
    const std::set<CellIndex> &cells,
    const ChiParentProvenanceRuntime::HostSnapshot &state) {
  MinimumSummary result;
  for (const CellIndex &cell : cells) {
    const Real value = state.at(cell);
    ++result.count;
    if (!std::isfinite(value)) ++result.nonfinite;
    else if (!(value > 0.0)) ++result.nonpositive;
    if (std::isfinite(value) && value < result.minimum) {
      result.minimum = value;
      result.cell = cell;
    }
  }
  return result;
}

std::pair<Real, Real> FineCoordinates(MeshBlockPack *pack,
                                      const CellIndex &cell) {
  const auto &indcs = pack->pmesh->mb_indcs;
  const auto &size = pack->pmb->mb_size.h_view(cell.m);
  return {size.x1min + (cell.i - indcs.is + 0.5) * size.dx1,
          size.x2min + (cell.j - indcs.js + 0.5) * size.dx2};
}

std::pair<Real, Real> CoarseCoordinates(MeshBlockPack *pack,
                                        const CellIndex &cell) {
  const auto &indcs = pack->pmesh->mb_indcs;
  const auto &size = pack->pmb->mb_size.h_view(cell.m);
  return {size.x1min + (cell.i - indcs.cis + 0.5) * 2.0 * size.dx1,
          size.x2min + (cell.j - indcs.cjs + 0.5) * 2.0 * size.dx2};
}

bool SameBits(const Real left, const Real right) {
  return std::memcmp(&left, &right, sizeof(Real)) == 0;
}

struct WriterInfo {
  ChiWriterProvenance writer = ChiWriterProvenance::unknown;
  std::string first_phase = "UNKNOWN";
  int owner_gid = -1;
  int owner_i = -1;
  int owner_j = -1;
  int owner_k = -1;
  std::string owner_storage = "UNKNOWN";
};

ChiWriterProvenance LocalRestrictionClass(MeshBlockPack *pack,
                                          const CellIndex &cell) {
  const auto &indcs = pack->pmesh->mb_indcs;
  const int finei = 2 * cell.i - indcs.cis;
  const int finej = 2 * cell.j - indcs.cjs;
  const int outer_i = indcs.nx1 + 2 * indcs.ng - 2;
  const int outer_j = indcs.nx2 + 2 * indcs.ng - 2;
  const bool radial = finei == 0 || finei == indcs.ng ||
      finei == indcs.ng + indcs.nx1 - 2 || finei == outer_i;
  const bool zedge = finej == 0 || finej == indcs.ng ||
      finej == indcs.ng + indcs.nx2 - 2 || finej == outer_j;
  if (radial && zedge) return ChiWriterProvenance::local_restriction_corner;
  if (radial) return ChiWriterProvenance::local_restriction_radial_edge;
  if (zedge) return ChiWriterProvenance::local_restriction_z_edge;
  return ChiWriterProvenance::local_restriction_centered;
}

bool InActiveCoarse(const RegionIndcs &indcs, const CellIndex &cell) {
  return cell.i >= indcs.cis && cell.i <= indcs.cie &&
         cell.j >= indcs.cjs && cell.j <= indcs.cje &&
         cell.k >= indcs.cks && cell.k <= indcs.cke;
}

WriterInfo IdentifyWriter(
    MeshBlockPack *pack, MeshBoundaryValuesCC *boundary, const CellIndex &cell,
    const ChiParentProvenanceRuntime::HostSnapshot &s1,
    const ChiParentProvenanceRuntime::HostSnapshot &s2,
    const ChiParentProvenanceRuntime::HostSnapshot &s3, const Real current) {
  WriterInfo result;
  const auto &indcs = pack->pmesh->mb_indcs;
  const int gid = pack->pmb->mb_gid.h_view(cell.m);
  const int level = pack->pmb->mb_lev.h_view(cell.m);
  const Real v1 = s1.at(cell);
  const Real v2 = s2.at(cell);
  const Real v3 = s3.at(cell);

  int receive_slot = -1;
  ChiWriterProvenance receive_writer = ChiWriterProvenance::unknown;
  for (int n = 0; n < pack->pmb->nnghbr; ++n) {
    const auto &neighbor = pack->pmb->nghbr.h_view(cell.m, n);
    if (neighbor.gid < 0) continue;
    if (neighbor.lev < level && Inside(boundary->recvbuf[n].icoar[0], cell)) {
      if (receive_slot >= 0 && receive_slot != n) {
        receive_writer = ChiWriterProvenance::unknown;
        receive_slot = -2;
        break;
      }
      receive_slot = n;
      receive_writer = ChiWriterProvenance::coarser_neighbor_receive;
    } else if (neighbor.lev == level &&
               Inside(boundary->recvbuf[n].isame_z4c, cell)) {
      if (receive_slot >= 0 && receive_slot != n) {
        receive_writer = ChiWriterProvenance::unknown;
        receive_slot = -2;
        break;
      }
      receive_slot = n;
      receive_writer = ChiWriterProvenance::same_level_owner_receive;
    }
  }

  const auto &bcs = pack->pmb->mb_bcs;
  const bool axis_cell = cell.i < indcs.cis &&
      bcs.h_view(cell.m, BoundaryFace::inner_x1) == BoundaryFlag::axis;
  const bool outer_cell =
      (cell.i < indcs.cis &&
       bcs.h_view(cell.m, BoundaryFace::inner_x1) != BoundaryFlag::block &&
       bcs.h_view(cell.m, BoundaryFace::inner_x1) != BoundaryFlag::axis) ||
      (cell.i > indcs.cie &&
       bcs.h_view(cell.m, BoundaryFace::outer_x1) != BoundaryFlag::block) ||
      (cell.j < indcs.cjs &&
       bcs.h_view(cell.m, BoundaryFace::inner_x2) != BoundaryFlag::block) ||
      (cell.j > indcs.cje &&
       bcs.h_view(cell.m, BoundaryFace::outer_x2) != BoundaryFlag::block);

  if (InActiveCoarse(indcs, cell) && InvalidChi(v1)) {
    result.writer = LocalRestrictionClass(pack, cell);
    result.first_phase = "S1";
    result.owner_gid = gid;
    result.owner_i = cell.i;
    result.owner_j = cell.j;
    result.owner_k = cell.k;
    result.owner_storage = "coarse_u0_active";
  } else if (receive_slot >= 0 && InvalidChi(v2) &&
             (!InvalidChi(v1) || !SameBits(v1, v2))) {
    result.writer = receive_writer;
    result.first_phase = "S2";
    const auto &neighbor = pack->pmb->nghbr.h_view(cell.m, receive_slot);
    result.owner_gid = neighbor.gid;
    result.owner_storage = receive_writer ==
            ChiWriterProvenance::same_level_owner_receive
        ? "owner_coarse_u0"
        : "owner_u0";
  } else if (axis_cell && InvalidChi(v3) &&
             (!InvalidChi(v2) || !SameBits(v2, v3))) {
    result.writer = ChiWriterProvenance::axis_boundary_fill;
    result.first_phase = "S3";
    result.owner_gid = gid;
    result.owner_storage = "coarse_u0_axis_ghost";
  } else if (outer_cell && InvalidChi(v3) &&
             (!InvalidChi(v2) || !SameBits(v2, v3))) {
    result.writer = ChiWriterProvenance::outer_physical_boundary_fill;
    result.first_phase = "S3";
    result.owner_gid = gid;
    result.owner_storage = "coarse_u0_physical_ghost";
  } else if (!InvalidChi(v3) && InvalidChi(current)) {
    result.writer = ChiWriterProvenance::unknown;
    result.first_phase = "S4";
  } else {
    result.writer = ChiWriterProvenance::preexisting_unchanged_cache;
    result.first_phase = "PREEXISTING";
  }
  return result;
}

struct RestrictionDiagnostic {
  bool available = false;
  bool all_fine_positive = false;
  Real fine_min = std::numeric_limits<Real>::infinity();
  Real fine_max = -std::numeric_limits<Real>::infinity();
  Real high = std::numeric_limits<Real>::quiet_NaN();
  Real average = std::numeric_limits<Real>::quiet_NaN();
  Real log_candidate = std::numeric_limits<Real>::quiet_NaN();
  Real parity_centered = std::numeric_limits<Real>::quiet_NaN();
  std::vector<Real> fine_values;
  std::vector<Real> weights;
};

RestrictionDiagnostic RestrictionCandidates(
    MeshBlockPack *pack, const CellIndex &cell,
    const ChiParentProvenanceRuntime::HostSnapshot &fine) {
  RestrictionDiagnostic result;
  const auto &indcs = pack->pmesh->mb_indcs;
  if (!InActiveCoarse(indcs, cell) || indcs.nx3 != 1 ||
      pack->pz4c->opt.fd_stencil != 4) {
    return result;
  }
  const int fi = 2 * cell.i - indcs.cis;
  const int fj = 2 * cell.j - indcs.cjs;
  const bool offset_i = fi < indcs.nx1 / 2 + indcs.ng;
  const bool offset_j = fj < indcs.nx2 / 2 + indcs.ng;
  int refi = offset_i ? fi - 1 : fi - 2;
  int refj = offset_j ? fj - 1 : fj - 2;
  const int outer_i = indcs.nx1 + 2 * indcs.ng - 2;
  const int outer_j = indcs.nx2 + 2 * indcs.ng - 2;
  const bool edge_i = fi == 0 || fi == indcs.ng ||
      fi == indcs.ng + indcs.nx1 - 2 || fi == outer_i;
  const bool edge_j = fj == 0 || fj == indcs.ng ||
      fj == indcs.ng + indcs.nx2 - 2 || fj == outer_j;
  if (fi == indcs.ng) ++refi;
  if (fj == indcs.ng) ++refj;
  if (fi == indcs.ng + indcs.nx1 - 2) --refi;
  if (fj == indcs.ng + indcs.nx2 - 2) --refj;
  if (fi == 0) refi = 0;
  if (fj == 0) refj = 0;
  if (fi == outer_i) refi = indcs.nx1 + indcs.ng - 1;
  if (fj == outer_j) refj = indcs.nx2 + indcs.ng - 1;
  constexpr std::array<Real, 5> centered = {
      -5.0 / 128.0, 60.0 / 128.0, 90.0 / 128.0,
      -20.0 / 128.0, 3.0 / 128.0};
  constexpr std::array<Real, 5> edge = {
      35.0 / 128.0, 140.0 / 128.0, -70.0 / 128.0,
      28.0 / 128.0, -5.0 / 128.0};
  result.available = true;
  result.all_fine_positive = true;
  Real log_sum = 0.0;
  Real parity_sum = 0.0;
  for (int jj = 0; jj < 5; ++jj) {
    for (int ii = 0; ii < 5; ++ii) {
      const int wi_index = offset_i ? ii : 4 - ii;
      const int wj_index = offset_j ? jj : 4 - jj;
      const Real wi = edge_i ? edge[wi_index] : centered[wi_index];
      const Real wj = edge_j ? edge[wj_index] : centered[wj_index];
      const Real weight = wi * wj;
      const Real value = fine.at({cell.m, indcs.ks, refj + jj, refi + ii});
      result.fine_values.push_back(value);
      result.weights.push_back(weight);
      result.fine_min = std::min(result.fine_min, value);
      result.fine_max = std::max(result.fine_max, value);
      result.all_fine_positive = result.all_fine_positive && !InvalidChi(value);
      if (!InvalidChi(value)) log_sum += weight * std::log(value);

      if (fi == indcs.ng) {
        const int centered_refi = fi - 1;
        int parity_i = centered_refi + ii;
        if (parity_i < indcs.is) parity_i = 2 * indcs.is - 1 - parity_i;
        const Real pvalue = fine.at({cell.m, indcs.ks, refj + jj, parity_i});
        parity_sum += centered[ii] * wj * pvalue;
      }
    }
  }
  // high starts as NaN to make unavailable diagnostics explicit; replace it with
  // the exact tensor sum now that all terms have been gathered.
  result.high = 0.0;
  for (std::size_t q = 0; q < result.fine_values.size(); ++q) {
    result.high += result.weights[q] * result.fine_values[q];
  }
  const Real f00 = fine.at({cell.m, indcs.ks, fj, fi});
  const Real f10 = fine.at({cell.m, indcs.ks, fj, fi + 1});
  const Real f01 = fine.at({cell.m, indcs.ks, fj + 1, fi});
  const Real f11 = fine.at({cell.m, indcs.ks, fj + 1, fi + 1});
  result.average = 0.25 * (f00 + f10 + f01 + f11);
  if (result.all_fine_positive) result.log_candidate = std::exp(log_sum);
  if (fi == indcs.ng) result.parity_centered = parity_sum;
  return result;
}

}  // namespace

ChiParentProvenanceRuntime::ChiParentProvenanceRuntime(
    MeshBlockPack *pack, const ChiParentProvenanceConfig &config)
    : pack_(pack), config_(config), output_root_(config.output_basename) {
  // This runtime is created at the end of Z4c's constructor, before the owning
  // unique_ptr has been assigned back to MeshBlockPack::pz4c.
  if (pack_ == nullptr || pack_->pmesh == nullptr) {
    DiagnosticFatal("constructed without a complete MeshBlockPack");
  }
  if (global_variable::nranks != 1) {
    DiagnosticFatal("the bounded provenance diagnostic currently requires one MPI rank");
  }
  if (!pack_->pmesh->multilevel || pack_->pmesh->mb_indcs.nx3 != 1) {
    DiagnosticFatal("requires a multilevel collapsed-x3 calculation");
  }
  struct stat info;
  if (stat(output_root_.c_str(), &info) == 0) {
    DiagnosticFatal("fresh output directory already exists: " + output_root_);
  }
  if (mkdir(output_root_.c_str(), 0775) != 0) {
    DiagnosticFatal("cannot create output directory: " + output_root_);
  }
  {
    std::ofstream output(output_root_ + "/phase1_stage_minima.csv");
    output << "cycle,time_hex,rk_stage,checkpoint,tree_checksum,active_fine_min,"
              "active_min_gid,active_min_i,active_min_j,active_min_rho,"
              "active_min_z,active_nonpositive,active_nonfinite,"
              "consumed_coarse_min,coarse_min_gid,coarse_min_i,coarse_min_j,"
              "coarse_min_rho,coarse_min_z,coarse_nonpositive,coarse_nonfinite,"
              "consumed_coarse_cells\n";
  }
  {
    std::ofstream output(output_root_ + "/shadow_amr_requests.jsonl");
  }
  {
    std::ofstream output(output_root_ + "/replay_time_alignment.jsonl");
  }
}

ChiParentProvenanceRuntime::~ChiParentProvenanceRuntime() {
  delete fine_s0_;
  delete coarse_s1_;
  delete coarse_s2_;
  delete coarse_s3_;
}

void ChiParentProvenanceRuntime::RecordCheckpoint(
    const ChiProvenanceCheckpoint checkpoint, const int stage,
    MeshBoundaryValuesCC *boundary) {
  Mesh *mesh = pack_->pmesh;
  if (mesh->time < config_.start_time) return;
  if (checkpoint == ChiProvenanceCheckpoint::s0_after_rk) {
    cycle_ = mesh->ncycle;
    stage_ = stage;
    delete fine_s0_;
    delete coarse_s1_;
    delete coarse_s2_;
    delete coarse_s3_;
    fine_s0_ = new HostSnapshot(CaptureFineChi(pack_));
    coarse_s1_ = nullptr;
    coarse_s2_ = nullptr;
    coarse_s3_ = nullptr;
  } else if (fine_s0_ == nullptr) {
    // Driver initialization performs boundary/restriction tasks before the
    // first evolution-stage RK update. They are outside the S0--S4 audit.
    return;
  } else if (cycle_ != mesh->ncycle) {
    // Regridding and post-step boundary initialization can run after ncycle is
    // incremented but before the next cycle's first RK update.
    return;
  } else if (stage_ != stage) {
    DiagnosticFatal("checkpoint sequence does not begin at S0 for this RK stage");
  }

  // No task between S0 and S4 changes active u0. Reuse the S0 host image so
  // the diagnostic does not add four redundant device-to-host copies per RK stage.
  HostSnapshot fine = *fine_s0_;
  HostSnapshot coarse = CaptureCoarseChi(pack_);
  if (checkpoint == ChiProvenanceCheckpoint::s1_after_restriction) {
    delete coarse_s1_;
    coarse_s1_ = new HostSnapshot(coarse);
  } else if (checkpoint == ChiProvenanceCheckpoint::s2_after_receive) {
    delete coarse_s2_;
    coarse_s2_ = new HostSnapshot(coarse);
  } else if (checkpoint == ChiProvenanceCheckpoint::s3_after_boundary) {
    delete coarse_s3_;
    coarse_s3_ = new HostSnapshot(coarse);
  }

  const MinimumSummary active = ActiveFineMinimum(pack_, fine);
  const auto consumed = ConsumedCoarseCells(pack_, boundary);
  const MinimumSummary coarse_min = ConsumedCoarseMinimum(consumed, coarse);
  const auto active_xy = FineCoordinates(pack_, active.cell);
  const auto coarse_xy = CoarseCoordinates(pack_, coarse_min.cell);
  const int active_gid = pack_->pmb->mb_gid.h_view(active.cell.m);
  const int coarse_gid = pack_->pmb->mb_gid.h_view(coarse_min.cell.m);
  std::ofstream output(output_root_ + "/phase1_stage_minima.csv",
                       std::ios::app);
  output << std::setprecision(17) << mesh->ncycle << ','
         << amr_history::HexReal(mesh->time) << ',' << stage << ','
         << CheckpointName(checkpoint) << ',' << TreeChecksum(mesh) << ','
         << active.minimum << ',' << active_gid << ',' << active.cell.i << ','
         << active.cell.j << ',' << active_xy.first << ',' << active_xy.second
         << ',' << active.nonpositive << ',' << active.nonfinite << ','
         << coarse_min.minimum << ',' << coarse_gid << ',' << coarse_min.cell.i
         << ',' << coarse_min.cell.j << ',' << coarse_xy.first << ','
         << coarse_xy.second << ',' << coarse_min.nonpositive << ','
         << coarse_min.nonfinite << ',' << coarse_min.count << '\n';
  output.flush();
  if (!output) DiagnosticFatal("failed to write stage minima");
  if (checkpoint == ChiProvenanceCheckpoint::s0_after_rk &&
      (active.nonpositive != 0 || active.nonfinite != 0)) {
    std::ofstream cells(output_root_ + "/active_fine_failure.csv");
    cells << "cycle,time_hex,rk_stage,tree_checksum,gid,relative_level,lx1,lx2,"
             "lx3,local_k,local_j,local_i,rho,z,value,classification\n";
    const auto &indcs = mesh->mb_indcs;
    for (int m = 0; m < fine.nmb; ++m) {
      const int gid = pack_->pmb->mb_gid.h_view(m);
      const auto &location = mesh->lloc_eachmb[gid];
      for (int k = indcs.ks; k <= indcs.ke; ++k) {
        for (int j = indcs.js; j <= indcs.je; ++j) {
          for (int i = indcs.is; i <= indcs.ie; ++i) {
            const CellIndex cell{m, k, j, i};
            const Real value = fine.at(cell);
            if (!InvalidChi(value)) continue;
            const auto xy = FineCoordinates(pack_, cell);
            cells << std::setprecision(17) << mesh->ncycle << ','
                  << amr_history::HexReal(mesh->time) << ',' << stage << ','
                  << TreeChecksum(mesh) << ',' << gid << ','
                  << location.level - mesh->root_level << ',' << location.lx1
                  << ',' << location.lx2 << ',' << location.lx3 << ',' << k
                  << ',' << j << ',' << i << ',' << xy.first << ','
                  << xy.second << ',' << value << ',' << Classification(value)
                  << '\n';
          }
        }
      }
    }
    cells.flush();
    if (!cells) DiagnosticFatal("failed to write active fine failure cells");
    std::ofstream disposition(output_root_ + "/phase1_disposition.json");
    disposition << "{\"classification\":\"ACTIVE_FINE_CHI_FAILURE\","
                << "\"cycle\":" << mesh->ncycle << ",\"stage\":" << stage
                << ",\"time_hex\":\"" << amr_history::HexReal(mesh->time)
                << "\",\"active_nonpositive\":" << active.nonpositive
                << ",\"active_nonfinite\":" << active.nonfinite << "}\n";
    disposition.flush();
    DiagnosticFatal("active fine chi first became invalid immediately after RK update");
  }
}

void ChiParentProvenanceRuntime::AnalyzeBoundaryFailure(
    MeshBoundaryValuesCC *boundary,
    const unsigned long long invalid_parent_stencils,
    const unsigned long long first_rejected_key) {
  if (pack_->pmesh->time < config_.start_time) return;
  if (fine_s0_ == nullptr || coarse_s1_ == nullptr || coarse_s2_ == nullptr ||
      coarse_s3_ == nullptr) {
    DiagnosticFatal("boundary failure lacks a complete S0--S3 snapshot sequence");
  }
  const HostSnapshot current = CaptureCoarseChi(pack_);
  const auto &indcs = pack_->pmesh->mb_indcs;
  const int stencil = pack_->pz4c->opt.fd_stencil;
  const int lower = stencil / 2;
  const int nk = indcs.nx3 == 1 ? 1 : stencil + 1;
  auto &neighbors = pack_->pmb->nghbr;
  auto &levels = pack_->pmb->mb_lev;

  struct InvalidRecord {
    CellIndex cell;
    Real value = 0.0;
    WriterInfo writer;
    std::uint64_t multiplicity = 0;
    int storage_level = -1;
    long long global_i = 0;
    long long global_j = 0;
    Real rho = 0.0;
    Real z = 0.0;
  };
  using GlobalKey = std::tuple<int, long long, long long, int>;
  std::map<GlobalKey, InvalidRecord> invalid;
  std::uint64_t rejected_targets = 0;

  const int first_gid = static_cast<int>(first_rejected_key >> 36);
  const int first_slot = static_cast<int>((first_rejected_key >> 30) & 0x3fULL);
  const int first_k = static_cast<int>((first_rejected_key >> 20) & 0x3ffULL);
  const int first_j = static_cast<int>((first_rejected_key >> 10) & 0x3ffULL);
  const int first_i = static_cast<int>(first_rejected_key & 0x3ffULL);
  std::ofstream first(output_root_ + "/first_invalid_parent_stencil.csv");
  first << "target_gid,neighbor_slot,target_k,target_j,target_i,stencil_k,"
           "stencil_j,stencil_i,value,classification,writer,first_invalid_phase,"
           "owner_gid,owner_storage,rho,z\n";

  const Real root_dx1 = (pack_->pmesh->mesh_size.x1max -
      pack_->pmesh->mesh_size.x1min) / pack_->pmesh->mesh_indcs.nx1;
  const Real root_dx2 = (pack_->pmesh->mesh_size.x2max -
      pack_->pmesh->mesh_size.x2min) / pack_->pmesh->mesh_indcs.nx2;

  for (int m = 0; m < pack_->nmb_thispack; ++m) {
    const int gid = pack_->pmb->mb_gid.h_view(m);
    const int relative_level = levels.h_view(m) - pack_->pmesh->root_level;
    for (int n = 0; n < pack_->pmb->nnghbr; ++n) {
      if (neighbors.h_view(m, n).gid < 0 ||
          neighbors.h_view(m, n).lev >= levels.h_view(m)) continue;
      const auto &range = boundary->recvbuf[n].iprol[0];
      for (int k = range.bks; k <= range.bke; ++k) {
        for (int j = range.bjs; j <= range.bje; ++j) {
          for (int i = range.bis; i <= range.bie; ++i) {
            std::vector<std::pair<CellIndex, Real>> bad;
            for (int kk = 0; kk < nk; ++kk) {
              const int ck = indcs.nx3 == 1 ? k : k - lower + kk;
              for (int jj = 0; jj <= stencil; ++jj) {
                for (int ii = 0; ii <= stencil; ++ii) {
                  const CellIndex cell{m, ck, j - lower + jj,
                                       i - lower + ii};
                  const Real value = current.at(cell);
                  if (InvalidChi(value)) bad.emplace_back(cell, value);
                  if (gid == first_gid && n == first_slot && k == first_k &&
                      j == first_j && i == first_i) {
                    const WriterInfo writer = IdentifyWriter(
                        pack_, boundary, cell, *coarse_s1_, *coarse_s2_,
                        *coarse_s3_, value);
                    const auto xy = CoarseCoordinates(pack_, cell);
                    first << std::setprecision(17) << gid << ',' << n << ',' << k
                          << ',' << j << ',' << i << ',' << cell.k << ','
                          << cell.j << ',' << cell.i << ',' << value << ','
                          << Classification(value) << ','
                          << ChiWriterProvenanceName(writer.writer) << ','
                          << writer.first_phase << ',' << writer.owner_gid << ','
                          << writer.owner_storage << ',' << xy.first << ','
                          << xy.second << '\n';
                  }
                }
              }
            }
            if (bad.empty()) continue;
            ++rejected_targets;
            for (const auto &entry : bad) {
              const CellIndex &cell = entry.first;
              const Real value = entry.second;
              const WriterInfo writer = IdentifyWriter(
                  pack_, boundary, cell, *coarse_s1_, *coarse_s2_,
                  *coarse_s3_, value);
              const auto xy = CoarseCoordinates(pack_, cell);
              const int storage_level = relative_level - 1;
              const Real dx1 = std::ldexp(root_dx1, -storage_level);
              const Real dx2 = std::ldexp(root_dx2, -storage_level);
              const long long gi = std::llround(
                  (xy.first - pack_->pmesh->mesh_size.x1min) / dx1 - 0.5);
              const long long gj = std::llround(
                  (xy.second - pack_->pmesh->mesh_size.x2min) / dx2 - 0.5);
              const GlobalKey key{storage_level, gi, gj, writer.owner_gid};
              auto found = invalid.find(key);
              if (found == invalid.end()) {
                InvalidRecord record;
                record.cell = cell;
                record.value = value;
                record.writer = writer;
                record.multiplicity = 1;
                record.storage_level = storage_level;
                record.global_i = gi;
                record.global_j = gj;
                record.rho = xy.first;
                record.z = xy.second;
                invalid.emplace(key, record);
              } else {
                ++found->second.multiplicity;
              }
            }
          }
        }
      }
    }
  }
  first.flush();
  if (rejected_targets != invalid_parent_stencils) {
    DiagnosticFatal("offline rejected-target enumeration does not match device count");
  }

  std::ofstream unique(output_root_ + "/unique_invalid_coarse_cells.csv");
  unique << "storage_level,global_i,global_j,receiver_gid,local_k,local_j,local_i,"
            "rho,z,value,classification,writer,first_invalid_phase,owner_gid,"
            "owner_storage,multiplicity,axis_distance,receiver_block_edge_distance_cells,"
            "s1_value,s2_value,s3_value,s4_value\n";
  std::ofstream multiplicity(
      output_root_ + "/invalid_cell_consumption_multiplicity.csv");
  multiplicity << "storage_level,global_i,global_j,owner_gid,rejected_targets_consuming\n";
  std::ofstream candidates(output_root_ + "/restriction_candidate_comparison.csv");
  candidates << "storage_level,global_i,global_j,receiver_gid,local_j,local_i,"
                "stencil_class,all_fine_positive,fine_min,fine_max,production_s1,"
                "recomputed_high,convex_2x2_average,log_restriction_candidate,"
                "parity_folded_axis_candidate,fine_stencil_values,tensor_weights\n";

  std::map<ChiWriterProvenance, std::uint64_t> writer_counts;
  bool restriction_signature = false;
  bool communication_signature = false;
  bool boundary_signature = false;
  Real minimum_invalid = std::numeric_limits<Real>::infinity();
  const InvalidRecord *first_record = nullptr;
  for (const auto &item : invalid) {
    const auto &key = item.first;
    const InvalidRecord &record = item.second;
    ++writer_counts[record.writer.writer];
    if (first_record == nullptr || record.value < minimum_invalid) {
      first_record = &record;
      minimum_invalid = record.value;
    }
    const int gid = pack_->pmb->mb_gid.h_view(record.cell.m);
    const int edge_distance = std::min(
        std::min(std::abs(record.cell.i - indcs.cis),
                 std::abs(record.cell.i - indcs.cie)),
        std::min(std::abs(record.cell.j - indcs.cjs),
                 std::abs(record.cell.j - indcs.cje)));
    unique << std::setprecision(17) << record.storage_level << ','
           << record.global_i << ',' << record.global_j << ',' << gid << ','
           << record.cell.k << ',' << record.cell.j << ',' << record.cell.i << ','
           << record.rho << ',' << record.z << ',' << record.value << ','
           << Classification(record.value) << ','
           << ChiWriterProvenanceName(record.writer.writer) << ','
           << record.writer.first_phase << ',' << record.writer.owner_gid << ','
           << record.writer.owner_storage << ',' << record.multiplicity << ','
           << record.rho << ',' << edge_distance << ','
           << coarse_s1_->at(record.cell) << ',' << coarse_s2_->at(record.cell)
           << ',' << coarse_s3_->at(record.cell) << ',' << record.value << '\n';
    multiplicity << std::get<0>(key) << ',' << std::get<1>(key) << ','
                 << std::get<2>(key) << ',' << std::get<3>(key) << ','
                 << record.multiplicity << '\n';

    if (record.writer.writer >= ChiWriterProvenance::local_restriction_centered &&
        record.writer.writer <= ChiWriterProvenance::local_restriction_corner) {
      const RestrictionDiagnostic diagnostic =
          RestrictionCandidates(pack_, record.cell, *fine_s0_);
      if (diagnostic.available) {
        candidates << std::setprecision(17) << record.storage_level << ','
                   << record.global_i << ',' << record.global_j << ',' << gid << ','
                   << record.cell.j << ',' << record.cell.i << ','
                   << ChiWriterProvenanceName(record.writer.writer) << ','
                   << (diagnostic.all_fine_positive ? "true" : "false") << ','
                   << diagnostic.fine_min << ',' << diagnostic.fine_max << ','
                   << coarse_s1_->at(record.cell) << ',' << diagnostic.high << ','
                   << diagnostic.average << ',' << diagnostic.log_candidate << ','
                   << diagnostic.parity_centered << ','
                   << Join(diagnostic.fine_values) << ',' << Join(diagnostic.weights)
                   << '\n';
        if (diagnostic.all_fine_positive && InvalidChi(diagnostic.high) &&
            !InvalidChi(diagnostic.average)) {
          restriction_signature = true;
        }
      }
    } else if (record.writer.writer ==
                   ChiWriterProvenance::same_level_owner_receive ||
               record.writer.writer ==
                   ChiWriterProvenance::coarser_neighbor_receive) {
      communication_signature = true;
    } else if (record.writer.writer == ChiWriterProvenance::axis_boundary_fill ||
               record.writer.writer ==
                   ChiWriterProvenance::outer_physical_boundary_fill) {
      boundary_signature = true;
    }
  }
  unique.flush();
  multiplicity.flush();
  candidates.flush();

  std::string disposition = "NOT_ESTABLISHED";
  const int mechanism_count = static_cast<int>(restriction_signature) +
      static_cast<int>(communication_signature) +
      static_cast<int>(boundary_signature);
  if (mechanism_count > 1) disposition = "MIXED_MECHANISM";
  else if (restriction_signature) {
    disposition = "HIGH_ORDER_RESTRICTION_BREAKS_POSITIVITY";
  } else if (communication_signature || boundary_signature) {
    disposition = "COMMUNICATION_OR_BOUNDARY_BREAKS_POSITIVITY";
  }

  if (first_record == nullptr) DiagnosticFatal("device reported no recoverable invalid cell");
  std::ofstream first_json(output_root_ + "/first_invalid_coarse_cell.json");
  first_json << std::setprecision(17)
             << "{\"schema\":\"athenak_z4c_chi_parent_provenance_v1\","
             << "\"phase1_classification\":\"" << disposition << "\","
             << "\"cycle\":" << pack_->pmesh->ncycle << ",\"stage\":"
             << stage_ << ",\"time_hex\":\""
             << amr_history::HexReal(pack_->pmesh->time) << "\","
             << "\"device_rejected_parent_stencils\":"
             << invalid_parent_stencils << ",\"enumerated_rejected_targets\":"
             << rejected_targets << ",\"unique_invalid_coarse_cells\":"
             << invalid.size() << ",\"minimum_invalid_value\":"
             << JsonReal(minimum_invalid) << ",\"first_writer\":\""
             << ChiWriterProvenanceName(first_record->writer.writer) << "\","
             << "\"first_invalid_phase\":\""
             << first_record->writer.first_phase << "\",\"rho\":"
             << first_record->rho << ",\"z\":" << first_record->z
             << ",\"writer_counts\":{";
  bool first_count = true;
  for (const auto &count : writer_counts) {
    if (!first_count) first_json << ',';
    first_count = false;
    first_json << '\"' << ChiWriterProvenanceName(count.first) << "\":"
               << count.second;
  }
  first_json << "}}\n";
  first_json.flush();
  std::ofstream phase1(output_root_ + "/phase1_disposition.json");
  phase1 << "{\"classification\":\"" << disposition
         << "\",\"cycle\":" << pack_->pmesh->ncycle << ",\"stage\":"
         << stage_ << ",\"unique_invalid_coarse_cells\":" << invalid.size()
         << ",\"rejected_parent_stencils\":" << invalid_parent_stencils
         << "}\n";
  phase1.flush();
  std::cerr << "CHI_PARENT_PROVENANCE classification=" << disposition
            << " unique_invalid_coarse_cells=" << invalid.size()
            << " rejected_parent_stencils=" << invalid_parent_stencils
            << std::endl;
}

void ChiParentProvenanceRuntime::RecordShadowAMRRequests(
    const std::size_t next_event, const std::string &next_event_time_hex,
    const std::string &tree_checksum) {
  if (pack_->pmesh->time < config_.start_time) return;
  Mesh *mesh = pack_->pmesh;
  const int begin = mesh->gids_eachrank[global_variable::my_rank];
  bool any = false;
  for (int m = 0; m < pack_->nmb_thispack; ++m) {
    if (mesh->pmr->refine_flag.h_view(begin + m) != 0) any = true;
  }
  if (!any) return;
  const HostSnapshot fine = CaptureFineChi(pack_);
  const auto &indcs = mesh->mb_indcs;
  std::ofstream output(output_root_ + "/shadow_amr_requests.jsonl",
                       std::ios::app);
  for (int m = 0; m < pack_->nmb_thispack; ++m) {
    const int gid = begin + m;
    const int flag = mesh->pmr->refine_flag.h_view(gid);
    if (flag == 0) continue;
    Real dmax = 0.0;
    for (int j = indcs.js; j <= indcs.je; ++j) {
      for (int i = indcs.is; i <= indcs.ie; ++i) {
        const Real di = fine.at({m, indcs.ks, j, i + 1}) -
                        fine.at({m, indcs.ks, j, i - 1});
        const Real dj = fine.at({m, indcs.ks, j + 1, i}) -
                        fine.at({m, indcs.ks, j - 1, i});
        dmax = std::max(dmax, std::sqrt(di * di + dj * dj));
      }
    }
    const auto &loc = mesh->lloc_eachmb[gid];
    output << std::setprecision(17)
           << "{\"schema\":\"athenak_amr_shadow_request_v1\",\"cycle\":"
           << mesh->ncycle << ",\"actual_time_hex\":\""
           << amr_history::HexReal(mesh->time) << "\",\"next_authority_event\":"
           << next_event << ",\"next_authority_time_hex\":\""
           << next_event_time_hex << "\",\"tree_checksum\":\""
           << tree_checksum << "\",\"gid\":" << gid << ",\"level\":"
           << loc.level - mesh->root_level << ",\"lx1\":" << loc.lx1
           << ",\"lx2\":" << loc.lx2 << ",\"lx3\":" << loc.lx3
           << ",\"requested_flag\":" << flag << ",\"raw_dchi_max\":"
           << dmax << ",\"dchi_threshold\":"
           << pack_->pz4c->pamr->dchi_thresh << ",\"derefine_threshold\":"
           << pack_->pz4c->pamr->dchi_derefine_factor *
                  pack_->pz4c->pamr->dchi_thresh
           << "}\n";
  }
  output.flush();
  if (!output) DiagnosticFatal("failed to append shadow AMR requests");
}

void ChiParentProvenanceRuntime::RecordReplayAlignment(
    const std::size_t event, const std::string &authority_time_hex,
    const std::string &actual_time_hex, const double signed_difference,
    const long long ulp_difference, const bool preceding_timestep_clipped) {
  std::ofstream output(output_root_ + "/replay_time_alignment.jsonl",
                       std::ios::app);
  output << std::setprecision(17)
         << "{\"schema\":\"athenak_amr_replay_time_alignment_v1\","
         << "\"event\":" << event << ",\"authority_time_hex\":\""
         << authority_time_hex << "\",\"actual_mesh_time_hex\":\""
         << actual_time_hex << "\",\"signed_difference\":"
         << signed_difference << ",\"ulp_difference\":" << ulp_difference
         << ",\"preceding_timestep_clipped\":"
         << (preceding_timestep_clipped ? "true" : "false") << "}\n";
  output.flush();
  if (!output) DiagnosticFatal("failed to append replay time alignment");
}

}  // namespace z4c
