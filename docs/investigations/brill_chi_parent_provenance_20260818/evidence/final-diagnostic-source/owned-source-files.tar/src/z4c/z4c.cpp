//========================================================================================
// AthenaXXX astrophysical plasma code
// Copyright(C) 2020 James M. Stone <jmstone@ias.edu> and the Athena code team
// Licensed under the 3-clause BSD License (the "LICENSE")
//========================================================================================
//! \file z4c.cpp
//! \brief implementation of Z4c class constructor and assorted other functions

#include <math.h>
#include <sys/stat.h>  // mkdir

#include <iostream>
#include <string>
#include <algorithm>
#include <memory>    // make_unique, unique_ptr
#include <vector>    // vector
#include <Kokkos_Core.hpp>

#include "athena.hpp"
#include "globals.hpp"
#include "parameter_input.hpp"
#include "mesh/mesh.hpp"
#include "bvals/bvals.hpp"
#include "z4c/fastflow.hpp"
#include "z4c/compact_object_tracker.hpp"
#include "z4c/horizon_dump.hpp"
#include "z4c/z4c.hpp"
#include "z4c/z4c_amr.hpp"
#include "z4c/z4c_symmetry.hpp"
#include "z4c/stored_domain_bounds.hpp"
#include "coordinates/adm.hpp"
#include "utils/cart_grid.hpp"

namespace z4c {

char const * const Z4c::Z4c_names[Z4c::nz4c] = {
  "z4c_chi",
  "z4c_gxx", "z4c_gxy", "z4c_gxz", "z4c_gyy", "z4c_gyz", "z4c_gzz",
  "z4c_Khat",
  "z4c_Axx", "z4c_Axy", "z4c_Axz", "z4c_Ayy", "z4c_Ayz", "z4c_Azz",
  "z4c_Gamx", "z4c_Gamy", "z4c_Gamz",
  "z4c_Theta",
  "z4c_alpha",
  "z4c_betax", "z4c_betay", "z4c_betaz",
  "z4c_Bx", "z4c_By", "z4c_Bz",
};

char const * const Z4c::Constraint_names[Z4c::ncon] = {
  "con_C",
  "con_H",
  "con_M",
  "con_Z",
  "con_Mx", "con_My", "con_Mz",
};

/*char const * const Z4c::Matter_names[Z4c::nmat] = {
  "mat_rho",
  "mat_Sx", "mat_Sy", "mat_Sz",
  "mat_Sxx", "mat_Sxy", "mat_Sxz", "mat_Syy", "mat_Syz", "mat_Szz",
};*/

//----------------------------------------------------------------------------------------
// constructor, initializes data structures and parameters

Z4c::Z4c(MeshBlockPack *ppack, ParameterInput *pin) :
  u_con("u_con",1,1,1,1,1),
  //u_mat("u_mat",1,1,1,1,1),
  u0("u0 z4c",1,1,1,1,1),
  u1("u1 z4c",1,1,1,1,1),
  u_rhs("u_rhs z4c",1,1,1,1,1),
  u_telegraph_mu("u_telegraph_mu",1,1,1,1,1),
  coarse_u0("coarse u0 z4c",1,1,1,1,1),
  u_weyl("u_weyl",1,1,1,1,1),
  coarse_u_weyl("coarse_u_weyl",1,1,1,1,1),
  pamr(new Z4c_AMR(pin)),
  pmy_pack(ppack) {
  // (1) read time-evolution option [already error checked in driver constructor]
  // Then initialize memory and algorithms for reconstruction and Riemann solvers
  std::string evolution_t = pin->GetString("time","evolution");

  int nmb = std::max((ppack->nmb_thispack), (ppack->pmesh->nmb_maxperrank));
  // int nmb = ppack->nmb_thispack;
  auto &indcs = pmy_pack->pmesh->mb_indcs;
  {
  const auto bounds = MakeStoredDomainBounds(indcs);
  Kokkos::Profiling::pushRegion("Tensor fields");
  Kokkos::realloc(u_con, nmb, (ncon), bounds.n3, bounds.n2, bounds.n1);
  // Matter storage is currently disabled.
  Kokkos::realloc(u0,    nmb, (nz4c), bounds.n3, bounds.n2, bounds.n1);
  Kokkos::realloc(u1,    nmb, (nz4c), bounds.n3, bounds.n2, bounds.n1);
  Kokkos::realloc(u_rhs, nmb, (nz4c), bounds.n3, bounds.n2, bounds.n1);
  Kokkos::realloc(u_telegraph_mu, nmb, 1, bounds.n3, bounds.n2, bounds.n1);
  Kokkos::deep_copy(u_telegraph_mu, 0.0);
  Kokkos::realloc(u_weyl,    nmb, (2), bounds.n3, bounds.n2, bounds.n1);

  con.C.InitWithShallowSlice(u_con, I_CON_C);
  con.H.InitWithShallowSlice(u_con, I_CON_H);
  con.M.InitWithShallowSlice(u_con, I_CON_M);
  con.Z.InitWithShallowSlice(u_con, I_CON_Z);
  con.M_d.InitWithShallowSlice(u_con, I_CON_MX, I_CON_MZ);

  z4c.alpha.InitWithShallowSlice (u0, I_Z4C_ALPHA);
  z4c.beta_u.InitWithShallowSlice(u0, I_Z4C_BETAX, I_Z4C_BETAZ);
  z4c.vB_d.InitWithShallowSlice(u0, I_Z4C_BX, I_Z4C_BZ);
  z4c.chi.InitWithShallowSlice   (u0, I_Z4C_CHI);
  z4c.vKhat.InitWithShallowSlice  (u0, I_Z4C_KHAT);
  z4c.vTheta.InitWithShallowSlice (u0, I_Z4C_THETA);
  z4c.vGam_u.InitWithShallowSlice (u0, I_Z4C_GAMX, I_Z4C_GAMZ);
  z4c.g_dd.InitWithShallowSlice  (u0, I_Z4C_GXX, I_Z4C_GZZ);
  z4c.vA_dd.InitWithShallowSlice  (u0, I_Z4C_AXX, I_Z4C_AZZ);

  rhs.alpha.InitWithShallowSlice (u_rhs, I_Z4C_ALPHA);
  rhs.beta_u.InitWithShallowSlice(u_rhs, I_Z4C_BETAX, I_Z4C_BETAZ);
  rhs.vB_d.InitWithShallowSlice  (u_rhs, I_Z4C_BX, I_Z4C_BZ);
  rhs.chi.InitWithShallowSlice   (u_rhs, I_Z4C_CHI);
  rhs.vKhat.InitWithShallowSlice  (u_rhs, I_Z4C_KHAT);
  rhs.vTheta.InitWithShallowSlice (u_rhs, I_Z4C_THETA);
  rhs.vGam_u.InitWithShallowSlice (u_rhs, I_Z4C_GAMX, I_Z4C_GAMZ);
  rhs.g_dd.InitWithShallowSlice  (u_rhs, I_Z4C_GXX, I_Z4C_GZZ);
  rhs.vA_dd.InitWithShallowSlice  (u_rhs, I_Z4C_AXX, I_Z4C_AZZ);

  weyl.rpsi4.InitWithShallowSlice (u_weyl, 0);
  weyl.ipsi4.InitWithShallowSlice (u_weyl, 1);

  opt.chi_psi_power = pin->GetOrAddReal("z4c", "chi_psi_power", -4.0);
  opt.chi_div_floor = pin->GetOrAddReal("z4c", "chi_div_floor", -1000.0);
  opt.chi_min_floor = pin->GetOrAddReal("z4c", "chi_min_floor", 1e-12);
  opt.floor_chi = pin->GetOrAddBoolean("z4c", "floor_chi", false);
  opt.diss = pin->GetOrAddReal("z4c", "diss", 0.0);
  const std::string amr_transfer =
      pin->GetOrAddString("z4c", "amr_transfer", "high_order");
  if (amr_transfer == "high_order") {
    opt.amr_transfer = Z4cAMRTransfer::high_order;
  } else if (amr_transfer == "limited_o2") {
    opt.amr_transfer = Z4cAMRTransfer::limited_o2;
  } else {
    std::cerr << "### FATAL ERROR in " << __FILE__
              << ": unknown <z4c>/amr_transfer=" << amr_transfer
              << "; expected high_order or limited_o2" << std::endl;
    std::exit(EXIT_FAILURE);
  }
  opt.eps_floor = pin->GetOrAddReal("z4c", "eps_floor", 1e-12);
  opt.damp_kappa1 = pin->GetOrAddReal("z4c", "damp_kappa1", 0.0);
  opt.damp_kappa2 = pin->GetOrAddReal("z4c", "damp_kappa2", 0.0);
  opt.damp_kappa1_max_K =
      pin->GetOrAddBoolean("z4c", "damp_kappa1_max_K", false);
  opt.history_kretschmann =
      pin->GetOrAddBoolean("z4c", "history_kretschmann", false);
  opt.rhs_stage_diagnostics =
      pin->GetOrAddBoolean("z4c", "rhs_stage_diagnostics", false);
  opt.rhs_stage_diagnostics_start_time =
      pin->GetOrAddReal("z4c", "rhs_stage_diagnostics_start_time", 0.0);
  opt.rhs_stage_diagnostics_rho_max =
      pin->GetOrAddReal("z4c", "rhs_stage_diagnostics_rho_max", 0.5);
  opt.rhs_stage_diagnostics_abs_z_max =
      pin->GetOrAddReal("z4c", "rhs_stage_diagnostics_abs_z_max", 0.5);
  if (opt.rhs_stage_diagnostics_rho_max <= 0.0 ||
      opt.rhs_stage_diagnostics_abs_z_max <= 0.0) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
              << std::endl
              << "Z4c RHS stage diagnostic extents must be positive" << std::endl;
    std::exit(EXIT_FAILURE);
  }
  try {
    AMRJumpDiagnosticContext jump_context;
    jump_context.cartoon =
        pmy_pack->z4c_symmetry.mode == Z4cSymmetryMode::cartoon_so2;
    jump_context.adaptive = pmy_pack->pmesh->adaptive;
    jump_context.multilevel = pmy_pack->pmesh->multilevel;
    // User-facing AMR levels and the history maximum-level column are measured
    // relative to the root grid, whereas LogicalLocation::level includes the
    // root-grid Morton depth.
    jump_context.root_level = 0;
    jump_context.maximum_level =
        pmy_pack->pmesh->max_level - pmy_pack->pmesh->root_level;
    jump_context.nranks = global_variable::nranks;
    opt.amr_jump_diagnostic =
        ReadAMRJumpDiagnosticConfig(pin, jump_context);
  } catch (const std::invalid_argument &error) {
    std::cerr << "### FATAL ERROR in " << __FILE__
              << ": invalid Z4c AMR jump diagnostic configuration: "
              << error.what() << std::endl;
    std::exit(EXIT_FAILURE);
  }
  opt.chi_parent_provenance = ReadChiParentProvenanceConfig(pin);
  // Gauge conditions (default to moving puncture gauge)
  opt.lapse_harmonicf = pin->GetOrAddReal("z4c", "lapse_harmonicf", 1.0);
  opt.lapse_harmonic = pin->GetOrAddReal("z4c", "lapse_harmonic", 0.0);
  opt.lapse_oplog = pin->GetOrAddReal("z4c", "lapse_oplog", 2.0);
  opt.lapse_advect = pin->GetOrAddReal("z4c", "lapse_advect", 1.0);
  // Keep the legacy input/output bytes unchanged unless this prospective gauge is
  // explicitly requested.
  opt.lapse_shock_avoiding =
      pin->DoesParameterExist("z4c", "lapse_shock_avoiding") &&
      pin->GetBoolean("z4c", "lapse_shock_avoiding");
  opt.lapse_shock_avoiding_kappa =
      pin->DoesParameterExist("z4c", "lapse_shock_avoiding_kappa")
          ? pin->GetReal("z4c", "lapse_shock_avoiding_kappa")
          : 1.0;
  opt.slow_start_lapse = pin->GetOrAddBoolean("z4c", "slow_start_lapse", false);
  opt.ssl_damping_amp = pin->GetOrAddReal("z4c", "ssl_damping_amp", 0.6);
  opt.ssl_damping_time = pin->GetOrAddReal("z4c", "ssl_damping_time", 20.0);
  opt.ssl_damping_index = pin->GetOrAddInteger("z4c", "ssl_damping_index", 1);
  opt.sss_damping_amp = pin->GetOrAddReal("z4c", "sss_damping_amp", 0.);
  opt.sss_damping_time = pin->GetOrAddReal("z4c", "sss_damping_time", 10.0);
  opt.telegraph_lapse = pin->GetOrAddBoolean("z4c", "telegraph_lapse", false);
  opt.telegraph_max_K = pin->GetOrAddBoolean("z4c", "telegraph_max_K", false);
  const std::string telegraph_damping_prescription =
      pin->DoesParameterExist("z4c", "telegraph_damping_prescription")
          ? pin->GetString("z4c", "telegraph_damping_prescription")
          : (opt.telegraph_max_K ? "max_domain_abs_K" : "fixed");
  if (telegraph_damping_prescription == "fixed") {
    opt.telegraph_damping_prescription = TelegraphDampingPrescription::fixed;
  } else if (telegraph_damping_prescription == "max_domain_abs_K") {
    opt.telegraph_damping_prescription =
        TelegraphDampingPrescription::max_domain_abs_K;
  } else if (telegraph_damping_prescription == "local_abs_K") {
    opt.telegraph_damping_prescription = TelegraphDampingPrescription::local_abs_K;
  } else if (telegraph_damping_prescription ==
             "local_extrinsic_curvature_norm") {
    opt.telegraph_damping_prescription =
        TelegraphDampingPrescription::local_extrinsic_curvature_norm;
  } else if (telegraph_damping_prescription == "local_chi_gradient_norm") {
    opt.telegraph_damping_prescription =
        TelegraphDampingPrescription::local_chi_gradient_norm;
  } else {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
              << std::endl
              << "unknown <z4c>/telegraph_damping_prescription='"
              << telegraph_damping_prescription << "'; expected fixed, "
              << "max_domain_abs_K, local_abs_K, "
              << "local_extrinsic_curvature_norm, or local_chi_gradient_norm"
              << std::endl;
    std::exit(EXIT_FAILURE);
  }
  opt.telegraph_tau = pin->GetOrAddReal("z4c", "telegraph_tau", 0.1);
  opt.telegraph_kappa = pin->GetOrAddReal("z4c", "telegraph_kappa", 0.1);

  opt.shift_ggamma = pin->GetOrAddReal("z4c", "shift_Gamma", 1.0);
  opt.shift_advect = pin->GetOrAddReal("z4c", "shift_advect", 1.0);
  opt.shift_alpha2ggamma = pin->GetOrAddReal("z4c", "shift_alpha2Gamma", 0.0);
  opt.shift_hh = pin->GetOrAddReal("z4c", "shift_H", 0.0);
  opt.shift_eta = pin->GetOrAddReal("z4c", "shift_eta", 2.0);
  opt.shift_eta_max_K = pin->GetOrAddBoolean("z4c", "shift_eta_max_K", false);

  if (opt.telegraph_tau <= 0.0) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
              << std::endl
              << "<z4c>/telegraph_tau must be positive, but is "
              << opt.telegraph_tau << std::endl;
    std::exit(EXIT_FAILURE);
  }
  if (opt.telegraph_kappa < 0.0) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
              << std::endl
              << "<z4c>/telegraph_kappa must be nonnegative, but is "
              << opt.telegraph_kappa << std::endl;
    std::exit(EXIT_FAILURE);
  }
  if (opt.lapse_shock_avoiding) {
    if (opt.lapse_shock_avoiding_kappa <= 0.0) {
      std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
                << std::endl
                << "<z4c>/lapse_shock_avoiding_kappa must be positive, but is "
                << opt.lapse_shock_avoiding_kappa << std::endl;
      std::exit(EXIT_FAILURE);
    }
    if (opt.telegraph_lapse || opt.slow_start_lapse || opt.lapse_oplog != 0.0 ||
        opt.lapse_harmonic != 0.0) {
      std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
                << std::endl
                << "shock-avoiding lapse requires telegraph_lapse=false, "
                << "slow_start_lapse=false, lapse_oplog=0, and lapse_harmonic=0"
                << std::endl;
      std::exit(EXIT_FAILURE);
    }
  }

  opt.use_z4c = pin->GetOrAddBoolean("z4c", "use_z4c", true);

  opt.user_Sbc = pin->GetOrAddBoolean("z4c", "user_Sbc", false);

  opt.excise_chi = pin->GetOrAddReal("z4c", "excise_chi", 0.0625);

  opt.extrap_order = fmax(2,fmin(indcs.ng,fmin(4,
      pin->GetOrAddInteger("z4c", "extrap_order", 2))));

  int const default_spatial_order = 2 * (indcs.ng - 1);
  int const requested_spatial_order = pin->GetOrAddInteger("z4c", "spatial_order",
                                                           default_spatial_order);
  opt.spatial_order = EffectiveZ4cSpatialOrder(requested_spatial_order, indcs.ng);
  if (opt.spatial_order != 2 && opt.spatial_order != 4 && opt.spatial_order != 6) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
              << std::endl
              << "<z4c>/spatial_order must be 2, 4, or 6, but is "
              << opt.spatial_order << std::endl;
    std::exit(EXIT_FAILURE);
  }
  opt.fd_stencil = opt.spatial_order/2 + 1;
  if (indcs.ng < opt.fd_stencil) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
              << std::endl
              << "<z4c>/spatial_order=" << opt.spatial_order
              << " requires at least " << opt.fd_stencil
              << " ghost cells, but <mesh>/nghost=" << indcs.ng << std::endl;
    std::exit(EXIT_FAILURE);
  }
  if (opt.history_kretschmann && opt.fd_stencil != 4) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
              << std::endl
              << "<z4c>/history_kretschmann=true requires "
              << "<z4c>/spatial_order=6 and at least four ghost cells"
              << std::endl;
    std::exit(EXIT_FAILURE);
  }

  opt.roll_kappa = pin->GetOrAddBoolean("z4c", "roll_kappa", false);
  opt.kappa_roll_start_time = pin->GetOrAddReal("z4c", "kappa_roll_start_time", 0.0);
  opt.roll_window = pin->GetOrAddReal("z4c", "roll_window", 20.0);
  opt.target_kappa1 = pin->GetOrAddReal("z4c", "target_kappa1", 0.0);

  diss = opt.diss*pow(2., -2.*opt.fd_stencil)*(opt.fd_stencil % 2 == 0 ? -1. : 1.);
  }

  // allocate memory for conserved variables on coarse mesh
  if (ppack->pmesh->multilevel) {
    auto &indcs = pmy_pack->pmesh->mb_indcs;
    const auto coarse_bounds = MakeCoarseStoredDomainBounds(indcs);
    Kokkos::realloc(coarse_u0, nmb, (nz4c), coarse_bounds.n3,
                    coarse_bounds.n2, coarse_bounds.n1);
    Kokkos::realloc(coarse_u_weyl, nmb, (2), coarse_bounds.n3,
                    coarse_bounds.n2, coarse_bounds.n1);
  }
  Kokkos::Profiling::popRegion();

  // allocate boundary buffers for conserved (cell-centered) variables
  Kokkos::Profiling::pushRegion("Buffers");
  pbval_u = new MeshBoundaryValuesCC(ppack, pin, true);
  pbval_u->InitializeBuffers((nz4c));
  pbval_weyl = new MeshBoundaryValuesCC(ppack, pin, true);
  pbval_weyl->InitializeBuffers((2));
  Kokkos::Profiling::popRegion();

  // wave extraction spheres
  // TODO(@hzhu): Read radii from input file
  auto &grids = spherical_grids;
  // set nrad_wave_extraction = 0 to turn off wave extraction
  nrad = pin->GetOrAddReal("z4c", "nrad_wave_extraction", 0);
  int nlev = pin->GetOrAddReal("z4c", "extraction_nlev", 10);
  for (int i=0; i<nrad; i++) {
    Real rad = pin->GetOrAddReal("z4c", "extraction_radius_"+std::to_string(i), 10);
    grids.push_back(std::make_unique<SphericalGrid>(ppack, nlev, rad));
  }
  // TODO(@dur566): Why is the size of psi_out hardcoded?
  psi_out = new Real[nrad*77*2];
  if (nrad > 0) {
    mkdir("waveforms",0775);
  }
  waveform_dt = pin->GetOrAddReal("z4c", "waveform_dt", 1);
  last_output_time = 0;
  // CCE
  cce_dump_dt = pin->GetOrAddReal("cce", "cce_dt", 1);
  int ncce = pin->GetOrAddInteger("cce", "num_radii", 0);
  if (ncce > 0) {
    mkdir("cce",0775);
  }
  cce_dump_last_output_time = -100;

  // Construct the compact object trackers
  int n = 0;
  while (true) {
    if (pin->DoesParameterExist("z4c", "co_" + std::to_string(n) + "_type")) {
      ptracker.push_back(std::make_unique<CompactObjectTracker>(pmy_pack->pmesh, pin, n));
      n++;
    } else {
      break;
    }
  }
  // Construct the apparent horizon finders
  n = 0;
  while (n < pin->GetOrAddInteger("fastflow", "num_horizons", 0)) {
    pfastflow.push_back(std::make_unique<FastFlow>(pmy_pack, pin, n));
    n++;
  }
  // Construct the Cartesian data grid for dumping horizon data
  n = 0;
  while (true) {
    if (pin->GetOrAddBoolean("z4c", "dump_horizon_" + std::to_string(n),false)) {
      // phorizon_dump.emplace_back(pmy_pack, pin, n,false);
      phorizon_dump.push_back(std::make_unique<HorizonDump>(pmy_pack, pin, n, 0));
      std::string foldername = "horizon_"+std::to_string(n);
      mkdir(foldername.c_str(),0775);
      n++;
    } else {
      break;
    }
  }
  if (opt.amr_jump_diagnostic.enabled) {
    amr_jump_diagnostic = std::make_unique<AMRJumpDiagnosticRuntime>(
        pmy_pack, opt.amr_jump_diagnostic);
  }
  if (opt.chi_parent_provenance.enabled) {
    chi_parent_provenance = std::make_unique<ChiParentProvenanceRuntime>(
        pmy_pack, opt.chi_parent_provenance);
  }
}

//----------------------------------------------------------------------------------------
//! \fn void Z4c::AlgConstr(AthenaArray<Real> & u)
//! \brief algebraic constraints projection
//
// This function operates on all grid points of the MeshBlock
void Z4c::AlgConstr(MeshBlockPack *pmbp) {
  // capture variables for the kernel
  auto &indcs = pmbp->pmesh->mb_indcs;
  const auto bounds = MakeStoredDomainBounds(indcs);

  int nmb = pmbp->nmb_thispack;

  auto &z4c = pmbp->pz4c->z4c;
  par_for("Alg constr loop",DevExeSpace(),
  0,nmb-1,bounds.ks,bounds.ke,bounds.js,bounds.je,bounds.is,bounds.ie,
  KOKKOS_LAMBDA(const int m, const int k, const int j, const int i) {
    Real detg = adm::SpatialDet(z4c.g_dd(m,0,0,k,j,i), z4c.g_dd(m,0,1,k,j,i),
                              z4c.g_dd(m,0,2,k,j,i),z4c.g_dd(m,1,1,k,j,i),
                              z4c.g_dd(m,1,2,k,j,i), z4c.g_dd(m,2,2,k,j,i));
    detg = detg > 0. ? detg : 1.;
    // Real eps = detg - 1.;
    // Real oopsi4 = (eps < opt.eps_floor) ? (1. - opt.eps_floor/3.) :
    //             (std::pow(1./detg, 1./3.));
    Real oopsi4 = std::cbrt(1./detg);

    for(int a = 0; a < 3; ++a)
    for(int b = a; b < 3; ++b) {
      z4c.g_dd(m,a,b,k,j,i) *= oopsi4;
    }

    // compute trace of A
    // note: here we are assuming that det g = 1, which we enforced above
    Real A = adm::Trace(1.0,
              z4c.g_dd(m,0,0,k,j,i), z4c.g_dd(m,0,1,k,j,i), z4c.g_dd(m,0,2,k,j,i),
              z4c.g_dd(m,1,1,k,j,i), z4c.g_dd(m,1,2,k,j,i), z4c.g_dd(m,2,2,k,j,i),
              z4c.vA_dd(m,0,0,k,j,i), z4c.vA_dd(m,0,1,k,j,i), z4c.vA_dd(m,0,2,k,j,i),
              z4c.vA_dd(m,1,1,k,j,i), z4c.vA_dd(m,1,2,k,j,i), z4c.vA_dd(m,2,2,k,j,i));

    // enforce trace of A to be zero
    for(int a = 0; a < 3; ++a)
    for(int b = a; b < 3; ++b) {
      z4c.vA_dd(m,a,b,k,j,i) -= (1.0/3.0) * A * z4c.g_dd(m,a,b,k,j,i);
    }
  });
}

//----------------------------------------------------------------------------------------
// destructor
Z4c::~Z4c() {
  delete[] psi_out;
  delete pbval_weyl;
  delete pbval_u;
  delete pamr;
}

} // namespace z4c
