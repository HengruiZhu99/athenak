## Repeated setup comparisons

| Backend / case | Ranks | M0 process (s) | M4 process (s) | Paired median speedup | Paired 95% t interval |
|---|---:|---:|---:|---:|---:|
| CPU / dynamic | 2 | 79.342 | 57.641 | 1.376× | 1.341–1.409 |
| CPU / fixed | 4 | 42.020 | 34.479 | 1.216× | 1.051–1.347 |
| Aurora / dynamic | 2 | 64.713 | 37.855 | 1.710× | 1.704–1.715 |
| Aurora / fixed | 4 | 23.323 | 14.350 | 1.627× | 1.591–1.654 |

Three alternating pairs per row. Fixed: eight steps, 15 Cartesian leaves;
dynamic: six steps and 15→22→8 leaves. The same six-shell exterior and
every-step diagnostics are retained. The intervals assume independent log
ratios and do not remove workstation scheduling uncertainty.

![Setup comparisons](plots/setup-speedup.png)

## Aurora strong scaling

| Problem | Ranks / used nodes | Step + diagnostics (s) | Full range (s) | Steady speedup / efficiency | Process (s) | Max rank host RSS (GiB) | Max node RSS upper bound (GiB) |
|---|---:|---:|---:|---:|---:|---:|---:|
| Mixed | 1 / 1 | 0.40608 | 0.40603–0.40622 | 1.00× / 100.0% | 26.08 | 2.64 | 2.64 |
| Mixed | 2 / 1 | 0.28373 | 0.28354–0.28380 | 1.43× / 71.6% | 22.07 | 2.50 | 4.99 |
| Mixed | 4 / 1 | 0.18870 | 0.18865–0.18883 | 2.15× / 53.8% | 18.96 | 2.27 | 8.33 |
| Mixed | 8 / 2 | 0.16585 | 0.16577–0.16585 | 2.45× / 30.6% | 17.91 | 1.99 | 7.54 |
| Mixed | 8 / 1 | 0.16569 | 0.16568–0.16573 | 2.45× / 30.6% | 18.13 | 2.04 | 15.29 |
| Uniform | 1 / 1 | 0.61845 | 0.61829–0.61847 | 1.00× / 100.0% | 37.20 | 3.90 | 3.90 |
| Uniform | 4 / 1 | 0.27922 | 0.27915–0.27946 | 2.21× / 55.4% | 25.78 | 3.49 | 12.23 |
| Uniform | 12 / 1 | 0.16022 | 0.16020–0.16024 | 3.86× / 32.2% | 21.55 | 2.84 | 33.04 |
| Uniform | 24 / 2 | 0.15143 | 0.15138–0.15148 | 4.08× / 17.0% | 21.14 | 2.74 | 32.53 |

Each row has three repeats of the same 32-step problem; four warmup steps
are excluded from the critical-rank steady window. Speedup uses that problem’s
one-rank median. Both nodes were allocated for this sweep; “used nodes” follows
the explicit ranks-per-node launch. The two eight-rank mixed rows isolate
placement. Node memory is the sum of individual rank peaks under the verified
PALS contiguous placement, an upper bound rather than simultaneous RSS.

![Strong scaling](plots/strong-scaling.png)
