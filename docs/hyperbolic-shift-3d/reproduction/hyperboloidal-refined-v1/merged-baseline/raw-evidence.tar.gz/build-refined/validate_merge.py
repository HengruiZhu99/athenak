from pathlib import Path
import subprocess,json,hashlib,time,shutil
root=Path.cwd();out=root/'build-refined/merged';out.mkdir(exist_ok=False)
bin=root/'build-refined/local/tst/hyperbolic_shift_3d'
records=[]
def run(name,cmd,expected=0):
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as f:r=subprocess.run(list(map(str,cmd)),stdout=f,stderr=subprocess.STDOUT,timeout=420)
 records.append(dict(name=name,command=list(map(str,cmd)),returncode=r.returncode,seconds=time.monotonic()-start));(out/'commands.json').write_text(json.dumps(records,indent=2))
 assert r.returncode==expected,(name,r.returncode)
 print(name,'passed',flush=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
run('normalized-oracle',[bin/'hyperbolic_shift_3d_normalized_inner_shift'])
bn=bin/'hyperbolic_shift_3d_mpi_native_control_broad_smooth_six_shells_boosted_free_gauge_refined_core_matched_cfl_normalized_shift'
run('bn1',['mpiexec','-n','2',bn,16,out/'bn1','puncture','.0005','.00025','-','-',300,'.05','.001',12,24,2])
prior=Path('/Users/hz0693/.codex/worktrees/hyperbolic-core-shell/hyperboloidal/output/boosted-normalized-shift/serial/puncture.checkpoint')
checks=[dict(case='bn1',reference=str(prior),actual_sha256=sha(out/'bn1.checkpoint'),reference_sha256=sha(prior))]
for name,kind,policy,ref,expected in [('amr-wave','wave','dynamic','final-check/final-wave',0),('amr-boost','boost','fixed','final-check/fixed-boost-final',0),('amr-reject','boost','dynamic','final-check/rejected-m4',2)]:
 run(name,['mpiexec','-n','2',bin/'hyperbolic_shift_3d_amr_evolution',12,kind,6,'.00025',out/name,'-',policy],expected)
 base=Path('/Users/hz0693/.codex/worktrees/hyperboloidal-performance-scaling/hyperboloidal/build-performance')/ref
 for suffix in (['checkpoint','history.jsonl'] if expected==0 else ['history.jsonl','failed-stage.bin','rejected-transfer.bin','failure.json']):
  a=out/(name+'.'+suffix);b=Path(str(base)+'.'+suffix);checks.append(dict(case=name,artifact=suffix,reference=str(b),actual_sha256=sha(a),reference_sha256=sha(b)))
(out/'comparisons.json').write_text(json.dumps(checks,indent=2))
assert all(x['actual_sha256']==x['reference_sha256'] for x in checks),checks
run('amr-interfaces',['ctest','--test-dir',root/'build-refined/local','--output-on-failure','-R','^hyperbolic_shift_3d_amr_(transfer_mpi[124]|operators)$'])
(out/'completed.json').write_text(json.dumps(dict(passed=True,bytewise_checks=len(checks))))
