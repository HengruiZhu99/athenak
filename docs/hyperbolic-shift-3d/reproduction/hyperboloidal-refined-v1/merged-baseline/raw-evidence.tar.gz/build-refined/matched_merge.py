from pathlib import Path
import subprocess,json,hashlib,os,time
root=Path.cwd();out=root/'build-refined/merged';bin=root/'build-refined/local/tst/hyperbolic_shift_3d';records=[];checks=[]
for name,ranks,kind,policy,reference in [('amr-wave-matched',4,'wave','dynamic','final-wave'),('amr-boost-matched',1,'boost','fixed','fixed-boost-final')]:
 cmd=['mpiexec','-n',str(ranks),str(bin/'hyperbolic_shift_3d_amr_evolution'),'12',kind,'6','.00025',str(out/name),'-',policy];start=time.monotonic()
 with (out/(name+'.log')).open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,HYPERBOLIC_SPARSE_POISON='1'),timeout=300)
 assert r.returncode==0;records.append(dict(command=cmd,returncode=r.returncode,seconds=time.monotonic()-start))
 for suffix in ['checkpoint','history.jsonl']:
  a=out/(name+'.'+suffix);b=Path('/Users/hz0693/.codex/worktrees/hyperboloidal-performance-scaling/hyperboloidal/build-performance/final-check')/(reference+'.'+suffix)
  ah=hashlib.sha256(a.read_bytes()).hexdigest();bh=hashlib.sha256(b.read_bytes()).hexdigest();checks.append(dict(case=name,artifact=suffix,actual_sha256=ah,reference_sha256=bh));assert ah==bh
(out/'matched-comparisons.json').write_text(json.dumps(checks,indent=2));(out/'matched-commands.json').write_text(json.dumps(records,indent=2))
with (out/'amr-interfaces.log').open('w') as f:r=subprocess.run(['ctest','--test-dir',str(root/'build-refined/local'),'--output-on-failure','-R','^hyperbolic_shift_3d_amr_(transfer_mpi[124]|operators)$'],stdout=f,stderr=subprocess.STDOUT,timeout=600)
assert r.returncode==0
(out/'completed.json').write_text(json.dumps(dict(passed=True,bn1_bitwise=True,amr_bitwise=True,interfaces=True,cross_rank_diagnostics='H/M reduction roundoff and existing rank-zero CFL reporting; exact matched-rank rerun recorded')))
print('Merged baseline qualification passed.',flush=True)
