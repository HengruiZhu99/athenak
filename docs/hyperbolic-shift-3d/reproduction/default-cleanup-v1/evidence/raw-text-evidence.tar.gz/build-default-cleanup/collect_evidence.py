"""Package text evidence; keep large binaries/checkpoints local with SHA-256 bindings."""
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

root = Path.cwd()
work = root / 'build-default-cleanup'
destination = root / 'docs/hyperbolic-shift-3d/reproduction/default-cleanup-v1/evidence'
assert json.loads((work / 'evidence/completed.json').read_text())['passed']
destination.mkdir(parents=True, exist_ok=True)

def digest(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(chunk)
    return result.hexdigest()

# These comparisons bind the post-cleanup source to the binaries that ran.
sources = json.loads((work / 'evidence/source-and-definitions.json').read_text())
for name, expected in sources['source_sha256'].items():
    assert digest(root / name) == expected, name

manifest = {}
for folder in ('amr', 'checkpoint-rejection', 'transaction', 'sparse', 'frozen'):
    directory = work / folder
    if directory.exists():
        for path in sorted(directory.rglob('*')):
            if path.is_file():
                manifest[str(path.relative_to(root))] = {
                    'bytes': path.stat().st_size, 'sha256': digest(path)
                }
# The transaction executable writes prefix-based outputs beside these folders.
for path in sorted(work.glob('transaction.*')):
    if path.is_file():
        manifest[str(path.relative_to(root))] = {
            'bytes': path.stat().st_size, 'sha256': digest(path)
        }
for name in ('hyperbolic_shift_3d_amr_evolution', 'hyperbolic_shift_3d_amr_setup_contract',
             'hyperbolic_shift_3d_mesh_plan_bundle', 'hyperbolic_shift_3d_repartition_transaction',
             'hyperbolic_shift_3d_mpi_continuous_positive_sparse'):
    path = root / 'build-performance/candidate/tst/hyperbolic_shift_3d' / name
    manifest[str(path.relative_to(root))] = {
        'bytes': path.stat().st_size, 'sha256': digest(path)
    }
initial = root / 'build-performance/qualification/puncture-n16.txt'
manifest[str(initial.relative_to(root))] = {'bytes': initial.stat().st_size, 'sha256': digest(initial)}
(destination / 'artifacts.json').write_text(json.dumps(manifest, indent=2) + '\n')
for name in ('completed.json', 'bitwise.json', 'commands.json', 'source-and-definitions.json',
             'frozen.json', 'static-checks.json', 'replay-guard.json'):
    shutil.copy2(work / 'evidence' / name, destination / name)

# Logs and raw histories are portable; large numerical payloads remain hash-bound.
with tarfile.open(destination / 'raw-text-evidence.tar.gz', 'w:gz') as archive:
    for path in sorted(work.rglob('*')):
        if path.is_file() and path.suffix in ('.json', '.jsonl', '.log', '.py', '.csv'):
            archive.add(path, arcname=str(path.relative_to(root)), recursive=False)
    for name in ('formatter-version.txt', 'targets.txt'):
        path = work / 'evidence' / name
        archive.add(path, arcname=str(path.relative_to(root)), recursive=False)

bindings = {path.name: digest(path) for path in sorted(destination.iterdir())
            if path.is_file() and path.name != 'SHA256SUMS'}
(destination / 'SHA256SUMS').write_text(''.join(f'{value}  {name}\n' for name, value in bindings.items()))
print(f'Packaged {len(manifest)} artifact bindings into {destination}')
