#include "z4c/hyperboloidal/native_composite_evolution.hpp"
//========================================================================================
// AthenaXXX astrophysical plasma code
// Copyright(C) 2020 James M. Stone <jmstone@ias.edu> and the Athena code team
// Licensed under the 3-clause BSD License (the "LICENSE")
//========================================================================================
//! \fn TaskStatus Z4c::CalcRHS
//! \brief Computes the wave equation RHS

#include <math.h>

#include <cmath>

//#include <algorithm>
//#include <cinttypes>
#include <iostream>
//#include <limits>

#include "athena.hpp"
#include "mesh/mesh.hpp"
#include "mesh/cubed_sphere/derivatives.hpp"
#include "coordinates/adm.hpp"
#include "z4c/z4c.hpp"
#include "z4c/hyperboloidal/cartesian_patch.hpp"
#include "z4c/driftcontrol/driftcontrol.hpp"
#include "z4c/tmunu.hpp"
#include "coordinates/cell_locations.hpp"

namespace z4c {

template <int NGHOST>
//! \fn void Z4c::CalcRHS(Driver *pdriver, int stage)
//! \brief compute rhs of the z4c equations
TaskStatus Z4c::CalcRHS(Driver *pdriver, int stage) {
  if (native_composite) {native_composite->EvaluateRHS(pdriver,stage);return TaskStatus::complete;}
  if (hyperboloidal_patch) {
    hyperboloidal_patch->RHS(u0,u_rhs);
    return TaskStatus::complete;
  }
  auto &indcs = pmy_pack->pmesh->mb_indcs;
  auto &size = pmy_pack->pmb->mb_size;
  auto geometry = pmy_pack->pcoord->z4c_geometry;
  int &is = indcs.is; int &ie = indcs.ie;
  int &js = indcs.js; int &je = indcs.je;
  int &ks = indcs.ks; int &ke = indcs.ke;

  int nmb = pmy_pack->nmb_thispack;

  auto &z4c = pmy_pack->pz4c->z4c;
  auto &rhs = pmy_pack->pz4c->rhs;
  auto &opt = pmy_pack->pz4c->opt;

  Real time = pmy_pack->pmesh->time;

  // Drift control (optional)
  int nx1 = indcs.nx1, nx2 = indcs.nx2, nx3 = indcs.nx3;
  bool dc_on        = opt.enable_driftcontrol;
  int  dc_variety   = opt.dc_variety;
  Real dc_inv_s2    = 0.0;             // 1/damping_scale^2
  Real dc_inv_tau[3] = {0.0, 0.0, 0.0}; // relaxation rate, per axis
  Real dc_c[3]      = {0.0, 0.0, 0.0};  // centre of the Gaussian weight
  Real dc_corr[3]   = {0.0, 0.0, 0.0};  // oscillator/PID shift RHS increment
  Real dc_target[3] = {0.0, 0.0, 0.0};  // relaxation target shift
  Real dc_gsupp[3]  = {0.0, 0.0, 0.0};  // relaxation Gamma-driver suppression

  if (dc_on) {
    DriftControl *pdc = pmy_pack->pz4c->pdrift_control.get();
    Real const fixed[3] = {opt.dc_fixed_x, opt.dc_fixed_y, opt.dc_fixed_z};
    dc_inv_s2 = 1.0 / SQR(opt.dc_damping_scale);

    for (int a = 0; a < 3; ++a) {
      dc_c[a] = (opt.dc_gaussian_center == DriftControl::CenterTracker)
              ? pdc->GetPos(a) : fixed[a];
    }

    if (dc_variety == DriftControl::Relaxation) {
      for (int a = 0; a < 3; ++a) {
        dc_inv_tau[a] = 1.0 / opt.dc_relaxation_time;
        Real const e = pdc->GetPos(a) - fixed[a];
        dc_target[a] = opt.dc_kappa * e;
        if (opt.dc_gamma_suppress > 0.0) {
          Real const sc = 1.0 / (1.0 + opt.dc_gamma_suppress
                                    * Kokkos::fabs(e) / opt.dc_damping_scale);
          dc_gsupp[a] = opt.shift_ggamma * (1.0 - sc);
        }
      }
    } else if (dc_variety == DriftControl::PID) {
      for (int a = 0; a < 3; ++a) {
        Real const e = pdc->GetPos(a) - fixed[a];
        dc_corr[a] = -(opt.dc_Kp * e + opt.dc_Ki * pdc->GetIntegral(a)
                     + opt.dc_Kd * pdc->GetVel(a));
      }
    } else if (dc_variety == DriftControl::BDOB) {
      for (int a = 0; a < 3; ++a) {
        dc_corr[a] = -pdc->GetU(a);
      }
    } else if (dc_variety == DriftControl::DOB) {
      Real const wc2  = SQR(opt.dc_omega_c);
      Real const twzc = 2.0 * opt.dc_zeta * opt.dc_omega_c;
      for (int a = 0; a < 3; ++a) {
        Real const e    = pdc->GetPos(a) - fixed[a];
        Real const v    = pdc->GetVel(a);
        Real const fhat = pdc->GetP(a) + opt.dc_omega_o * v;
        dc_corr[a] = -(wc2 * e + twzc * v + fhat);
      }
    } else {
      Real const tau      = opt.dc_damping_time;
      Real const zeta     = opt.dc_damping_coeff;
      Real const inv_tau2 = 1.0 / SQR(tau);
      for (int a = 0; a < 3; ++a) {
        dc_corr[a] = -(2.0 * tau * zeta * pdc->GetVel(a)
                     + (pdc->GetPos(a) - fixed[a])) * inv_tau2;
      }
    }

    if (dc_variety != DriftControl::BDOB) {
      // Per-axis gain on the applied correction.
      Real const dc_gain[3] = {opt.dc_gain_x, opt.dc_gain_y, opt.dc_gain_z};
      for (int a = 0; a < 3; ++a) {
        dc_corr[a]    *= dc_gain[a];
        dc_gsupp[a]   *= dc_gain[a];
        dc_inv_tau[a] *= dc_gain[a];
      }

      // Optional ramp-down, applied to everything the controller injects. The factor is
      // 1 unless dc_ramp_start >= 0, so this is a no-op for every existing parfile.
      Real const dc_ramp = pdc->RampFactor(time);
      if (dc_ramp < 1.0) {
        for (int a = 0; a < 3; ++a) {
          dc_corr[a]    *= dc_ramp;
          dc_gsupp[a]   *= dc_ramp;
          dc_inv_tau[a] *= dc_ramp;
        }
      }
    }
  }

  bool is_vacuum = (pmy_pack->ptmunu == nullptr) ? true : false;
  Tmunu::Tmunu_vars tmunu;
  if (!is_vacuum) tmunu = pmy_pack->ptmunu->tmunu;

  // ===================================================================================
  // Main RHS calculation
  //
  // Keep geometry, connection and gauge scratch separate to reduce device register
  // pressure. These kernels read the same RK-stage state and write disjoint RHS fields.
  par_for("z4c geometry rhs loop",DevExeSpace(),0,nmb-1,ks,ke,js,je,is,ie,
  KOKKOS_LAMBDA(const int m, const int k, const int j, const int i) {
    // Define scratch arrays to be used in the following calculations

    // Gamma computed from the metric
    AthenaPointTensor<Real, TensorSymm::NONE, 3, 1> Gamma_u;

    // inverse of conf. metric
    AthenaPointTensor<Real, TensorSymm::SYM2, 3, 2> g_uu;
    // g^cd A_ac A_db
    AthenaPointTensor<Real, TensorSymm::SYM2, 3, 2> AA_dd;
    // Ricci tensor
    AthenaPointTensor<Real, TensorSymm::SYM2, 3, 2> R_dd;
    // Ricci tensor, conformal contribution
    AthenaPointTensor<Real, TensorSymm::SYM2, 3, 2> Rphi_dd;
    // 2nd differential of the lapse
    AthenaPointTensor<Real, TensorSymm::SYM2, 3, 2> Ddalpha_dd;
    // 2nd differential of phi
    AthenaPointTensor<Real, TensorSymm::SYM2, 3, 2> Ddphi_dd;

    // Christoffel symbols of 1st kind
    AthenaPointTensor<Real, TensorSymm::SYM2, 3, 3> Gamma_ddd;
    // Christoffel symbols of 2nd kind
    AthenaPointTensor<Real, TensorSymm::SYM2, 3, 3> Gamma_udd;

    // auxiliary derivatives

    // lapse 1st drvts
    AthenaPointTensor<Real, TensorSymm::NONE, 3, 1> dalpha_d;
    // chi 1st drvts
    AthenaPointTensor<Real, TensorSymm::NONE, 3, 1> dchi_d;
    // phi 1st drvts
    AthenaPointTensor<Real, TensorSymm::NONE, 3, 1> dphi_d;

    // lapse 2nd drvts
    AthenaPointTensor<Real, TensorSymm::SYM2, 3, 2> ddalpha_dd;
    // shift 1st drvts
    AthenaPointTensor<Real, TensorSymm::NONE, 3, 2> dbeta_du;
    // chi 2nd drvts
    AthenaPointTensor<Real, TensorSymm::SYM2, 3, 2> ddchi_dd;
    // Gamma 1st drvts
    AthenaPointTensor<Real, TensorSymm::NONE, 3, 2> dGam_du;

    // metric 1st drvts
    AthenaPointTensor<Real, TensorSymm::SYM2,  3, 3> dg_ddd;

    // metric 2nd drvts
    AthenaPointTensor<Real, TensorSymm::SYM22, 3, 4> ddg_dddd;


    // Lie derivative of conf. 3-metric
    AthenaPointTensor<Real, TensorSymm::SYM2, 3, 2> Lg_dd;
    // Lie derivative of A
    AthenaPointTensor<Real, TensorSymm::SYM2, 3, 2> LA_dd;

    auto idx = cubed_sphere::MakeStencil(geometry,size.d_view(m),indcs,m,k,j,i);

    // -----------------------------------------------------------------------------------
    // Initialize everything to zero
    //
    // Scalars

    // auxiliary Lie derivatives along the shift vector
    // Lie derivative of chi
    Real Lchi = 0.0;
    // Lie derivative of Khat
    Real LKhat = 0.0;
    // Lie derivative of Theta
    Real LTheta = 0.0;

    // determinant of three metric
    Real detg = 0.0;
    // bounded version of chi
    Real chi_guarded = 0.0;
    // 1/psi4
    Real oopsi4 = 0.0;
    // trace of A
    Real AA = 0.0;
    // Ricci scalar
    Real R = 0.0;
    // tilde H
    Real Ht = 0.0;
    // trace of extrinsic curvature
    Real K = 0.0;
    // Trace of S_ik
    Real S = 0.0;
    // Trace of Ddalpha_dd
    Real Ddalpha = 0.0;

    // d_a beta^a
    Real dbeta = 0.0;

    //
    // Vectors
    Gamma_u.ZeroClear();

    //
    // Symmetric tensors
    Lg_dd.ZeroClear();
    LA_dd.ZeroClear();
    AA_dd.ZeroClear();
    R_dd.ZeroClear();
    Gamma_udd.ZeroClear();

    // -----------------------------------------------------------------------------------
    // 1st derivatives
    //
    // Scalars
    for(int a = 0; a < 3; ++a) {
      dalpha_d(a) = Dx<NGHOST>(a, idx, z4c.alpha, m,k,j,i);
      dchi_d  (a) = Dx<NGHOST>(a, idx, z4c.chi,   m,k,j,i);
    }

    // Vectors
    for(int a = 0; a < 3; ++a)
    for(int b = 0; b < 3; ++b) {
      dbeta_du(b,a) = Dx<NGHOST>(b, idx, z4c.beta_u, m,a,k,j,i);
      dGam_du(b,a) = Dx<NGHOST>(b, idx, z4c.vGam_u,  m,a,k,j,i);
    }

    // Tensors
    for(int a = 0; a < 3; ++a)
    for(int b = a; b < 3; ++b)
    for(int c = 0; c < 3; ++c) {
      dg_ddd(c,a,b) = Dx<NGHOST>(c, idx, z4c.g_dd, m,a,b,k,j,i);
    }

    // -----------------------------------------------------------------------------------
    // 2nd derivatives
    //
    // Scalars
    for(int a = 0; a < 3; ++a) {
      ddalpha_dd(a,a) = Dxx<NGHOST>(a, idx, z4c.alpha, m,k,j,i);
      ddchi_dd(a,a) = Dxx<NGHOST>(a, idx, z4c.chi,   m,k,j,i);

      for(int b = a + 1; b < 3; ++b) {
        ddalpha_dd(a,b) = Dxy<NGHOST>(a, b, idx, z4c.alpha, m,k,j,i);
        ddchi_dd(a,b) = Dxy<NGHOST>(a, b, idx, z4c.chi,   m,k,j,i);
      }
    }

    // Tensors
    for(int c = 0; c < 3; ++c)
    for(int d = c; d < 3; ++d)
    for(int a = 0; a < 3; ++a) {
      ddg_dddd(a,a,c,d) = Dxx<NGHOST>(a, idx, z4c.g_dd, m,c,d,k,j,i);
      for(int b = a + 1; b < 3; ++b) {
        ddg_dddd(a,b,c,d) = Dxy<NGHOST>(a, b, idx, z4c.g_dd, m,c,d,k,j,i);
      }
    }

    // -----------------------------------------------------------------------------------
    // Advective derivatives
    //

    //
    // Scalars
    for(int a = 0; a < 3; ++a) {
      Lchi   += Lx<NGHOST>(a, idx, z4c.beta_u, z4c.chi,   m,a,k,j,i);
      LKhat  += Lx<NGHOST>(a, idx, z4c.beta_u, z4c.vKhat,  m,a,k,j,i);
      LTheta += Lx<NGHOST>(a, idx, z4c.beta_u, z4c.vTheta, m,a,k,j,i);
    }

    //
    // Vectors

    //
    // Tensors
    for(int a = 0; a < 3; ++a)
    for(int b = a; b < 3; ++b)
    for(int c = 0; c < 3; ++c) {
      Lg_dd(a,b) += Lx<NGHOST>(c, idx, z4c.beta_u, z4c.g_dd, m,c,a,b,k,j,i);
      LA_dd(a,b) += Lx<NGHOST>(c, idx, z4c.beta_u, z4c.vA_dd, m,c,a,b,k,j,i);
    }

    // -----------------------------------------------------------------------------------
    // Get K from Khat
    //
    K = z4c.vKhat(m,k,j,i) + 2.*z4c.vTheta(m,k,j,i);

    // -----------------------------------------------------------------------------------
    // Inverse metric

    detg = adm::SpatialDet(z4c.g_dd(m,0,0,k,j,i), z4c.g_dd(m,0,1,k,j,i),
                              z4c.g_dd(m,0,2,k,j,i), z4c.g_dd(m,1,1,k,j,i),
                              z4c.g_dd(m,1,2,k,j,i), z4c.g_dd(m,2,2,k,j,i));
    adm::SpatialInv(1.0/detg,
               z4c.g_dd(m,0,0,k,j,i), z4c.g_dd(m,0,1,k,j,i), z4c.g_dd(m,0,2,k,j,i),
               z4c.g_dd(m,1,1,k,j,i), z4c.g_dd(m,1,2,k,j,i), z4c.g_dd(m,2,2,k,j,i),
               &g_uu(0,0), &g_uu(0,1), &g_uu(0,2),
               &g_uu(1,1), &g_uu(1,2), &g_uu(2,2));

    // -----------------------------------------------------------------------------------
    // Christoffel symbols

    for(int c = 0; c < 3; ++c)
    for(int a = 0; a < 3; ++a)
    for(int b = a; b < 3; ++b) {
      Gamma_ddd(c,a,b) = 0.5*(dg_ddd(a,b,c) + dg_ddd(b,a,c) - dg_ddd(c,a,b));
    }
    for(int c = 0; c < 3; ++c)
    for(int a = 0; a < 3; ++a)
    for(int b = a; b < 3; ++b)
    for(int d = 0; d < 3; ++d) {
      Gamma_udd(c,a,b) += g_uu(c,d)*Gamma_ddd(d,a,b);
    }
    // Gamma's computed from the conformal metric (not evolved)
    for(int a = 0; a < 3; ++a)
    for(int b = 0; b < 3; ++b)
    for(int c = 0; c < 3; ++c) {
      Gamma_u(a) += g_uu(b,c)*Gamma_udd(a,b,c);
    }

    // -----------------------------------------------------------------------------------
    // Curvature of conformal metric
    //
    for(int a = 0; a < 3; ++a)
    for(int b = a; b < 3; ++b) {
      for(int c = 0; c < 3; ++c) {
        R_dd(a,b) += 0.5*(z4c.g_dd(m,c,a,k,j,i)*dGam_du(b,c) +
                          z4c.g_dd(m,c,b,k,j,i)*dGam_du(a,c) +
                          Gamma_u(c)*(Gamma_ddd(a,b,c) + Gamma_ddd(b,a,c)));
      }
      for(int c = 0; c < 3; ++c)
      for(int d = 0; d < 3; ++d) {
        R_dd(a,b) -= 0.5*g_uu(c,d)*ddg_dddd(c,d,a,b);
      }
      for(int c = 0; c < 3; ++c)
      for(int d = 0; d < 3; ++d)
      for(int e = 0; e < 3; ++e) {
        R_dd(a,b) += g_uu(c,d)*(
            Gamma_udd(e,c,a)*Gamma_ddd(b,e,d) +
            Gamma_udd(e,c,b)*Gamma_ddd(a,e,d) +
            Gamma_udd(e,a,d)*Gamma_ddd(e,c,b));
      }
    }

    // -----------------------------------------------------------------------------------
    // Derivatives of conformal factor phi
    //
    chi_guarded = (z4c.chi(m,k,j,i)>opt.chi_div_floor)
                    ? z4c.chi(m,k,j,i) : opt.chi_div_floor;
    oopsi4 = pow(chi_guarded, -4./opt.chi_psi_power);
    for(int a = 0; a < 3; ++a) {
      dphi_d(a) = dchi_d(a)/(chi_guarded * opt.chi_psi_power);
    }
    for(int a = 0; a < 3; ++a)
    for(int b = a; b < 3; ++b) {
      Ddphi_dd(a,b) = ddchi_dd(a,b)/(chi_guarded * opt.chi_psi_power) -
        opt.chi_psi_power * dphi_d(a) * dphi_d(b);
      for(int c = 0; c < 3; ++c) {
        Ddphi_dd(a,b) -= Gamma_udd(c,a,b)*dphi_d(c);
      }
    }

    // -----------------------------------------------------------------------------------
    // Curvature contribution from conformal factor
    //
    for(int a = 0; a < 3; ++a)
    for(int b = a; b < 3; ++b) {
      Rphi_dd(a,b) = 4.*dphi_d(a)*dphi_d(b) - 2.*Ddphi_dd(a,b);
      for(int c = 0; c < 3; ++c)
      for(int d = 0; d < 3; ++d) {
        Rphi_dd(a,b) -= 2.*z4c.g_dd(m,a,b,k,j,i) * g_uu(c,d)*(Ddphi_dd(c,d) +
            2.*dphi_d(c)*dphi_d(d));
      }
    }

    // -----------------------------------------------------------------------------------
    // Trace of the matter stress tensor
    //
    if(!is_vacuum) {
      for (int a = 0; a < 3; ++a)
      for (int b = 0; b < 3; ++b) {
        S += oopsi4 * g_uu(a,b) * tmunu.S_dd(m,a,b,k,j,i);
      }
    }

    // -----------------------------------------------------------------------------------
    // 2nd covariant derivative of the lapse
    // TODO(JMF): This could potentially be sped up by calculating d_i phi d^i alpha
    // beforehand.
    for(int a = 0; a < 3; ++a)
    for(int b = 0; b < 3; ++b) {
      Ddalpha_dd(a,b) = ddalpha_dd(a,b)
                       - 2.*(dphi_d(a)*dalpha_d(b) + dphi_d(b)*dalpha_d(a));
      for(int c = 0; c < 3; ++c) {
        Ddalpha_dd(a,b) -= Gamma_udd(c,a,b)*dalpha_d(c);
        for(int d = 0; d < 3; ++d) {
            Ddalpha_dd(a,b) += 2.*z4c.g_dd(m,a,b,k,j,i) * g_uu(c,d)
            * dphi_d(c) * dalpha_d(d);
        }
      }
    }

    for(int a = 0; a < 3; ++a)
    for(int b = 0; b < 3; ++b) {
      Ddalpha += oopsi4 * g_uu(a,b) * Ddalpha_dd(a,b);
    }

    // -----------------------------------------------------------------------------------
    // Contractions of A_ab, inverse, and derivatives
    //
    for(int a = 0; a < 3; ++a)
    for(int b = a; b < 3; ++b)
    for(int c = 0; c < 3; ++c)
    for(int d = 0; d < 3; ++d) {
      AA_dd(a,b) += g_uu(c,d) * z4c.vA_dd(m,a,c,k,j,i) * z4c.vA_dd(m,d,b,k,j,i);
    }
    for(int a = 0; a < 3; ++a)
    for(int b = 0; b < 3; ++b) {
      AA += g_uu(a,b) * AA_dd(a,b);
    }
    // -----------------------------------------------------------------------------------
    // Ricci scalar
    //
    for(int a = 0; a < 3; ++a)
    for(int b = 0; b < 3; ++b) {
      R += oopsi4 * g_uu(a,b) * (R_dd(a,b) + Rphi_dd(a,b));
    }

    // -----------------------------------------------------------------------------------
    // Hamiltonian constraint
    //
    // Note that the matter term is *not* included here; this is included explicitly when
    // calculating d_t \Theta.
    Ht = R + (2./3.)*SQR(K) - AA;// - 16.*M_PI*tmunu.E(m,k,j,i);

    // -----------------------------------------------------------------------------------
    // Finalize advective (Lie) derivatives
    //
    // Shift vector contractions
    for(int a = 0; a < 3; ++a) {
      dbeta += dbeta_du(a,a);
    }

    // Finalize Lchi
    Lchi += (1./6.) * opt.chi_psi_power * chi_guarded * dbeta;

    // Finalize Lg_dd and LA_dd
    for(int a = 0; a < 3; ++a)
    for(int b = a; b < 3; ++b) {
      Lg_dd(a,b) -= (2./3.) * z4c.g_dd(m,a,b,k,j,i) * dbeta;
      for(int c = 0; c < 3; ++c) {
        Lg_dd(a,b) += dbeta_du(a,c) * z4c.g_dd(m,b,c,k,j,i);
        Lg_dd(a,b) += dbeta_du(b,c) * z4c.g_dd(m,a,c,k,j,i);
      }
    }
    for(int a = 0; a < 3; ++a)
    for(int b = a; b < 3; ++b) {
      LA_dd(a,b) -= (2./3.) * z4c.vA_dd(m,a,b,k,j,i) * dbeta;
      for(int c = 0; c < 3; ++c) {
        LA_dd(a,b) += dbeta_du(b,c) * z4c.vA_dd(m,a,c,k,j,i);
        LA_dd(a,b) += dbeta_du(a,c) * z4c.vA_dd(m,b,c,k,j,i);
      }
    }

    // -----------------------------------------------------------------------------------
    // Assemble RHS
    //
    // Khat, chi, and Theta
    rhs.vKhat(m,k,j,i) = - Ddalpha + z4c.alpha(m,k,j,i)
      * (AA + (1./3.)*SQR(K)) +
      LKhat + opt.damp_kappa1*(1 - opt.damp_kappa2)
      * z4c.alpha(m,k,j,i) * z4c.vTheta(m,k,j,i);
    // Matter term
    if(!is_vacuum) {
      rhs.vKhat(m,k,j,i) += 4.*M_PI * z4c.alpha(m,k,j,i) * (S + tmunu.E(m,k,j,i));
    }
    rhs.chi(m,k,j,i) = Lchi - (1./6.) * opt.chi_psi_power *
      chi_guarded * z4c.alpha(m,k,j,i) * K;
    rhs.vTheta(m,k,j,i) = LTheta + z4c.alpha(m,k,j,i) * (
        0.5*Ht - (2. + opt.damp_kappa2) * opt.damp_kappa1 * z4c.vTheta(m,k,j,i));
    // Matter term
    if(!is_vacuum) {
      rhs.vTheta(m,k,j,i) -= 8.*M_PI * z4c.alpha(m,k,j,i) * tmunu.E(m,k,j,i);
    }
    // If BSSN is enabled, theta is disabled.
    rhs.vTheta(m,k,j,i) *= opt.use_z4c;
    // g and A
    for(int a = 0; a < 3; ++a)
    for(int b = a; b < 3; ++b) {
      rhs.g_dd(m,a,b,k,j,i) = - 2. * z4c.alpha(m,k,j,i) * z4c.vA_dd(m,a,b,k,j,i)
                      + Lg_dd(a,b);
      rhs.vA_dd(m,a,b,k,j,i) = oopsi4 *
          (-Ddalpha_dd(a,b) + z4c.alpha(m,k,j,i) * (R_dd(a,b) + Rphi_dd(a,b)));
      rhs.vA_dd(m,a,b,k,j,i) -= (1./3.) * z4c.g_dd(m,a,b,k,j,i)
                             * (-Ddalpha + z4c.alpha(m,k,j,i)*R);
      rhs.vA_dd(m,a,b,k,j,i) += z4c.alpha(m,k,j,i) * (K*z4c.vA_dd(m,a,b,k,j,i)
                             - 2.*AA_dd(a,b));
      rhs.vA_dd(m,a,b,k,j,i) += LA_dd(a,b);
      // Matter term
      if(!is_vacuum) {
        rhs.vA_dd(m,a,b,k,j,i) -= 8.*M_PI * z4c.alpha(m,k,j,i) *
                (oopsi4*tmunu.S_dd(m,a,b,k,j,i) - (1./3.)*S*z4c.g_dd(m,a,b,k,j,i));
      }
    }
  });

  par_for("z4c Gamma rhs loop",DevExeSpace(),0,nmb-1,ks,ke,js,je,is,ie,
  KOKKOS_LAMBDA(const int m, const int k, const int j, const int i) {
    AthenaPointTensor<Real, TensorSymm::NONE, 3, 1> Gamma_u, DA_u, LGam_u, ddbeta_d;
    AthenaPointTensor<Real, TensorSymm::NONE, 3, 1> dalpha_d, dchi_d, dKhat_d, dTheta_d;
    AthenaPointTensor<Real, TensorSymm::SYM2, 3, 2> g_uu, A_uu;
    AthenaPointTensor<Real, TensorSymm::NONE, 3, 2> dbeta_du;
    AthenaPointTensor<Real, TensorSymm::SYM2, 3, 3> Gamma_ddd, Gamma_udd, dg_ddd;
    AthenaPointTensor<Real, TensorSymm::ISYM2, 3, 3> ddbeta_ddu;
    auto idx = cubed_sphere::MakeStencil(geometry,size.d_view(m),indcs,m,k,j,i);
    Real detg = 0.0, dbeta = 0.0;
    Real chi_guarded = fmax(z4c.chi(m,k,j,i),opt.chi_div_floor);
    Gamma_u.ZeroClear();
    DA_u.ZeroClear();
    LGam_u.ZeroClear();
    ddbeta_d.ZeroClear();
    A_uu.ZeroClear();
    Gamma_udd.ZeroClear();
    for (int a=0; a<3; ++a) {
      dalpha_d(a) = Dx<NGHOST>(a, idx, z4c.alpha, m,k,j,i);
      dchi_d(a) = Dx<NGHOST>(a, idx, z4c.chi, m,k,j,i);
      dKhat_d(a) = Dx<NGHOST>(a, idx, z4c.vKhat, m,k,j,i);
      dTheta_d(a) = Dx<NGHOST>(a, idx, z4c.vTheta, m,k,j,i);
      for (int b=0; b<3; ++b) {
        dbeta_du(b,a) = Dx<NGHOST>(b, idx, z4c.beta_u, m,a,k,j,i);
        LGam_u(b) += Lx<NGHOST>(a, idx, z4c.beta_u, z4c.vGam_u, m,a,b,k,j,i);
      }
    }
    // Tensors
    for(int a = 0; a < 3; ++a)
    for(int b = a; b < 3; ++b)
    for(int c = 0; c < 3; ++c) {
      dg_ddd(c,a,b) = Dx<NGHOST>(c, idx, z4c.g_dd, m,a,b,k,j,i);
    }

    // Vectors
    for(int c = 0; c < 3; ++c)
    for(int a = 0; a < 3; ++a) {
      ddbeta_ddu(a,a,c) = Dxx<NGHOST>(a, idx, z4c.beta_u, m,c,k,j,i);
      for(int b = a + 1; b < 3; ++b) {
        ddbeta_ddu(a,b,c) = Dxy<NGHOST>(a, b, idx, z4c.beta_u, m,c,k,j,i);
      }
    }

    detg = adm::SpatialDet(z4c.g_dd(m,0,0,k,j,i), z4c.g_dd(m,0,1,k,j,i),
                              z4c.g_dd(m,0,2,k,j,i), z4c.g_dd(m,1,1,k,j,i),
                              z4c.g_dd(m,1,2,k,j,i), z4c.g_dd(m,2,2,k,j,i));
    adm::SpatialInv(1.0/detg,
               z4c.g_dd(m,0,0,k,j,i), z4c.g_dd(m,0,1,k,j,i), z4c.g_dd(m,0,2,k,j,i),
               z4c.g_dd(m,1,1,k,j,i), z4c.g_dd(m,1,2,k,j,i), z4c.g_dd(m,2,2,k,j,i),
               &g_uu(0,0), &g_uu(0,1), &g_uu(0,2),
               &g_uu(1,1), &g_uu(1,2), &g_uu(2,2));

    for(int c = 0; c < 3; ++c)
    for(int a = 0; a < 3; ++a)
    for(int b = a; b < 3; ++b) {
      Gamma_ddd(c,a,b) = 0.5*(dg_ddd(a,b,c) + dg_ddd(b,a,c) - dg_ddd(c,a,b));
    }
    for(int c = 0; c < 3; ++c)
    for(int a = 0; a < 3; ++a)
    for(int b = a; b < 3; ++b)
    for(int d = 0; d < 3; ++d) {
      Gamma_udd(c,a,b) += g_uu(c,d)*Gamma_ddd(d,a,b);
    }
    // Gamma's computed from the conformal metric (not evolved)
    for(int a = 0; a < 3; ++a)
    for(int b = 0; b < 3; ++b)
    for(int c = 0; c < 3; ++c) {
      Gamma_u(a) += g_uu(b,c)*Gamma_udd(a,b,c);
    }

    for(int a = 0; a < 3; ++a)
    for(int b = a; b < 3; ++b)
    for(int c = 0; c < 3; ++c)
    for(int d = 0; d < 3; ++d) {
      A_uu(a,b) += g_uu(a,c) * g_uu(b,d) * z4c.vA_dd(m,c,d,k,j,i);
    }
    // TODO(JMF): dchi_d/chi_guarded is opt.chi_psi_power * dphi_d.
    for(int a = 0; a < 3; ++a) {
      for(int b = 0; b < 3; ++b) {
          DA_u(a) -= (3./2.) * A_uu(a,b) * dchi_d(b) / chi_guarded;
          DA_u(a) -= (1./3.) * g_uu(a,b) * (2.*dKhat_d(b) + dTheta_d(b));
      }
      for(int b = 0; b < 3; ++b)
      for(int c = 0; c < 3; ++c) {
        DA_u(a) += Gamma_udd(a,b,c) * A_uu(b,c);
      }
    }

    // Shift vector contractions
    for(int a = 0; a < 3; ++a) {
      dbeta += dbeta_du(a,a);
    }
    for(int a = 0; a < 3; ++a)
    for(int b = 0; b < 3; ++b) {
      ddbeta_d(a) += (1./3.) * ddbeta_ddu(a,b,b);
    }

    // Finalize LGam_u (note that this is not a real Lie derivative)
    for(int a = 0; a < 3; ++a) {
      LGam_u(a) += (2./3.) * Gamma_u(a) * dbeta;
      for(int b = 0; b < 3; ++b) {
        LGam_u(a) += g_uu(a,b) * ddbeta_d(b) - Gamma_u(b) * dbeta_du(b,a);
        for(int c = 0; c < 3; ++c) {
          LGam_u(a) += g_uu(b,c) * ddbeta_ddu(b,c,a);
        }
      }
    }

    // Gamma's
    for(int a = 0; a < 3; ++a) {
      rhs.vGam_u(m,a,k,j,i) = 2.*z4c.alpha(m,k,j,i)*DA_u(a) + LGam_u(a);
      rhs.vGam_u(m,a,k,j,i) -= 2.*z4c.alpha(m,k,j,i) * opt.damp_kappa1 *
          (z4c.vGam_u(m,a,k,j,i) - Gamma_u(a));
      for(int b = 0; b < 3; ++b) {
        rhs.vGam_u(m,a,k,j,i) -= 2. * A_uu(a,b) * dalpha_d(b);
        // Matter term
        if(!is_vacuum) {
          rhs.vGam_u(m,a,k,j,i) -= 16.*M_PI * z4c.alpha(m,k,j,i)
                              * g_uu(a,b) * tmunu.S_d(m,b,k,j,i);
        }
      }
    }
  });

  par_for("z4c gauge rhs loop",DevExeSpace(),0,nmb-1,ks,ke,js,je,is,ie,
  KOKKOS_LAMBDA(const int m, const int k, const int j, const int i) {
    AthenaPointTensor<Real, TensorSymm::SYM2, 3, 2> g_uu;
    AthenaPointTensor<Real, TensorSymm::NONE, 3, 1> dalpha_d, dchi_d, Lbeta_u;
    auto idx = cubed_sphere::MakeStencil(geometry,size.d_view(m),indcs,m,k,j,i);
    Real Lalpha = 0.0;
    Real detg = 0.0;
    Real chi_guarded = fmax(z4c.chi(m,k,j,i),opt.chi_div_floor);
    Real oopsi4 = pow(chi_guarded,-4./opt.chi_psi_power);
    Lbeta_u.ZeroClear();
    for (int a=0; a<3; ++a) {
      dalpha_d(a) = Dx<NGHOST>(a, idx, z4c.alpha, m,k,j,i);
      dchi_d(a) = Dx<NGHOST>(a, idx, z4c.chi, m,k,j,i);
      Lalpha += Lx<NGHOST>(a, idx, z4c.beta_u, z4c.alpha, m,a,k,j,i);
      for (int b=0; b<3; ++b) {
        Lbeta_u(b) += Lx<NGHOST>(a, idx, z4c.beta_u, z4c.beta_u, m,a,b,k,j,i);
      }
    }
    detg = adm::SpatialDet(z4c.g_dd(m,0,0,k,j,i), z4c.g_dd(m,0,1,k,j,i),
                              z4c.g_dd(m,0,2,k,j,i), z4c.g_dd(m,1,1,k,j,i),
                              z4c.g_dd(m,1,2,k,j,i), z4c.g_dd(m,2,2,k,j,i));
    adm::SpatialInv(1.0/detg,
               z4c.g_dd(m,0,0,k,j,i), z4c.g_dd(m,0,1,k,j,i), z4c.g_dd(m,0,2,k,j,i),
               z4c.g_dd(m,1,1,k,j,i), z4c.g_dd(m,1,2,k,j,i), z4c.g_dd(m,2,2,k,j,i),
               &g_uu(0,0), &g_uu(0,1), &g_uu(0,2),
               &g_uu(1,1), &g_uu(1,2), &g_uu(2,2));

    // lapse function
    Real const f = opt.lapse_oplog * opt.lapse_harmonicf
                 + opt.lapse_harmonic * z4c.alpha(m,k,j,i);
    rhs.alpha(m,k,j,i) = opt.lapse_advect * Lalpha
                       - f * z4c.alpha(m,k,j,i) * z4c.vKhat(m,k,j,i);

    if (opt.slow_start_lapse) {
      Real W2 = (z4c.chi(m,k,j,i) > opt.chi_min_floor)
                    ? z4c.chi(m,k,j,i) : opt.chi_min_floor;
      Real W = pow(W2, 0.5);
      rhs.alpha(m,k,j,i) += opt.ssl_damping_amp*(W-z4c.alpha(m,k,j,i))
                            *pow(W,opt.ssl_damping_index)*exp(-0.5*pow(time/
                            (opt.ssl_damping_time),2));
    }

    // Telegraph lapse: partial_t B_i = advection + (kappa partial_i alpha-B_i)/tau.
    // The lapse receives gamma^{ij} partial_i B_j (the original partial-derivative
    // formulation, not a covariant divergence). oopsi4 supports arbitrary chi powers.
    for (int b=0; b<3; ++b) {
      rhs.vB_d(m,b,k,j,i) = 0.0;
      if (opt.telegraph_lapse) {
        Real adv = 0.0;
        for (int a=0; a<3; ++a) {
          adv += Lx<NGHOST>(a, idx, z4c.beta_u, z4c.vB_d, m,a,b,k,j,i);
          rhs.alpha(m,k,j,i) += oopsi4*g_uu(a,b)*
                               Dx<NGHOST>(a, idx, z4c.vB_d, m,b,k,j,i);
        }
        rhs.vB_d(m,b,k,j,i) = opt.lapse_advect*adv +
            (opt.telegraph_kappa*dalpha_d(b)-z4c.vB_d(m,b,k,j,i))/opt.telegraph_tau;
      }
    }

    // shift vector
    for(int a = 0; a < 3; ++a) {
      rhs.beta_u(m,a,k,j,i) = opt.shift_ggamma * z4c.vGam_u(m,a,k,j,i)
                            + opt.shift_advect * Lbeta_u(a);
      rhs.beta_u(m,a,k,j,i) -= opt.shift_eta * z4c.beta_u(m,a,k,j,i);
      // FORCE beta = 0
      //rhs.beta_u(m,a,k,j,i) = 0;
    }

    // harmonic gauge terms
    for(int a = 0; a < 3; ++a) {
      rhs.beta_u(m,a,k,j,i) += opt.shift_alpha2ggamma *
                          SQR(z4c.alpha(m,k,j,i)) * z4c.vGam_u(m,a,k,j,i);
      for(int b = 0; b < 3; ++b) {
        rhs.beta_u(m,a,k,j,i) += opt.shift_hh * z4c.alpha(m,k,j,i) *
          chi_guarded * (0.5 * z4c.alpha(m,k,j,i) * dchi_d(b) - dalpha_d(b)) * g_uu(a,b);
      }
    }

    // drift control correction
    if (dc_on) {
      Real &x1min = size.d_view(m).x1min;
      Real &x1max = size.d_view(m).x1max;
      Real &x2min = size.d_view(m).x2min;
      Real &x2max = size.d_view(m).x2max;
      Real &x3min = size.d_view(m).x3min;
      Real &x3max = size.d_view(m).x3max;
      Real x1 = CellCenterX(i - is, nx1, x1min, x1max);
      Real x2 = CellCenterX(j - js, nx2, x2min, x2max);
      Real x3 = CellCenterX(k - ks, nx3, x3min, x3max);

      Real const r2 = SQR(x1 - dc_c[0]) + SQR(x2 - dc_c[1]) + SQR(x3 - dc_c[2]);
      Real const g  = Kokkos::exp(-r2 * dc_inv_s2);

      if (dc_variety == DriftControl::Relaxation) {
        for (int a = 0; a < 3; ++a) {
          rhs.beta_u(m,a,k,j,i) -= dc_inv_tau[a]
                                 * (z4c.beta_u(m,a,k,j,i) - dc_target[a]) * g;
          rhs.beta_u(m,a,k,j,i) -= dc_gsupp[a] * z4c.vGam_u(m,a,k,j,i) * g;
        }
      } else {
        for (int a = 0; a < 3; ++a) {
          rhs.beta_u(m,a,k,j,i) -= dc_corr[a] * g;
        }
      }
    }
  });

  // ===================================================================================
  // Add dissipation for stability
  //
  Real &diss = pmy_pack->pz4c->diss;
  auto &u0 = pmy_pack->pz4c->u0;
  auto &u_rhs = pmy_pack->pz4c->u_rhs;
  par_for("K-O Dissipation",
  DevExeSpace(),0,nmb-1,0,nz4c-1,ks,ke,js,je,is,ie,
  KOKKOS_LAMBDA(const int m, const int n, const int k, const int j, const int i) {
    auto idx = cubed_sphere::MakeStencil(geometry,size.d_view(m),indcs,m,k,j,i);
    for(int a = 0; a < 3; ++a) {
      u_rhs(m,n,k,j,i) += Diss<NGHOST>(a, idx, u0, m, n, k, j, i)*diss;
    }
  });

  return TaskStatus::complete;
}

template TaskStatus Z4c::CalcRHS<2>(Driver *pdriver, int stage);
template TaskStatus Z4c::CalcRHS<3>(Driver *pdriver, int stage);
template TaskStatus Z4c::CalcRHS<4>(Driver *pdriver, int stage);
} // namespace z4c
