#include "z4c/hyperboloidal/native_composite_evolution.hpp"
//========================================================================================
// AthenaXXX astrophysical plasma code
// Copyright(C) 2020 James M. Stone <jmstone@ias.edu> and the Athena code team
// Licensed under the 3-clause BSD License (the "LICENSE")
//========================================================================================
//! \file z4c.cpp
//! \brief implementation of Z4c class constructor and assorted other functions

#include <math.h>
#include <sys/stat.h>  // mkdir

#include <iostream>
#include <stdexcept>
#include <string>
#include <algorithm>
#include <memory>    // make_unique, unique_ptr
#include <vector>    // vector
#include <Kokkos_Core.hpp>

#include "athena.hpp"
#include "mesh/cubed_sphere/extension.hpp"
#include "parameter_input.hpp"
#include "mesh/mesh.hpp"
#include "bvals/bvals.hpp"
#include "z4c/fastflow.hpp"
#include "z4c/compact_object_tracker.hpp"
#include "z4c/driftcontrol/driftcontrol.hpp"
#include "z4c/horizon_dump.hpp"
#include "z4c/z4c.hpp"
#include "z4c/hyperboloidal/cartesian_patch.hpp"
#include "z4c/z4c_amr.hpp"
#include "coordinates/adm.hpp"
#include "utils/cart_grid.hpp"

namespace z4c {

char const * const Z4c::Z4c_names[Z4c::nz4c] = {
  "z4c_chi",
  "z4c_gxx", "z4c_gxy", "z4c_gxz", "z4c_gyy", "z4c_gyz", "z4c_gzz",
  "z4c_Khat",
  "z4c_Axx", "z4c_Axy", "z4c_Axz", "z4c_Ayy", "z4c_Ayz", "z4c_Azz",
  "z4c_Gamx", "z4c_Gamy", "z4c_Gamz",
  "z4c_Theta",
  "z4c_alpha",
  "z4c_betax", "z4c_betay", "z4c_betaz",
  "z4c_Bx", "z4c_By", "z4c_Bz",
};

char const * const Z4c::Constraint_names[Z4c::ncon] = {
  "con_C",
  "con_H",
  "con_M",
  "con_Z",
  "con_Mx", "con_My", "con_Mz",
};

/*char const * const Z4c::Matter_names[Z4c::nmat] = {
  "mat_rho",
  "mat_Sx", "mat_Sy", "mat_Sz",
  "mat_Sxx", "mat_Sxy", "mat_Sxz", "mat_Syy", "mat_Syz", "mat_Szz",
};*/

//----------------------------------------------------------------------------------------
// constructor, initializes data structures and parameters

Z4c::Z4c(MeshBlockPack *ppack, ParameterInput *pin) :
  u_con("u_con",1,1,1,1,1),
  //u_mat("u_mat",1,1,1,1,1),
  u0("u0 z4c",1,1,1,1,1),
  u1("u1 z4c",1,1,1,1,1),
  u_rhs("u_rhs z4c",1,1,1,1,1),
  coarse_u0("coarse u0 z4c",1,1,1,1,1),
  u_weyl("u_weyl",1,1,1,1,1),
  coarse_u_weyl("coarse_u_weyl",1,1,1,1,1),
  pamr(new Z4c_AMR(pin)),
  pmy_pack(ppack) {
  if (pin->GetOrAddBoolean("z4c","hyperboloidal",false)
      && (pin->GetOrAddInteger("z4c","nrad_wave_extraction",0) != 0
          || pin->GetOrAddInteger("fastflow","num_horizons",0) != 0
          || pin->GetOrAddInteger("cce","num_radii",0) != 0
          || pin->DoesParameterExist("z4c","co_0_type"))) {
    throw std::invalid_argument("hyperboloidal prototype requires disabled extraction "
        "and trackers until their interpolation is mask aware");
  }
  // (1) read time-evolution option [already error checked in driver constructor]
  // Then initialize memory and algorithms for reconstruction and Riemann solvers
  std::string evolution_t = pin->GetString("time","evolution");

  int nmb = std::max((ppack->nmb_thispack), (ppack->pmesh->nmb_maxperrank));
  // int nmb = ppack->nmb_thispack;
  auto &indcs = pmy_pack->pmesh->mb_indcs;
  {
  int ncells1 = indcs.nx1 + 2*(indcs.ng);
  int ncells2 = (indcs.nx2 > 1)? (indcs.nx2 + 2*(indcs.ng)) : 1;
  int ncells3 = (indcs.nx3 > 1)? (indcs.nx3 + 2*(indcs.ng)) : 1;
  Kokkos::Profiling::pushRegion("Tensor fields");
  Kokkos::realloc(u_con, nmb, (ncon), ncells3, ncells2, ncells1);
  // Matter commented out
  // kokkos::realloc(u_mat, nmb, (N_MAT), ncells3, ncells2, ncells1);
  Kokkos::realloc(u0,    nmb, (nz4c), ncells3, ncells2, ncells1);
  Kokkos::realloc(u1,    nmb, (nz4c), ncells3, ncells2, ncells1);
  Kokkos::realloc(u_rhs, nmb, (nz4c), ncells3, ncells2, ncells1);
  Kokkos::realloc(u_weyl,    nmb, (2), ncells3, ncells2, ncells1);

  con.C.InitWithShallowSlice(u_con, I_CON_C);
  con.H.InitWithShallowSlice(u_con, I_CON_H);
  con.M.InitWithShallowSlice(u_con, I_CON_M);
  con.Z.InitWithShallowSlice(u_con, I_CON_Z);
  con.M_d.InitWithShallowSlice(u_con, I_CON_MX, I_CON_MZ);

  // Matter commented out
  //mat.rho.InitWithShallowSlice(u_mat, I_MAT_rho);
  //mat.S_d.InitWithShallowSlice(u_mat, I_MAT_Sx, I_MAT_Sz);
  //mat.S_dd.InitWithShallowSlice(u_mat, I_MAT_Sxx, I_MAT_Szz);

  z4c.vB_d.InitWithShallowSlice(u0, I_Z4C_BX, I_Z4C_BZ);
  z4c.alpha.InitWithShallowSlice (u0, I_Z4C_ALPHA);
  z4c.beta_u.InitWithShallowSlice(u0, I_Z4C_BETAX, I_Z4C_BETAZ);
  z4c.chi.InitWithShallowSlice   (u0, I_Z4C_CHI);
  z4c.vKhat.InitWithShallowSlice  (u0, I_Z4C_KHAT);
  z4c.vTheta.InitWithShallowSlice (u0, I_Z4C_THETA);
  z4c.vGam_u.InitWithShallowSlice (u0, I_Z4C_GAMX, I_Z4C_GAMZ);
  z4c.g_dd.InitWithShallowSlice  (u0, I_Z4C_GXX, I_Z4C_GZZ);
  z4c.vA_dd.InitWithShallowSlice  (u0, I_Z4C_AXX, I_Z4C_AZZ);

  rhs.vB_d.InitWithShallowSlice(u_rhs, I_Z4C_BX, I_Z4C_BZ);
  rhs.alpha.InitWithShallowSlice (u_rhs, I_Z4C_ALPHA);
  rhs.beta_u.InitWithShallowSlice(u_rhs, I_Z4C_BETAX, I_Z4C_BETAZ);
  rhs.chi.InitWithShallowSlice   (u_rhs, I_Z4C_CHI);
  rhs.vKhat.InitWithShallowSlice  (u_rhs, I_Z4C_KHAT);
  rhs.vTheta.InitWithShallowSlice (u_rhs, I_Z4C_THETA);
  rhs.vGam_u.InitWithShallowSlice (u_rhs, I_Z4C_GAMX, I_Z4C_GAMZ);
  rhs.g_dd.InitWithShallowSlice  (u_rhs, I_Z4C_GXX, I_Z4C_GZZ);
  rhs.vA_dd.InitWithShallowSlice  (u_rhs, I_Z4C_AXX, I_Z4C_AZZ);

  weyl.rpsi4.InitWithShallowSlice (u_weyl, 0);
  weyl.ipsi4.InitWithShallowSlice (u_weyl, 1);

  opt.chi_psi_power = pin->GetOrAddReal("z4c", "chi_psi_power", -4.0);
  opt.chi_div_floor = pin->GetOrAddReal("z4c", "chi_div_floor", -1000.0);
  opt.chi_min_floor = pin->GetOrAddReal("z4c", "chi_min_floor", 1e-12);
  opt.floor_chi = pin->GetOrAddBoolean("z4c", "floor_chi", false);
  opt.diss = pin->GetOrAddReal("z4c", "diss", 0.0);
  opt.eps_floor = pin->GetOrAddReal("z4c", "eps_floor", 1e-12);
  opt.damp_kappa1 = pin->GetOrAddReal("z4c", "damp_kappa1", 0.0);
  opt.damp_kappa2 = pin->GetOrAddReal("z4c", "damp_kappa2", 0.0);
  // Gauge conditions (default to moving puncture gauge)
  opt.lapse_harmonicf = pin->GetOrAddReal("z4c", "lapse_harmonicf", 1.0);
  opt.lapse_harmonic = pin->GetOrAddReal("z4c", "lapse_harmonic", 0.0);
  opt.lapse_oplog = pin->GetOrAddReal("z4c", "lapse_oplog", 2.0);
  opt.lapse_advect = pin->GetOrAddReal("z4c", "lapse_advect", 1.0);
  opt.slow_start_lapse = pin->GetOrAddBoolean("z4c", "slow_start_lapse", false);
  opt.ssl_damping_amp = pin->GetOrAddReal("z4c", "ssl_damping_amp", 0.6);
  opt.ssl_damping_time = pin->GetOrAddReal("z4c", "ssl_damping_time", 20.0);
  opt.ssl_damping_index = pin->GetOrAddInteger("z4c", "ssl_damping_index", 1);

  opt.telegraph_lapse = pin->GetOrAddBoolean("z4c", "telegraph_lapse", false);
  opt.telegraph_tau = pin->GetOrAddReal("z4c", "telegraph_tau", 0.1);
  opt.telegraph_kappa = pin->GetOrAddReal("z4c", "telegraph_kappa", 0.1);
  if (opt.telegraph_lapse && (!std::isfinite(opt.telegraph_tau) ||
      opt.telegraph_tau<=0 || !std::isfinite(opt.telegraph_kappa) ||
      opt.telegraph_kappa<0)) {
    std::cerr << "Telegraph lapse requires finite tau>0 and kappa>=0." << std::endl;
    std::exit(EXIT_FAILURE);
  }

  opt.shift_ggamma = pin->GetOrAddReal("z4c", "shift_Gamma", 1.0);
  opt.shift_advect = pin->GetOrAddReal("z4c", "shift_advect", 1.0);
  opt.shift_alpha2ggamma = pin->GetOrAddReal("z4c", "shift_alpha2Gamma", 0.0);
  opt.shift_hh = pin->GetOrAddReal("z4c", "shift_H", 0.0);

  opt.shift_eta = pin->GetOrAddReal("z4c", "shift_eta", 2.0);

  opt.use_z4c = pin->GetOrAddBoolean("z4c", "use_z4c", true);

  opt.user_Sbc = pin->GetOrAddBoolean("z4c", "user_Sbc", false);

  opt.excise_chi = pin->GetOrAddReal("z4c", "excise_chi", 0.0625);

  opt.extrap_order = fmax(2,fmin(indcs.ng,fmin(4,
      pin->GetOrAddInteger("z4c", "extrap_order", 2))));

  opt.spatial_order = pin->GetOrAddInteger("z4c", "spatial_order", 2*(indcs.ng-1));
  opt.fd_stencil = opt.spatial_order/2+1;
  if ((opt.spatial_order!=2 && opt.spatial_order!=4 && opt.spatial_order!=6) ||
      indcs.ng<opt.fd_stencil || indcs.ng>4) {
    std::cerr << "spatial_order must be 2, 4, or 6; nghost must be order/2+1 through 4."
              << std::endl;
    std::exit(EXIT_FAILURE);
  }
  diss = opt.diss*pow(2., -2.*opt.fd_stencil)*(opt.fd_stencil % 2 == 0 ? -1. : 1.);

  // DriftControl parameters
  opt.enable_driftcontrol = pin->GetOrAddBoolean("z4c", "enable_driftcontrol", false);
  opt.dc_tracker_index    = pin->GetOrAddInteger("z4c", "dc_tracker_index", 0);
  opt.dc_fixed_x          = pin->GetOrAddReal("z4c", "dc_fixed_x", 0.0);
  opt.dc_fixed_y          = pin->GetOrAddReal("z4c", "dc_fixed_y", 0.0);
  opt.dc_fixed_z          = pin->GetOrAddReal("z4c", "dc_fixed_z", 0.0);
  opt.dc_damping_time     = pin->GetOrAddReal("z4c", "dc_damping_time", 0.5);
  opt.dc_damping_scale    = pin->GetOrAddReal("z4c", "dc_damping_scale", 10.0);
  opt.dc_damping_coeff    = pin->GetOrAddReal("z4c", "dc_damping_coeff", 1.0);
  opt.dc_variety          = DriftControl::VarietyFromString(
      pin->GetOrAddString("z4c", "dc_variety", "oscillator"));
  opt.dc_Kp               = pin->GetOrAddReal("z4c", "dc_Kp", 1.0);
  opt.dc_Ki               = pin->GetOrAddReal("z4c", "dc_Ki", 0.1);
  opt.dc_Kd               = pin->GetOrAddReal("z4c", "dc_Kd", 2.0);
  opt.dc_omega_c          = pin->GetOrAddReal("z4c", "dc_omega_c", 0.2);
  opt.dc_omega_o          = pin->GetOrAddReal("z4c", "dc_omega_o", 1.0);
  opt.dc_zeta             = pin->GetOrAddReal("z4c", "dc_zeta", 1.0);
  opt.dc_relaxation_time  = pin->GetOrAddReal("z4c", "dc_relaxation_time", 1.0);
  opt.dc_kappa            = pin->GetOrAddReal("z4c", "dc_kappa", 1.0);
  opt.dc_gamma_suppress   = pin->GetOrAddReal("z4c", "dc_gamma_suppress", 0.0);
  opt.dc_gain_x           = pin->GetOrAddReal("z4c", "dc_gain_x", 1.0);
  opt.dc_gain_y           = pin->GetOrAddReal("z4c", "dc_gain_y", 1.0);
  opt.dc_gain_z           = pin->GetOrAddReal("z4c", "dc_gain_z", 1.0);
  opt.dc_gaussian_center  = DriftControl::CenterFromString(
      pin->GetOrAddString("z4c", "dc_gaussian_center", "fixed"));
  }

  // allocate memory for conserved variables on coarse mesh
  if (ppack->pmesh->multilevel) {
    auto &indcs = pmy_pack->pmesh->mb_indcs;
    int nccells1 = indcs.cnx1 + 2*(indcs.ng);
    int nccells2 = (indcs.cnx2 > 1)? (indcs.cnx2 + 2*(indcs.ng)) : 1;
    int nccells3 = (indcs.cnx3 > 1)? (indcs.cnx3 + 2*(indcs.ng)) : 1;
    Kokkos::realloc(coarse_u0, nmb, (nz4c), nccells3, nccells2, nccells1);
    Kokkos::realloc(coarse_u_weyl, nmb, (2), nccells3, nccells2, nccells1);
  }
  Kokkos::Profiling::popRegion();

  // allocate boundary buffers for conserved (cell-centered) variables
  Kokkos::Profiling::pushRegion("Buffers");
  pbval_u = new MeshBoundaryValuesCC(ppack, pin, true);
  pbval_u->InitializeBuffers((nz4c));
  pbval_weyl = new MeshBoundaryValuesCC(ppack, pin, true);
  pbval_weyl->InitializeBuffers((2));
  Kokkos::Profiling::popRegion();

  // wave extraction spheres
  // TODO(@hzhu): Read radii from input file
  auto &grids = spherical_grids;
  // set nrad_wave_extraction = 0 to turn off wave extraction
  nrad = pin->GetOrAddReal("z4c", "nrad_wave_extraction", 0);
  int nlev = pin->GetOrAddReal("z4c", "extraction_nlev", 10);
  for (int i=0; i<nrad; i++) {
    Real rad = pin->GetOrAddReal("z4c", "extraction_radius_"+std::to_string(i), 10);
    grids.push_back(std::make_unique<SphericalGrid>(ppack, nlev, rad));
  }
  // TODO(@dur566): Why is the size of psi_out hardcoded?
  psi_out = new Real[nrad*77*2];
  if (nrad > 0) {
    mkdir("waveforms",0775);
  }
  waveform_dt = pin->GetOrAddReal("z4c", "waveform_dt", 1);
  last_output_time = 0;
  // CCE
  cce_dump_dt = pin->GetOrAddReal("cce", "cce_dt", 1);
  int ncce = pin->GetOrAddInteger("cce", "num_radii", 0);
  if (ncce > 0) {
    mkdir("cce",0775);
  }
  cce_dump_last_output_time = pin->GetOrAddReal("z4c", "cce_last_output_time", -100);

  // Construct the compact object trackers
  int n = 0;
  while (true) {
    if (pin->DoesParameterExist("z4c", "co_" + std::to_string(n) + "_type")) {
      ptracker.push_back(std::make_unique<CompactObjectTracker>(pmy_pack->pmesh, pin, n));
      n++;
    } else {
      break;
    }
  }
  // Construct the drift control (needs the trackers to already exist)
  if (opt.enable_driftcontrol) {
    if (opt.dc_tracker_index < 0 ||
        static_cast<std::size_t>(opt.dc_tracker_index) >= ptracker.size()) {
      std::cout << "### FATAL ERROR in " << __FILE__ << " at line "
                << __LINE__ << std::endl;
      std::cout << "enable_driftcontrol is set but dc_tracker_index "
                << opt.dc_tracker_index << " is out of range for "
                << ptracker.size() << " compact object trackers." << std::endl;
      std::exit(EXIT_FAILURE);
    }
    pdrift_control = std::make_unique<DriftControl>(pmy_pack->pmesh, pin);
  }

  // Construct the apparent horizon finders
  n = 0;
  while (n < pin->GetOrAddInteger("fastflow", "num_horizons", 0)) {
    pfastflow.push_back(std::make_unique<FastFlow>(pmy_pack, pin, n));
    n++;
  }
  // Construct the Cartesian data grid for dumping horizon data
  n = 0;
  while (true) {
    if (pin->GetOrAddBoolean("z4c", "dump_horizon_" + std::to_string(n),false)) {
      if (static_cast<std::size_t>(n) >= ptracker.size()) {
        std::cerr << "Horizon dump requires its matching compact-object tracker"
                  << std::endl;
        std::exit(EXIT_FAILURE);
      }
      phorizon_dump.push_back(std::make_unique<HorizonDump>(pmy_pack, pin, n, 0));
      std::string foldername = "horizon_"+std::to_string(n);
      mkdir(foldername.c_str(),0775);
      n++;
    } else {
      break;
    }
  }
  /*
  horizon_dt = pin->GetOrAddReal("z4c", "horizon_dt", 1);
  horizon_last_output_time = 0;
  n = 0;
  for (auto & pt : ptracker) {
    if (pin->GetOrAddBoolean("z4c", "dump_horizon_" + std::to_string(n),false)) {
      horizon_extent.push_back(pin->GetOrAddReal("z4c", "horizon_"
                              + std::to_string(n)+"_radius",3));
      Real extend[3] = {horizon_extent[n],horizon_extent[n],horizon_extent[n]};
      horizon_nx.push_back(pin->GetOrAddInteger("z4c", "horizon_"
                              + std::to_string(n)+"_Nx",100));
      int Nx[3] = {horizon_nx[n],horizon_nx[n],horizon_nx[n]};
      horizon_dump.emplace_back(pmy_pack, pt.pos, extend, Nx);
      n++;
    }
  }
  */
  if (pin->GetOrAddBoolean("z4c","composite_elliptic_experimental",false))
    native_composite=std::make_unique<hyperboloidal::NativeCompositeEvolution>(*this,pmy_pack,pin);
  SetupHyperboloidal(pin);
}

//----------------------------------------------------------------------------------------
//! \fn void Z4c::AlgConstr(AthenaArray<Real> & u)
//! \brief algebraic constraints projection
//
// This function operates on all grid points of the MeshBlock
void Z4c::AlgConstr(MeshBlockPack *pmbp) {
  if (native_composite) return; // independently evolved tensor fields are never projected
  if (hyperboloidal_patch) {
    hyperboloidal_patch->ProjectAlgebraic(u0);
    return;
  }
  // capture variables for the kernel
  auto &indcs = pmbp->pmesh->mb_indcs;
  int &is = indcs.is; int &ie = indcs.ie;
  int &js = indcs.js; int &je = indcs.je;
  int &ks = indcs.ks; int &ke = indcs.ke;
  //For GLOOPS
  int isg = is-indcs.ng; int ieg = ie+indcs.ng;
  int jsg = js-indcs.ng; int jeg = je+indcs.ng;
  int ksg = ks-indcs.ng; int keg = ke+indcs.ng;

  int nmb = pmbp->nmb_thispack;

  auto &z4c = pmbp->pz4c->z4c;
  par_for("Alg constr loop",DevExeSpace(),
  0,nmb-1,ksg,keg,jsg,jeg,isg,ieg,
  KOKKOS_LAMBDA(const int m, const int k, const int j, const int i) {
    Real detg = adm::SpatialDet(z4c.g_dd(m,0,0,k,j,i), z4c.g_dd(m,0,1,k,j,i),
                              z4c.g_dd(m,0,2,k,j,i),z4c.g_dd(m,1,1,k,j,i),
                              z4c.g_dd(m,1,2,k,j,i), z4c.g_dd(m,2,2,k,j,i));
    detg = detg > 0. ? detg : 1.;
    // Real eps = detg - 1.;
    // Real oopsi4 = (eps < opt.eps_floor) ? (1. - opt.eps_floor/3.) :
    //             (std::pow(1./detg, 1./3.));
    Real oopsi4 = std::cbrt(1./detg);

    for(int a = 0; a < 3; ++a)
    for(int b = a; b < 3; ++b) {
      z4c.g_dd(m,a,b,k,j,i) *= oopsi4;
    }

    // compute trace of A
    // note: here we are assuming that det g = 1, which we enforced above
    Real A = adm::Trace(1.0,
              z4c.g_dd(m,0,0,k,j,i), z4c.g_dd(m,0,1,k,j,i), z4c.g_dd(m,0,2,k,j,i),
              z4c.g_dd(m,1,1,k,j,i), z4c.g_dd(m,1,2,k,j,i), z4c.g_dd(m,2,2,k,j,i),
              z4c.vA_dd(m,0,0,k,j,i), z4c.vA_dd(m,0,1,k,j,i), z4c.vA_dd(m,0,2,k,j,i),
              z4c.vA_dd(m,1,1,k,j,i), z4c.vA_dd(m,1,2,k,j,i), z4c.vA_dd(m,2,2,k,j,i));

    // enforce trace of A to be zero
    for(int a = 0; a < 3; ++a)
    for(int b = a; b < 3; ++b) {
      z4c.vA_dd(m,a,b,k,j,i) -= (1.0/3.0) * A * z4c.g_dd(m,a,b,k,j,i);
    }
  });
}
//----------------------------------------------------------------------------------------
// destructor
Z4c::~Z4c() {
  delete[] psi_out;
  delete pbval_weyl;
  delete pbval_u;
  delete pamr;
}

} // namespace z4c
