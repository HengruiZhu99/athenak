//========================================================================================
// AthenaXXX astrophysical plasma code
// Copyright(C) 2020 James M. Stone <jmstone@ias.edu> and the Athena code team
// Licensed under the 3-clause BSD License (the "LICENSE")
//========================================================================================
//! \file zoom_datablock.cpp
//! \brief Functions for storing and applying data in for given zoom data block

#include <iostream>
#include <utility>

#include "athena.hpp"
#include "globals.hpp"
#include "mesh/mesh.hpp"
#include "coordinates/cartesian_ks.hpp"
#include "coordinates/cell_locations.hpp"
#include "eos/eos.hpp"
#include "eos/ideal_c2p_hyd.hpp"
#include "eos/ideal_c2p_mhd.hpp"
#include "hydro/hydro.hpp"
#include "mhd/mhd.hpp"
#include "radiation/radiation.hpp"
#include "cyclic_zoom/cyclic_zoom.hpp"

//----------------------------------------------------------------------------------------
//! \fn void ZoomData::StoreData()
//! \brief Store data from MeshBlock m to zoom data zm

void ZoomData::StoreData(int zm, int m) {
  auto pmbp = pzoom->pmesh->pmb_pack;
  if (pmbp->phydro != nullptr) {
    auto u_ = pmbp->phydro->u0;
    auto w_ = pmbp->phydro->w0;
    StoreCCData(zm, u0, coarse_u0, m, u_);
    StoreCCData(zm, w0, coarse_w0, m, w_);
    CoarseConToPrim(zm, m, coarse_u0, coarse_w0);
  }
  if (pmbp->pmhd != nullptr) {
    auto u_ = pmbp->pmhd->u0;
    auto w_ = pmbp->pmhd->w0;
    StoreCCData(zm, u0, coarse_u0, m, u_);
    StoreCCData(zm, w0, coarse_w0, m, w_);
    StoreCoarsePrim(zm, coarse_w0, m, w_);
    auto efld = pmbp->pmhd->efld;
    StoreEFieldsBeforeAMR(zm, m, efld);
  }
  if (pmbp->prad != nullptr) {
    auto i_ = pmbp->prad->i0;
    StoreCCData(zm, i0, coarse_i0, m, i_);
  }
  return;
}

//----------------------------------------------------------------------------------------
//! \fn void ZoomData::StoreCCData()
//! \brief Store cell-centered data from MeshBlock m to zoom meshblock zm

void ZoomData::StoreCCData(int zm, DvceArray5D<Real> a0, DvceArray5D<Real> ca,
                           int m, DvceArray5D<Real> a) {
  auto pmesh = pzoom->pmesh;
  auto des_slice = Kokkos::subview(a0, Kokkos::make_pair(zm,zm+1),
                                   Kokkos::ALL,Kokkos::ALL,Kokkos::ALL,Kokkos::ALL);
  auto src_slice = Kokkos::subview(a, Kokkos::make_pair(m,m+1),
                                   Kokkos::ALL,Kokkos::ALL,Kokkos::ALL,Kokkos::ALL);
  Kokkos::deep_copy(des_slice, src_slice);
  // now do coarse data by averaging fine data
  auto &indcs = pzoom->pmesh->mb_indcs;
  int &cis = indcs.cis;  int &cie  = indcs.cie;
  int &cjs = indcs.cjs;  int &cje  = indcs.cje;
  int &cks = indcs.cks;  int &cke  = indcs.cke;
  int nvar = a.extent_int(1);
  int hg = indcs.ng / 2;
  // TODO(@mhguo): 1D and 2D cases are not tested yet!
  // restrict in 1D
  if (pmesh->one_d) {
    par_for("zoom_restrictCC-1D",DevExeSpace(), 0, nvar-1, cis-hg, cie+hg,
    KOKKOS_LAMBDA(const int n, const int i) {
      int finei = 2*i - cis;  // correct when cis=is
      ca(zm,n,cks,cjs,i) = 0.5*(a(m,n,cks,cjs,finei) + a(m,n,cks,cjs,finei+1));
    });
  // restrict in 2D
  } else if (pmesh->two_d) {
    par_for("zoom_restrictCC-2D",DevExeSpace(), 0, nvar-1,
            cjs-hg, cje+hg, cis-hg, cie+hg,
    KOKKOS_LAMBDA(const int n, const int j, const int i) {
      int finei = 2*i - cis;  // correct when cis=is
      int finej = 2*j - cjs;  // correct when cjs=js
      ca(zm,n,cks,j,i) = 0.25*(a(m,n,cks,finej  ,finei) + a(m,n,cks,finej  ,finei+1)
                             + a(m,n,cks,finej+1,finei) + a(m,n,cks,finej+1,finei+1));
    });
  // restrict in 3D
  } else {
    par_for("zoom_restrictCC-3D",DevExeSpace(), 0, nvar-1, cks-hg, cke+hg,
            cjs-hg, cje+hg, cis-hg, cie+hg,
    KOKKOS_LAMBDA(const int n, const int k, const int j, const int i) {
      int finei = 2*i - cis;  // correct if cis = is
      int finej = 2*j - cjs;  // correct if cjs = js
      int finek = 2*k - cks;  // correct if cks = ks
      ca(zm,n,k,j,i) =
                 0.125*(a(m,n,finek  ,finej  ,finei) + a(m,n,finek  ,finej  ,finei+1)
                      + a(m,n,finek  ,finej+1,finei) + a(m,n,finek  ,finej+1,finei+1)
                      + a(m,n,finek+1,finej,  finei) + a(m,n,finek+1,finej,  finei+1)
                      + a(m,n,finek+1,finej+1,finei) + a(m,n,finek+1,finej+1,finei+1));
    });
  }
  return;
}

//----------------------------------------------------------------------------------------
//! \fn void ZoomData::CoarseConToPrim()
//! \brief Convert coarse-grained conserved variables to primitive variables. Hydro only.

void ZoomData::CoarseConToPrim(int zm, int m, DvceArray5D<Real> cu,
                               DvceArray5D<Real> cw) {
  auto pmbp = pzoom->pmesh->pmb_pack;
  if (pmbp->phydro == nullptr) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__ << std::endl
              << "CoarseConToPrim only works for hydro case" <<std::endl;
    std::exit(EXIT_FAILURE);
  }
  auto pmesh = pzoom->pmesh;
  auto &indcs = pmesh->mb_indcs;
  auto &size = pmbp->pmb->mb_size;
  int &cis = indcs.cis;  int &cie  = indcs.cie;
  int &cjs = indcs.cjs;  int &cje  = indcs.cje;
  int &cks = indcs.cks;  int &cke  = indcs.cke;
  int cnx1 = indcs.cnx1, cnx2 = indcs.cnx2, cnx3 = indcs.cnx3;
  bool is_gr = pmbp->pcoord->is_general_relativistic;
  bool is_sr = pmbp->pcoord->is_special_relativistic;
  auto eos = pmbp->phydro->peos->eos_data;
  auto &coord = pmbp->pcoord->coord_data;
  bool flat = true;
  Real spin = 0.0;
  if (is_gr) {
    flat = coord.is_minkowski;
    spin = coord.bh_spin;
  }
  const int nhyd = pmbp->phydro->nhydro;
  const int nscal = pmbp->phydro->nscalars;
  // TODO(@mhguo): may include 1D and 2D cases
  int hg = indcs.ng / 2;
  // convert coarse-grained hydro conserved variables to primitive variables
  par_for("zoom_coarse_c2p",DevExeSpace(), cks-hg, cke+hg, cjs-hg, cje+hg, cis-hg, cie+hg,
  KOKKOS_LAMBDA(const int ck, const int cj, const int ci) {
    Real &x1min = size.d_view(m).x1min;
    Real &x1max = size.d_view(m).x1max;
    Real &x2min = size.d_view(m).x2min;
    Real &x2max = size.d_view(m).x2max;
    Real &x3min = size.d_view(m).x3min;
    Real &x3max = size.d_view(m).x3max;

    HydCons1D u;
    u.d = cu(zm,IDN,ck,cj,ci);
    u.mx = cu(zm,IM1,ck,cj,ci);
    u.my = cu(zm,IM2,ck,cj,ci);
    u.mz = cu(zm,IM3,ck,cj,ci);
    u.e = cu(zm,IEN,ck,cj,ci);

    HydPrim1D w;
    bool dfloor_used=false, efloor_used=false, tfloor_used=false;
    if (is_gr) {
      // Extract components of metric
      Real x1v = CellCenterX(ci-cis, cnx1, x1min, x1max);
      Real x2v = CellCenterX(cj-cjs, cnx2, x2min, x2max);
      Real x3v = CellCenterX(ck-cks, cnx3, x3min, x3max);
      Real glower[4][4], gupper[4][4];
      ComputeMetricAndInverse(x1v, x2v, x3v, flat, spin, glower, gupper);

      HydCons1D u_sr;
      Real s2;
      TransformToSRHyd(u,glower,gupper,s2,u_sr);
      bool c2p_failure=false;
      int iter_used=0;
      SingleC2P_IdealSRHyd(u_sr, eos, s2, w,
                           dfloor_used, efloor_used, c2p_failure, iter_used);
      // apply velocity ceiling if necessary
      Real tmp = glower[1][1]*SQR(w.vx)
                + glower[2][2]*SQR(w.vy)
                + glower[3][3]*SQR(w.vz)
                + 2.0*glower[1][2]*w.vx*w.vy + 2.0*glower[1][3]*w.vx*w.vz
                + 2.0*glower[2][3]*w.vy*w.vz;
      Real lor = sqrt(1.0+tmp);
      if (lor > eos.gamma_max) {
        Real factor = sqrt((SQR(eos.gamma_max)-1.0)/(SQR(lor)-1.0));
        w.vx *= factor;
        w.vy *= factor;
        w.vz *= factor;
      }
    } else if (is_sr) {
      // Compute (S^i S_i) (eqn C2)
      Real s2 = SQR(u.mx) + SQR(u.my) + SQR(u.mz);
      bool c2p_failure=false;
      int iter_used=0;
      SingleC2P_IdealSRHyd(u, eos, s2, w,
                           dfloor_used, efloor_used, c2p_failure, iter_used);
      // apply velocity ceiling if necessary
      Real lor = sqrt(1.0+SQR(w.vx)+SQR(w.vy)+SQR(w.vz));
      if (lor > eos.gamma_max) {
        Real factor = sqrt((SQR(eos.gamma_max)-1.0)/(SQR(lor)-1.0));
        w.vx *= factor;
        w.vy *= factor;
        w.vz *= factor;
      }
    } else {
      SingleC2P_IdealHyd(u, eos, w, dfloor_used, efloor_used, tfloor_used);
    }
    cw(zm,IDN,ck,cj,ci) = w.d;
    cw(zm,IVX,ck,cj,ci) = w.vx;
    cw(zm,IVY,ck,cj,ci) = w.vy;
    cw(zm,IVZ,ck,cj,ci) = w.vz;
    cw(zm,IEN,ck,cj,ci) = w.e;
    // store passive scalars (if any)
    for (int n=nhyd; n<(nhyd+nscal); ++n) {
      cw(zm,n,ck,cj,ci) = cu(zm,n,ck,cj,ci)/u.d;
    }
  });
  return;
}

//----------------------------------------------------------------------------------------
//! \fn void ZoomData::StoreCoarsePrim()
//! \brief Store coarse-grained primitives from meshblock m to zoom block zm by averaging
//!        hydro part of conserved variables. MHD only.

void ZoomData::StoreCoarsePrim(int zm, DvceArray5D<Real> cw,
                               int m, DvceArray5D<Real> w_) {
  auto pmbp = pzoom->pmesh->pmb_pack;
  if (pmbp->pmhd == nullptr) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__ << std::endl
              << "StoreCoarsePrimData only works for MHD case" <<std::endl;
    std::exit(EXIT_FAILURE);
  }
  auto &indcs = pzoom->pmesh->mb_indcs;
  auto &size = pmbp->pmb->mb_size;
  int &is = indcs.is;
  int &js = indcs.js;
  int &ks = indcs.ks;
  int &cis = indcs.cis;  int &cie  = indcs.cie;
  int &cjs = indcs.cjs;  int &cje  = indcs.cje;
  int &cks = indcs.cks;  int &cke  = indcs.cke;
  int nx1 = indcs.nx1, nx2 = indcs.nx2, nx3 = indcs.nx3;
  int cnx1 = indcs.cnx1, cnx2 = indcs.cnx2, cnx3 = indcs.cnx3;
  // DvceArray5D<Real> u0_, w0_;
  bool is_gr = pmbp->pcoord->is_general_relativistic;
  bool is_sr = pmbp->pcoord->is_special_relativistic;
  auto eos = pmbp->pmhd->peos->eos_data;
  bool flat = true;
  Real spin = 0.0;
  if (is_gr) {
    flat = pmbp->pcoord->coord_data.is_minkowski;
    spin = pmbp->pcoord->coord_data.bh_spin;
  }
  const int nmhd = pmbp->pmhd->nmhd;
  const int nscal = pmbp->pmhd->nscalars;
  // TODO(@mhguo): may include 1D and 2D cases
  int hg = indcs.ng / 2;
  par_for("zoom_store_cw",DevExeSpace(), cks-hg, cke+hg, cjs-hg, cje+hg, cis-hg, cie+hg,
  KOKKOS_LAMBDA(const int ck, const int cj, const int ci) {
    Real &x1min = size.d_view(m).x1min;
    Real &x1max = size.d_view(m).x1max;
    Real &x2min = size.d_view(m).x2min;
    Real &x2max = size.d_view(m).x2max;
    Real &x3min = size.d_view(m).x3min;
    Real &x3max = size.d_view(m).x3max;
    int fi = 2*ci - cis;  // correct when cis=is
    int fj = 2*cj - cjs;  // correct when cjs=js
    int fk = 2*ck - cks;  // correct when cks=ks
    cw(zm,IDN,ck,cj,ci) = 0.0;
    cw(zm,IM1,ck,cj,ci) = 0.0;
    cw(zm,IM2,ck,cj,ci) = 0.0;
    cw(zm,IM3,ck,cj,ci) = 0.0;
    cw(zm,IEN,ck,cj,ci) = 0.0;
    for (int n=nmhd; n<(nmhd+nscal); ++n) {
      cw(zm,n,ck,cj,ci) = 0.0;
    }
    Real glower[4][4], gupper[4][4];
    // Step 1: compute coarse-grained hydro conserved variables
    for (int ii=0; ii<2; ++ii) {
      for (int jj=0; jj<2; ++jj) {
        for (int kk=0; kk<2; ++kk) {
          // Load single state of primitive variables
          HydPrim1D w;
          w.d  = w_(m,IDN,fk+kk,fj+jj,fi+ii);
          w.vx = w_(m,IVX,fk+kk,fj+jj,fi+ii);
          w.vy = w_(m,IVY,fk+kk,fj+jj,fi+ii);
          w.vz = w_(m,IVZ,fk+kk,fj+jj,fi+ii);
          w.e  = w_(m,IEN,fk+kk,fj+jj,fi+ii);

          // call p2c function
          HydCons1D u;
          if (is_gr) {
            Real x1v = CellCenterX(fi+ii-is, nx1, x1min, x1max);
            Real x2v = CellCenterX(fj+jj-js, nx2, x2min, x2max);
            Real x3v = CellCenterX(fk+kk-ks, nx3, x3min, x3max);
            ComputeMetricAndInverse(x1v, x2v, x3v, flat, spin, glower, gupper);
            SingleP2C_IdealGRHyd(glower, gupper, w, eos.gamma, u);
          } else if (is_sr) {
            SingleP2C_IdealSRHyd(w, eos.gamma, u);
          } else {
            SingleP2C_IdealHyd(w, u);
          }

          // store conserved quantities using cw
          cw(zm,IDN,ck,cj,ci) += 0.125*u.d;
          cw(zm,IM1,ck,cj,ci) += 0.125*u.mx;
          cw(zm,IM2,ck,cj,ci) += 0.125*u.my;
          cw(zm,IM3,ck,cj,ci) += 0.125*u.mz;
          cw(zm,IEN,ck,cj,ci) += 0.125*u.e;
          // store passive scalars (if any)
          for (int n=nmhd; n<(nmhd+nscal); ++n) {
            cw(zm,n,ck,cj,ci) += 0.125*u.d*w_(m,n,fk+kk,fj+jj,fi+ii);
          }
        }
      }
    }
    // Step 2: convert coarse-grained hydro conserved variables to primitive variables
    // Shall we add excision?
    // load single state conserved variables
    HydCons1D u;
    u.d  = cw(zm,IDN,ck,cj,ci);
    u.mx = cw(zm,IM1,ck,cj,ci);
    u.my = cw(zm,IM2,ck,cj,ci);
    u.mz = cw(zm,IM3,ck,cj,ci);
    u.e  = cw(zm,IEN,ck,cj,ci);

    HydPrim1D w;
    bool dfloor_used=false, efloor_used=false, tfloor_used=false;
    if (is_gr) {
      // Extract components of metric
      Real x1v = CellCenterX(ci-cis, cnx1, x1min, x1max);
      Real x2v = CellCenterX(cj-cjs, cnx2, x2min, x2max);
      Real x3v = CellCenterX(ck-cks, cnx3, x3min, x3max);
      ComputeMetricAndInverse(x1v, x2v, x3v, flat, spin, glower, gupper);

      HydCons1D u_sr;
      Real s2;
      TransformToSRHyd(u,glower,gupper,s2,u_sr);
      bool c2p_failure=false;
      int iter_used=0;
      SingleC2P_IdealSRHyd(u_sr, eos, s2, w,
                           dfloor_used, efloor_used, c2p_failure, iter_used);
      // apply velocity ceiling if necessary
      Real tmp = glower[1][1]*SQR(w.vx)
                + glower[2][2]*SQR(w.vy)
                + glower[3][3]*SQR(w.vz)
                + 2.0*glower[1][2]*w.vx*w.vy + 2.0*glower[1][3]*w.vx*w.vz
                + 2.0*glower[2][3]*w.vy*w.vz;
      Real lor = sqrt(1.0+tmp);
      if (lor > eos.gamma_max) {
        Real factor = sqrt((SQR(eos.gamma_max)-1.0)/(SQR(lor)-1.0));
        w.vx *= factor;
        w.vy *= factor;
        w.vz *= factor;
      }
    } else if (is_sr) {
      // Compute (S^i S_i) (eqn C2)
      Real s2 = SQR(u.mx) + SQR(u.my) + SQR(u.mz);
      bool c2p_failure=false;
      int iter_used=0;
      SingleC2P_IdealSRHyd(u, eos, s2, w,
                           dfloor_used, efloor_used, c2p_failure, iter_used);
      // apply velocity ceiling if necessary
      Real lor = sqrt(1.0+SQR(w.vx)+SQR(w.vy)+SQR(w.vz));
      if (lor > eos.gamma_max) {
        Real factor = sqrt((SQR(eos.gamma_max)-1.0)/(SQR(lor)-1.0));
        w.vx *= factor;
        w.vy *= factor;
        w.vz *= factor;
      }
    } else {
      SingleC2P_IdealHyd(u, eos, w, dfloor_used, efloor_used, tfloor_used);
    }
    cw(zm,IDN,ck,cj,ci) = w.d;
    cw(zm,IVX,ck,cj,ci) = w.vx;
    cw(zm,IVY,ck,cj,ci) = w.vy;
    cw(zm,IVZ,ck,cj,ci) = w.vz;
    cw(zm,IEN,ck,cj,ci) = w.e;
    // store passive scalars (if any)
    for (int n=nmhd; n<(nmhd+nscal); ++n) {
      cw(zm,n,ck,cj,ci) = cw(zm,n,ck,cj,ci)/u.d;
    }
  });

  return;
}

//----------------------------------------------------------------------------------------
//! \fn ZoomData::ApplyDataSameLevel()
//! \brief Load data from zoom data zm to MeshBlock m

void ZoomData::ApplyDataSameLevel(int m, int zm, const ZoomRegion &zregion) {
  auto pmbp = pzoom->pmesh->pmb_pack;
  if (pmbp->phydro == nullptr && pmbp->pmhd == nullptr && pmbp->prad == nullptr) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__ << std::endl
              << "No physics module enabled, nothing to load" <<std::endl;
    std::exit(EXIT_FAILURE);
  }
  if (pmbp->phydro != nullptr) {
    ApplyCCDataSameLevel(m, pmbp->phydro->u0, zm, u0, zregion);
    ApplyCCDataSameLevel(m, pmbp->phydro->w0, zm, w0, zregion);
  }
  if (pmbp->pmhd != nullptr) {
    ApplyPrimSameLevel(m, zm, zregion);
  }
  if (pmbp->prad != nullptr) {
    ApplyCCDataSameLevel(m, pmbp->prad->i0, zm, i0, zregion);
  }
  return;
}

//----------------------------------------------------------------------------------------
//! \fn ZoomData::ApplyDataFromFiner()
//! \brief Apply data to MeshBlock m from finer level zoom data zm for the zoom region

void ZoomData::ApplyDataFromFiner(int m, int zm, const ZoomRegion &zregion) {
  auto pmbp = pzoom->pmesh->pmb_pack;
  if (pmbp->phydro == nullptr && pmbp->pmhd == nullptr && pmbp->prad == nullptr) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__ << std::endl
              << "No physics module enabled, nothing to load" <<std::endl;
    std::exit(EXIT_FAILURE);
  }
  if (pmbp->phydro != nullptr) {
    ApplyCCDataFromFiner(m, pmbp->phydro->u0, zm, coarse_u0, zregion);
    ApplyCCDataFromFiner(m, pmbp->phydro->w0, zm, coarse_w0, zregion);
  }
  if (pmbp->pmhd != nullptr) {
    ApplyPrimFromFiner(m, zm, zregion);
  }
  if (pmbp->prad != nullptr) {
    ApplyCCDataFromFiner(m, pmbp->prad->i0, zm, coarse_i0, zregion);
  }
  return;
}

//----------------------------------------------------------------------------------------
//! \fn void ZoomData::ApplyCCDataSameLevel()
//! \brief Apply cell-centered data to MeshBlock m from zoom data zm

void ZoomData::ApplyCCDataSameLevel(int m, DvceArray5D<Real> a,
                                    int zm, DvceArray5D<Real> a0,
                                    const ZoomRegion &zregion) {
  auto &indcs = pzoom->pmesh->mb_indcs;
  auto pmbp = pzoom->pmesh->pmb_pack;
  auto &size = pmbp->pmb->mb_size;
  int &is = indcs.is;  int &ie  = indcs.ie;
  int &js = indcs.js;  int &je  = indcs.je;
  int &ks = indcs.ks;  int &ke  = indcs.ke;
  int nx1 = indcs.nx1, nx2 = indcs.nx2, nx3 = indcs.nx3;
  int nvar = a.extent_int(1);
  par_for("zoom_apply_cc_same", DevExeSpace(),ks,ke,js,je,is,ie,
  KOKKOS_LAMBDA(int k, int j, int i) {
    Real &x1min = size.d_view(m).x1min;
    Real &x1max = size.d_view(m).x1max;
    Real &x2min = size.d_view(m).x2min;
    Real &x2max = size.d_view(m).x2max;
    Real &x3min = size.d_view(m).x3min;
    Real &x3max = size.d_view(m).x3max;
    Real x1v = CellCenterX(i-is, nx1, x1min, x1max);
    Real x2v = CellCenterX(j-js, nx2, x2min, x2max);
    Real x3v = CellCenterX(k-ks, nx3, x3min, x3max);
    if (zregion.IsInRegion(x1v, x2v, x3v)) { // apply to zoom region
      // simply copy
      for (int n=0; n<nvar; ++n) {
        a(m,n,k,j,i) = a0(zm,n,k,j,i);
      }
    }
  });
  return;
}

//----------------------------------------------------------------------------------------
//! \fn void ZoomData::ApplyCCDataFromFiner()
//! \brief Apply cell-centered data to MeshBlock m from finer level zoom data zm

void ZoomData::ApplyCCDataFromFiner(int m, DvceArray5D<Real> a,
                                    int zm, DvceArray5D<Real> ca,
                                    const ZoomRegion &zregion) {
  auto &indcs = pzoom->pmesh->mb_indcs;
  auto pmbp = pzoom->pmesh->pmb_pack;
  auto &size = pmbp->pmb->mb_size;
  int &is = indcs.is;  int &js = indcs.js;  int &ks = indcs.ks;
  int nx1 = indcs.nx1, nx2 = indcs.nx2, nx3 = indcs.nx3;
  int &cis = indcs.cis;  int &cie  = indcs.cie;
  int &cjs = indcs.cjs;  int &cje  = indcs.cje;
  int &cks = indcs.cks;  int &cke  = indcs.cke;
  int cnx1 = indcs.cnx1, cnx2 = indcs.cnx2, cnx3 = indcs.cnx3;
  int nvar = a.extent_int(1);
  int zmbs = pzmesh->gzms_eachdvce[global_variable::my_rank]; // global id start of dvce
  auto &zlloc = pzmesh->lloc_eachzmb[zm+zmbs];
  int ox1 = ((zlloc.lx1 & 1) == 1);
  int ox2 = ((zlloc.lx2 & 1) == 1);
  int ox3 = ((zlloc.lx3 & 1) == 1);
  par_for("zoom_apply_cc_finer", DevExeSpace(),cks,cke,cjs,cje,cis,cie,
  KOKKOS_LAMBDA(int ck, int cj, int ci) {
    int i = ci + ox1 * cnx1;
    int j = cj + ox2 * cnx2;
    int k = ck + ox3 * cnx3;
    Real &x1min = size.d_view(m).x1min;
    Real &x1max = size.d_view(m).x1max;
    Real &x2min = size.d_view(m).x2min;
    Real &x2max = size.d_view(m).x2max;
    Real &x3min = size.d_view(m).x3min;
    Real &x3max = size.d_view(m).x3max;
    Real x1v = CellCenterX(i-is, nx1, x1min, x1max);
    Real x2v = CellCenterX(j-js, nx2, x2min, x2max);
    Real x3v = CellCenterX(k-ks, nx3, x3min, x3max);
    if (zregion.IsInRegion(x1v, x2v, x3v)) { // apply to zoom region
      // simply copy
      for (int n=0; n<nvar; ++n) {
        a(m,n,k,j,i) = ca(zm,n,ck,cj,ci);
      }
    }
  });
  return;
}

//----------------------------------------------------------------------------------------
//! \fn void ZoomData::ApplyPrimSameLevel()
//! \brief Apply MHD hydro data to MeshBlock m from zoom data zm

void ZoomData::ApplyPrimSameLevel(int m, int zm, const ZoomRegion &zregion) {
  auto pmbp = pzoom->pmesh->pmb_pack;
  if (pmbp->pmhd == nullptr) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__ << std::endl
              << "ApplyPrimSameLevel only works for MHD case" <<std::endl;
    std::exit(EXIT_FAILURE);
  }
  auto &indcs = pzoom->pmesh->mb_indcs;
  auto &size = pmbp->pmb->mb_size;
  int &is = indcs.is;  int &ie  = indcs.ie;
  int &js = indcs.js;  int &je  = indcs.je;
  int &ks = indcs.ks;  int &ke  = indcs.ke;
  int nx1 = indcs.nx1, nx2 = indcs.nx2, nx3 = indcs.nx3;
  auto eos = pmbp->pmhd->peos->eos_data;
  Real gamma = eos.gamma;
  bool is_gr = pmbp->pcoord->is_general_relativistic;
  bool is_sr = pmbp->pcoord->is_special_relativistic;
  auto &coord = pmbp->pcoord->coord_data;
  bool flat = true;
  Real spin = 0.0;
  if (is_gr) {
    flat = coord.is_minkowski;
    spin = coord.bh_spin;
  }
  const int nmhd = pmbp->pmhd->nmhd;
  const int nscal = pmbp->pmhd->nscalars;
  auto u_ = pmbp->pmhd->u0, w_ = pmbp->pmhd->w0;
  auto u0_ = u0, w0_ = w0;
  auto b = pmbp->pmhd->b0;
  par_for("zoom_apply_prim_same", DevExeSpace(),ks,ke,js,je,is,ie,
  KOKKOS_LAMBDA(int k, int j, int i) {
    Real &x1min = size.d_view(m).x1min;
    Real &x1max = size.d_view(m).x1max;
    Real &x2min = size.d_view(m).x2min;
    Real &x2max = size.d_view(m).x2max;
    Real &x3min = size.d_view(m).x3min;
    Real &x3max = size.d_view(m).x3max;
    Real x1v = CellCenterX(i-is, nx1, x1min, x1max);
    Real x2v = CellCenterX(j-js, nx2, x2min, x2max);
    Real x3v = CellCenterX(k-ks, nx3, x3min, x3max);
    if (zregion.IsInRegion(x1v, x2v, x3v)) { // apply to zoom region
      // convert primitive variables to conserved variables
      w_(m,IDN,k,j,i) = w0_(zm,IDN,k,j,i);
      w_(m,IVX,k,j,i) = w0_(zm,IVX,k,j,i);
      w_(m,IVY,k,j,i) = w0_(zm,IVY,k,j,i);
      w_(m,IVZ,k,j,i) = w0_(zm,IVZ,k,j,i);
      w_(m,IEN,k,j,i) = w0_(zm,IEN,k,j,i);
      for (int n=nmhd; n<(nmhd+nscal); ++n) {
        w_(m,n,k,j,i) = w0_(zm,n,k,j,i);
      }
      // zero out velocity if inside cut-off boundary
      if (zregion.IsInRegion(x1v, x2v, x3v, zregion.cut.r)) {
        w_(m,IVX,k,j,i) = 0.0;
        w_(m,IVY,k,j,i) = 0.0;
        w_(m,IVZ,k,j,i) = 0.0;
      }
      // Load single state of primitive variables
      MHDPrim1D w;
      w.d  = w_(m,IDN,k,j,i);
      w.vx = w_(m,IVX,k,j,i);
      w.vy = w_(m,IVY,k,j,i);
      w.vz = w_(m,IVZ,k,j,i);
      w.e  = w_(m,IEN,k,j,i);

      // load cell-centered fields into primitive state
      // use simple linear average of face-centered fields as bcc is not updated
      w.bx = 0.5*(b.x1f(m,k,j,i) + b.x1f(m,k,j,i+1));
      w.by = 0.5*(b.x2f(m,k,j,i) + b.x2f(m,k,j+1,i));
      w.bz = 0.5*(b.x3f(m,k,j,i) + b.x3f(m,k+1,j,i));

      // call p2c function
      HydCons1D u;
      if (is_gr) {
        Real glower[4][4], gupper[4][4];
        ComputeMetricAndInverse(x1v, x2v, x3v, flat, spin, glower, gupper);
        SingleP2C_IdealGRMHD(glower, gupper, w, gamma, u);
      } else if (is_sr) {
        SingleP2C_IdealSRMHD(w, gamma, u);
      } else {
        SingleP2C_IdealMHD(w, u);
      }

      // store conserved quantities in 3D array
      u_(m,IDN,k,j,i) = u.d;
      u_(m,IM1,k,j,i) = u.mx;
      u_(m,IM2,k,j,i) = u.my;
      u_(m,IM3,k,j,i) = u.mz;
      u_(m,IEN,k,j,i) = u.e;
      for (int n=nmhd; n<(nmhd+nscal); ++n) {
        u_(m,n,k,j,i) = u.d * w_(m,n,k,j,i);
      }
    }
  });
  if (pzoom->verbose) {
    std::cout << " Rank " << global_variable::my_rank
              << " applied same-level prims to local mb m=" << m
              << " with zm=" << zm << std::endl;
  }
  return;
}

//----------------------------------------------------------------------------------------
//! \fn void ZoomData::ApplyPrimFromFiner()
//! \brief Apply MHD hydro data to MeshBlock m from finer level zoom data zm

void ZoomData::ApplyPrimFromFiner(int m, int zm, const ZoomRegion &zregion) {
  auto pmbp = pzoom->pmesh->pmb_pack;
  if (pmbp->pmhd == nullptr) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__ << std::endl
              << "ApplyPrimFromFiner only works for MHD case" <<std::endl;
    std::exit(EXIT_FAILURE);
  }
  auto &indcs = pzoom->pmesh->mb_indcs;
  auto &size = pmbp->pmb->mb_size;
  int &is = indcs.is, &js = indcs.js, &ks = indcs.ks;
  // int &ie = indcs.ie, &je = indcs.je, &ke = indcs.ke;
  int nx1 = indcs.nx1, nx2 = indcs.nx2, nx3 = indcs.nx3;
  int &cis = indcs.cis;  int &cie  = indcs.cie;
  int &cjs = indcs.cjs;  int &cje  = indcs.cje;
  int &cks = indcs.cks;  int &cke  = indcs.cke;
  int cnx1 = indcs.cnx1, cnx2 = indcs.cnx2, cnx3 = indcs.cnx3;
  auto cu0 = coarse_u0, cw0 = coarse_w0;
  auto eos = pmbp->pmhd->peos->eos_data;
  Real gamma = eos.gamma;
  bool is_gr = pmbp->pcoord->is_general_relativistic;
  bool is_sr = pmbp->pcoord->is_special_relativistic;
  bool flat = true;
  Real spin = 0.0;
  if (is_gr) {
    flat = pmbp->pcoord->coord_data.is_minkowski;
    spin = pmbp->pcoord->coord_data.bh_spin;
  }
  const int nmhd = pmbp->pmhd->nmhd;
  const int nscal = pmbp->pmhd->nscalars;
  // eachlevel[pzoom->zstate.zone-1]; // starting gid of zoom MBs on previous level
  int zmbs = pzmesh->gzms_eachdvce[global_variable::my_rank]; // global id start of dvce
  auto &zlloc = pzmesh->lloc_eachzmb[zm+zmbs];
  int ox1 = ((zlloc.lx1 & 1) == 1);
  int ox2 = ((zlloc.lx2 & 1) == 1);
  int ox3 = ((zlloc.lx3 & 1) == 1);
  auto u_ = pmbp->pmhd->u0;
  auto w_ = pmbp->pmhd->w0;
  auto b = pmbp->pmhd->b0;
  par_for("zoom_apply_prim_finer", DevExeSpace(),cks,cke,cjs,cje,cis,cie,
  KOKKOS_LAMBDA(int ck, int cj, int ci) {
    int i = ci + ox1 * cnx1;
    int j = cj + ox2 * cnx2;
    int k = ck + ox3 * cnx3;
    Real &x1min = size.d_view(m).x1min;
    Real &x1max = size.d_view(m).x1max;
    Real &x2min = size.d_view(m).x2min;
    Real &x2max = size.d_view(m).x2max;
    Real &x3min = size.d_view(m).x3min;
    Real &x3max = size.d_view(m).x3max;
    Real x1v = CellCenterX(i-is, nx1, x1min, x1max);
    Real x2v = CellCenterX(j-js, nx2, x2min, x2max);
    Real x3v = CellCenterX(k-ks, nx3, x3min, x3max);
    if (zregion.IsInRegion(x1v, x2v, x3v)) { // apply to zoom region
      // convert primitive variables to conserved variables
      w_(m,IDN,k,j,i) = cw0(zm,IDN,ck,cj,ci);
      w_(m,IVX,k,j,i) = cw0(zm,IVX,ck,cj,ci);
      w_(m,IVY,k,j,i) = cw0(zm,IVY,ck,cj,ci);
      w_(m,IVZ,k,j,i) = cw0(zm,IVZ,ck,cj,ci);
      w_(m,IEN,k,j,i) = cw0(zm,IEN,ck,cj,ci);
      for (int n=nmhd; n<(nmhd+nscal); ++n) {
        w_(m,n,k,j,i) = cw0(zm,n,ck,cj,ci);
      }
      // zero out velocity if inside cut-off boundary
      if (zregion.IsInRegion(x1v, x2v, x3v, zregion.cut.r)) {
        w_(m,IVX,k,j,i) = 0.0;
        w_(m,IVY,k,j,i) = 0.0;
        w_(m,IVZ,k,j,i) = 0.0;
      }

      // Load single state of primitive variables
      MHDPrim1D w;
      w.d  = w_(m,IDN,k,j,i);
      w.vx = w_(m,IVX,k,j,i);
      w.vy = w_(m,IVY,k,j,i);
      w.vz = w_(m,IVZ,k,j,i);
      w.e  = w_(m,IEN,k,j,i);

      // load cell-centered fields into primitive state
      // use simple linear average of face-centered fields as bcc is probably not updated
      w.bx = 0.5*(b.x1f(m,k,j,i) + b.x1f(m,k,j,i+1));
      w.by = 0.5*(b.x2f(m,k,j,i) + b.x2f(m,k,j+1,i));
      w.bz = 0.5*(b.x3f(m,k,j,i) + b.x3f(m,k+1,j,i));

      // call p2c function
      HydCons1D u;
      if (is_gr) {
        Real glower[4][4], gupper[4][4];
        ComputeMetricAndInverse(x1v, x2v, x3v, flat, spin, glower, gupper);
        SingleP2C_IdealGRMHD(glower, gupper, w, gamma, u);
      } else if (is_sr) {
        SingleP2C_IdealSRMHD(w, gamma, u);
      } else {
        SingleP2C_IdealMHD(w, u);
      }

      // apply to conserved variables
      u_(m,IDN,k,j,i) = u.d;
      u_(m,IM1,k,j,i) = u.mx;
      u_(m,IM2,k,j,i) = u.my;
      u_(m,IM3,k,j,i) = u.mz;
      u_(m,IEN,k,j,i) = u.e;
      // apply to passive scalars (if any)
      for (int n=nmhd; n<(nmhd+nscal); ++n) {
        u_(m,n,k,j,i) = u.d * w_(m,n,k,j,i);
      }
    }
  });
  return;
}

//----------------------------------------------------------------------------------------
//! \fn ZoomData::ApplyUniformFill()
//! \brief Set uniform density, pressure, and zero velocity in zoom region

void ZoomData::ApplyUniformFill(const ZoomRegion &zregion) {
  auto pmbp = pzoom->pmesh->pmb_pack;
  auto pmesh = pzoom->pmesh;
  int nmb = pmbp->nmb_thispack;
  Real d0 = d_zoom;
  Real p0 = p_zoom;

  if (pmbp->phydro == nullptr && pmbp->pmhd == nullptr && pmbp->prad == nullptr) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__ << std::endl
              << "No physics module enabled, nothing to load" <<std::endl;
    std::exit(EXIT_FAILURE);
  }

  if (pmbp->phydro != nullptr) {
    auto peos = pmbp->phydro->peos;
    const bool is_ideal = peos->eos_data.is_ideal;
    Real gm1 = peos->eos_data.gamma - 1.0;
    Real e_int = (is_ideal) ? (p0 / gm1) : 0.0;
    int nhyd = pmbp->phydro->nhydro;
    int nscal = pmbp->phydro->nscalars;
    bool is_gr = pmbp->pcoord->is_general_relativistic;
    bool is_sr = pmbp->pcoord->is_special_relativistic;
    Real gamma = peos->eos_data.gamma;
    auto &coord = pmbp->pcoord->coord_data;
    bool flat = true;
    Real spin = 0.0;
    if (is_gr) {
      flat = coord.is_minkowski;
      spin = coord.bh_spin;
    }
    auto u_ = pmbp->phydro->u0;
    auto w_ = pmbp->phydro->w0;
    auto &indcs = pmesh->mb_indcs;
    auto &size = pmbp->pmb->mb_size;
    int &is = indcs.is;  int &ie  = indcs.ie;
    int &js = indcs.js;  int &je  = indcs.je;
    int &ks = indcs.ks;  int &ke  = indcs.ke;
    int nx1 = indcs.nx1, nx2 = indcs.nx2, nx3 = indcs.nx3;

    par_for("zoom_uniform_hyd", DevExeSpace(),0,nmb-1,ks,ke,js,je,is,ie,
    KOKKOS_LAMBDA(int m, int k, int j, int i) {
      Real &x1min = size.d_view(m).x1min;
      Real &x1max = size.d_view(m).x1max;
      Real &x2min = size.d_view(m).x2min;
      Real &x2max = size.d_view(m).x2max;
      Real &x3min = size.d_view(m).x3min;
      Real &x3max = size.d_view(m).x3max;
      Real x1v = CellCenterX(i-is, nx1, x1min, x1max);
      Real x2v = CellCenterX(j-js, nx2, x2min, x2max);
      Real x3v = CellCenterX(k-ks, nx3, x3min, x3max);
      if (zregion.IsInRegion(x1v, x2v, x3v)) { // apply to zoom region
        w_(m,IDN,k,j,i) = d0;
        w_(m,IVX,k,j,i) = 0.0;
        w_(m,IVY,k,j,i) = 0.0;
        w_(m,IVZ,k,j,i) = 0.0;
        if (is_ideal) {
          w_(m,IEN,k,j,i) = e_int;
        }
        for (int n=nhyd; n<(nhyd+nscal); ++n) {
          w_(m,n,k,j,i) = 0.0;
        }

        HydPrim1D w;
        w.d  = d0;
        w.vx = 0.0;
        w.vy = 0.0;
        w.vz = 0.0;
        w.e  = e_int;
        HydCons1D u;
        if (is_gr) {
          Real glower[4][4], gupper[4][4];
          ComputeMetricAndInverse(x1v, x2v, x3v, flat, spin, glower, gupper);
          SingleP2C_IdealGRHyd(glower, gupper, w, gamma, u);
        } else if (is_sr) {
          SingleP2C_IdealSRHyd(w, gamma, u);
        } else if (is_ideal) {
          SingleP2C_IdealHyd(w, u);
        } else {
          u.d  = d0;
          u.mx = 0.0;
          u.my = 0.0;
          u.mz = 0.0;
        }

        u_(m,IDN,k,j,i) = u.d;
        u_(m,IM1,k,j,i) = u.mx;
        u_(m,IM2,k,j,i) = u.my;
        u_(m,IM3,k,j,i) = u.mz;
        if (is_ideal) {
          u_(m,IEN,k,j,i) = u.e;
        }
        for (int n=nhyd; n<(nhyd+nscal); ++n) {
          u_(m,n,k,j,i) = u.d*w_(m,n,k,j,i);
        }
      }
    });
  }

  if (pmbp->pmhd != nullptr) {
    auto peos = pmbp->pmhd->peos;
    const bool is_ideal = peos->eos_data.is_ideal;
    Real gm1 = peos->eos_data.gamma - 1.0;
    Real e_int = (is_ideal) ? (p0 / gm1) : 0.0;
    int nmhd = pmbp->pmhd->nmhd;
    int nscal = pmbp->pmhd->nscalars;
    bool is_gr = pmbp->pcoord->is_general_relativistic;
    bool is_sr = pmbp->pcoord->is_special_relativistic;
    Real gamma = peos->eos_data.gamma;
    auto &coord = pmbp->pcoord->coord_data;
    bool flat = true;
    Real spin = 0.0;
    if (is_gr) {
      flat = coord.is_minkowski;
      spin = coord.bh_spin;
    }
    auto u_ = pmbp->pmhd->u0;
    auto w_ = pmbp->pmhd->w0;
    auto b = pmbp->pmhd->b0;
    auto &indcs = pmesh->mb_indcs;
    auto &size = pmbp->pmb->mb_size;
    int &is = indcs.is;  int &ie  = indcs.ie;
    int &js = indcs.js;  int &je  = indcs.je;
    int &ks = indcs.ks;  int &ke  = indcs.ke;
    int nx1 = indcs.nx1, nx2 = indcs.nx2, nx3 = indcs.nx3;

    par_for("zoom_uniform_mhd", DevExeSpace(),0,nmb-1,ks,ke,js,je,is,ie,
    KOKKOS_LAMBDA(int m, int k, int j, int i) {
      Real &x1min = size.d_view(m).x1min;
      Real &x1max = size.d_view(m).x1max;
      Real &x2min = size.d_view(m).x2min;
      Real &x2max = size.d_view(m).x2max;
      Real &x3min = size.d_view(m).x3min;
      Real &x3max = size.d_view(m).x3max;
      Real x1v = CellCenterX(i-is, nx1, x1min, x1max);
      Real x2v = CellCenterX(j-js, nx2, x2min, x2max);
      Real x3v = CellCenterX(k-ks, nx3, x3min, x3max);
      if (zregion.IsInRegion(x1v, x2v, x3v)) { // apply to zoom region
        w_(m,IDN,k,j,i) = d0;
        w_(m,IVX,k,j,i) = 0.0;
        w_(m,IVY,k,j,i) = 0.0;
        w_(m,IVZ,k,j,i) = 0.0;
        if (is_ideal) {
          w_(m,IEN,k,j,i) = e_int;
        }
        for (int n=nmhd; n<(nmhd+nscal); ++n) {
          w_(m,n,k,j,i) = 0.0;
        }

        Real bx = 0.5*(b.x1f(m,k,j,i) + b.x1f(m,k,j,i+1));
        Real by = 0.5*(b.x2f(m,k,j,i) + b.x2f(m,k,j+1,i));
        Real bz = 0.5*(b.x3f(m,k,j,i) + b.x3f(m,k+1,j,i));

        if (is_ideal) {
          MHDPrim1D w;
          w.d  = d0;
          w.vx = 0.0;
          w.vy = 0.0;
          w.vz = 0.0;
          w.e  = e_int;
          w.bx = bx;
          w.by = by;
          w.bz = bz;
          HydCons1D u;
          if (is_gr) {
            Real glower[4][4], gupper[4][4];
            ComputeMetricAndInverse(x1v, x2v, x3v, flat, spin, glower, gupper);
            SingleP2C_IdealGRMHD(glower, gupper, w, gamma, u);
          } else if (is_sr) {
            SingleP2C_IdealSRMHD(w, gamma, u);
          } else {
            SingleP2C_IdealMHD(w, u);
          }
          u_(m,IDN,k,j,i) = u.d;
          u_(m,IM1,k,j,i) = u.mx;
          u_(m,IM2,k,j,i) = u.my;
          u_(m,IM3,k,j,i) = u.mz;
          u_(m,IEN,k,j,i) = u.e;
        } else {
          u_(m,IDN,k,j,i) = d0;
          u_(m,IM1,k,j,i) = 0.0;
          u_(m,IM2,k,j,i) = 0.0;
          u_(m,IM3,k,j,i) = 0.0;
        }
        for (int n=nmhd; n<(nmhd+nscal); ++n) {
          u_(m,n,k,j,i) = u_(m,IDN,k,j,i)*w_(m,n,k,j,i);
        }
      }
    });
  }

  if (pmbp->prad != nullptr) {
    auto i_ = pmbp->prad->i0;
    auto &indcs = pmesh->mb_indcs;
    auto &size = pmbp->pmb->mb_size;
    int &is = indcs.is;  int &ie  = indcs.ie;
    int &js = indcs.js;  int &je  = indcs.je;
    int &ks = indcs.ks;  int &ke  = indcs.ke;
    int nx1 = indcs.nx1, nx2 = indcs.nx2, nx3 = indcs.nx3;
    int nang = nangles;

    par_for("zoom_uniform_rad", DevExeSpace(),0,nmb-1,ks,ke,js,je,is,ie,
    KOKKOS_LAMBDA(int m, int k, int j, int i) {
      Real &x1min = size.d_view(m).x1min;
      Real &x1max = size.d_view(m).x1max;
      Real &x2min = size.d_view(m).x2min;
      Real &x2max = size.d_view(m).x2max;
      Real &x3min = size.d_view(m).x3min;
      Real &x3max = size.d_view(m).x3max;
      Real x1v = CellCenterX(i-is, nx1, x1min, x1max);
      Real x2v = CellCenterX(j-js, nx2, x2min, x2max);
      Real x3v = CellCenterX(k-ks, nx3, x3min, x3max);
      if (zregion.IsInRegion(x1v, x2v, x3v)) { // apply to zoom region
        for (int n=0; n<nang; ++n) {
          i_(m,n,k,j,i) = 0.0;
        }
      }
    });
  }
  return;
}
