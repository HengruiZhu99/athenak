#ifndef CYCLIC_ZOOM_CYCLIC_ZOOM_HPP_
#define CYCLIC_ZOOM_CYCLIC_ZOOM_HPP_
//========================================================================================
// AthenaXXX astrophysical plasma code
// Copyright(C) 2020 James M. Stone <jmstone@ias.edu> and the Athena code team
// Licensed under the 3-clause BSD License (the "LICENSE")
//========================================================================================
//! \file cyclic_zoom.hpp
//! \brief Definitions for CyclicZoom class and related structures

#include <string>
#include <vector>

//----------------------------------------------------------------------------------------
//! \struct ZoomState
//! \brief runtime state of cyclic zoom AMR, updated during simulation, used for restart

typedef struct ZoomState {
  int id;                       // zoom event id
  int zone;                     // zone number = level_max - level
  int last_zone;                // last zone number
  int direction;                // direction of zooming (+1: coarsen, -1: refine)
  Real next_time;               // time of next zoom
} ZoomState;

//----------------------------------------------------------------------------------------
//! \struct ZoomAMR
//! \brief parameters of cyclic zoom AMR

typedef struct ZoomAMR {
  int nlevels;                  // number of levels
  int max_level;                // maximum level number
  int min_level;                // minimum level number
  int level;                    // level number = max_level - zone
  int refine_flag;              // flag for refinement (+1: refine, -1: coarsen)
  bool zooming_in;              // flag for performing zoom in (refinement)
  bool zooming_out;             // flag for performing zoom out (coarsening)
} ZoomAMR;

//----------------------------------------------------------------------------------------
//! \struct ZoomRegion
//! \brief parameters of zoom region

typedef struct ZoomRegion {
  // TODO(@mhguo): may add box region later
  // Real x1min, x2min, x3min;     // box minimum of zoom region
  // Real x1max, x2max, x3max;     // box maximum of zoom region
  Real x1c, x2c, x3c;           // center of zoom region
  Real r_0;                     // radius of zoom region at zone 0
  Real radius;                  // radius of zoom region

  // zoom scale parameters
  struct ZoomScale {
    Real f;
    Real r;
    Real r_max;
  };
  ZoomScale ref;                // mesh refinement
  ZoomScale exc;                // excision
  ZoomScale cut;                // cut-off
  ZoomScale flx;                // flux limiting

  // Kokkos inline function to check if a location is within the zoom region
  KOKKOS_INLINE_FUNCTION
  bool IsInRegion(Real x1, Real x2, Real x3) const {
    return IsInRegion(x1, x2, x3, radius);
  }
  KOKKOS_INLINE_FUNCTION
  bool IsInRegion(Real x1, Real x2, Real x3, Real r) const {
    return (SQR(x1 - x1c) + SQR(x2 - x2c) + SQR(x3 - x3c) <= SQR(r));
  }
} ZoomRegion;

//----------------------------------------------------------------------------------------
//! \struct ZoomInterval
//! \brief parameters of zoom interval

typedef struct ZoomInterval {
  Real trun_fac;                // interval factor
  Real trun_pow;                // interval power law
  Real trun_max;                // maximum interval
  std::vector<Real> trun_facs;  // interval factors for each zone (dynamic)
  // Constructor for initialization
  ZoomInterval() = default;
  // Initialize with given number of zones
  void initialize(int num_zones) {
    trun_facs.resize(num_zones);
  }
  Real runtime;                 // interval for zoom
} ZoomInterval;

//----------------------------------------------------------------------------------------
//! \struct ZoomEMF
//! \brief parameters for EMF during zoom

typedef struct ZoomEMF {
  bool add_emf;            // flag for fixing electric field
  Real emf_fmax;           // maximum electric field factor
  int  emf_zmax;           // maximum zone number for electric field
} ZoomEMF;

// Forward declaration
class ZoomMesh;
class ZoomData;

//----------------------------------------------------------------------------------------
//! \class CyclicZoom
//! \brief Cyclic Zoom AMR module

class CyclicZoom {
  friend class ZoomMesh;
  friend class ZoomData;
 public:
  CyclicZoom(Mesh *pmesh, ParameterInput *pin);
  ~CyclicZoom() = default;

  // data
  // TODO(@mhguo): may extend to accept multiple zoom criteria later
  std::string block_name;  // block name for reading parameters
  bool verbose;            // flag for verbose output
  bool read_rst;           // flag for reading zoom data restart file
  bool write_rst;          // flag for writing zoom data restart file

  ZoomState zstate;        // zoom runtime state
  ZoomAMR zamr;            // zoom AMR parameters
  ZoomInterval zint;       // zoom interval parameters
  ZoomRegion zregion;      // zoom region parameters
  ZoomRegion old_zregion;  // previous zoom region parameters
  ZoomEMF zemf;            // zoom electric field parameters

  ZoomMesh *pzmesh;        // zoom mesh
  ZoomData *pzdata;        // zoom data

  // functions
  // basic functions
  void Initialize(ParameterInput *pin);
  void UpdateAMRFromRestart();
  void PrintCyclicZoomDiagnostics();
  // functions for zoom criteria
  void CheckRefinement();
  void UpdateState();
  void SetRegionAndInterval();
  void SetRefinementFlags();
  // functions to handle zoom region
  void StoreZoomRegion();
  void ApplyZoomRegion(Driver *pdriver);
  void LoadZoomData(int zone);
  void StoreVariables();
  bool CheckStoreFlag(int m);
  void CorrectVariables();
  void MaskVariables(int zone, const ZoomRegion &zreg);
  void ApplyMask();
  void AdjustExcisionForZoom();
  void UpdateFluxes(Driver *pdriver);
  void StoreFluxes();
  void SourceTermsFC(DvceEdgeFld4D<Real> emf);
  // restart functions
  IOWrapperSizeT RestartFileSize();
  void WriteRestartFile(IOWrapper &resfile, IOWrapperSizeT offset_zoom,
                        bool single_file_per_rank);
  void ReadRestartFile(IOWrapper &resfile, IOWrapperSizeT offset_zoom,
                       bool single_file_per_rank);

 private:
  // data
  Mesh *pmesh;            // ptr to Mesh containing this CyclicZoom module
};

//----------------------------------------------------------------------------------------
//! \class ZoomMesh
//! \brief data/functions associated with zoom mesh

class ZoomMesh {
 public:
  ZoomMesh(CyclicZoom *pz, ParameterInput *pin);
  ~ZoomMesh();

  // data
  int max_level;           // maximum zoom mesh level
  int min_level;           // minimum zoom mesh level
  int nlevels;             // number of zoom mesh levels
  int nzmb_total;          // total number of Zoom MeshBlocks across all levels/ranks
  int nzmb_thisdvce;       // number of Zoom MeshBlocks on this device (local)
  int nzmb_max_perdvce;    // max allowed number of Zoom MBs per device (memory limit)
  int nzmb_max_perhost;    // max allowed number of Zoom MBs per host (memory limit)
  // following 2x arrays allocated with length [nranks] in BuildTreeFromXXXX()
  int *gzms_eachlevel;     // starting global ID of Zoom MeshBlocks in each level
  int *nzmb_eachlevel;     // number of Zoom MeshBlocks on each level
  int *gzms_eachdvce;      // starting global ID of MeshBlocks in each device
  int *nzmb_eachdvce;      // number of MeshBlocks on each device
  int *zm_eachmb;          // local index of zoom MeshBlock for each MeshBlock
  std::vector<int> rank_eachzmb;   // rank of each Zoom MeshBlock
  std::vector<int> lid_eachzmb;    // local ID of each Zoom MeshBlock
  std::vector<int> mbrank_eachzmb; // MeshBlock rank of each zoom MeshBlock
  std::vector<int> mblid_eachzmb;  // MeshBlock local ID of each zoom MeshBlock
  std::vector<LogicalLocation> lloc_eachzmb;  // LogicalLocations for each zoom MeshBlock

  // functions
  void GatherNZMB(int zm_count, int zone);
  void UpdateMeshStructure();
  void RebuildMeshStructure();
  int  CountMBsToStore(int zone);
  void AssignMBLists();
  void SyncMBLists();
  void SyncLogicalLocations();
  int  FindMB(int gzm);
  void FindRegion(int zone);

 private:
  CyclicZoom *pzoom;       // ptr to CyclicZoom containing this ZoomMesh module
};

//----------------------------------------------------------------------------------------
//! \class ZoomData
//! \brief data/functions associated with zoom data operations

class ZoomData {
  friend class CyclicZoom;
 public:
  ZoomData(CyclicZoom *pz, ParameterInput *pin);
  ~ZoomData() = default;
  // data
  int nvars;               // number of variables
  int nangles;             // number of angles
  int zmb_data_cnt;        // count of data elements per Zoom MeshBlock needed for zooming
  Real d_zoom;             // density within inner boundary
  Real p_zoom;             // pressure within inner boundary

  // arrays
  DvceArray5D<Real> u0;    // conserved variables
  DvceArray5D<Real> w0;    // primitive variables
  DvceArray5D<Real> coarse_u0;  // coarse conserved variables
  DvceArray5D<Real> coarse_w0;  // coarse primitive variables

  DvceEdgeFld4D<Real> efld_pre;   // coarse edge-centered electric fields before zoom
  DvceEdgeFld4D<Real> efld_aft;   // coarse edge-centered electric fields after zoom
  DvceEdgeFld4D<Real> delta_efld; // change in electric fields, used for source terms
  DvceEdgeFld4D<Real> efld_buf;   // buffer for electric fields during zoom

  // Radiation intensity arrays
  DvceArray5D<Real> i0;         // intensities
  DvceArray5D<Real> coarse_i0;  // intensities on 2x coarser grid (for SMR/AMR)

  // DualView for device <-> host mirrored packing buffer
  // Syncs only used portion via subviews for bandwidth efficiency
  DualArray1D<Real> zbuf;

  // Host array for storage with load balancing
  // Contains different ZMBs after redistribution due to load balancing
  HostArray1D<Real> zdata;

#if MPI_PARALLEL_ENABLED
  MPI_Comm zoom_comm;                       // unique communicator for zoom refinement
  MPI_Request *send_req, *recv_req;
#endif

  // functions
  void Initialize();
  void MeshBlockDataSize();
  void ResetDataEC(DvceEdgeFld4D<Real> ec);
  // functions for storing/applying data during zoom
  void StoreData(int zm, int m);
  void StoreCCData(int zm, DvceArray5D<Real> a0, DvceArray5D<Real> ca,
                   int m, DvceArray5D<Real> a);
  void CoarseConToPrim(int zm, int m, DvceArray5D<Real> cu, DvceArray5D<Real> cw);
  void StoreCoarsePrim(int zm, DvceArray5D<Real> cw,
                       int m, DvceArray5D<Real> w0_);
  void ApplyDataSameLevel(int m, int zm, const ZoomRegion &zregion);
  void ApplyDataFromFiner(int m, int zm, const ZoomRegion &zregion);
  void ApplyCCDataSameLevel(int m, DvceArray5D<Real> a, int zm, DvceArray5D<Real> a0,
                            const ZoomRegion &zregion);
  void ApplyCCDataFromFiner(int m, DvceArray5D<Real> a, int zm, DvceArray5D<Real> ca,
                            const ZoomRegion &zregion);
  void ApplyPrimSameLevel(int m, int zm, const ZoomRegion &zregion);
  void ApplyPrimFromFiner(int m, int zm, const ZoomRegion &zregion);
  void ApplyUniformFill(const ZoomRegion &zregion);
  // functions for storing/applying electric fields during zoom
  void StoreEFieldsBeforeAMR(int zm, int m, DvceEdgeFld4D<Real> efld);
  void CorrectEFieldsFromFiner(int zmc, int m, int zmf, DvceEdgeFld4D<Real> efld);
  void StoreEFieldsAfterAMR(int zm, int m, DvceEdgeFld4D<Real> efld);
  void LimitEFields();
  // load balancing functions
  void PackBuffer();
  void PackBuffersCC(DvceArray1D<Real> packed_data, size_t offset,
                     int m, DvceArray5D<Real> a0);
  void PackBuffersFC(DvceArray1D<Real> packed_data, size_t offset,
                     int m, DvceFaceFld4D<Real> fc);
  void PackBuffersEC(DvceArray1D<Real> packed_data, size_t offset,
                     int m, DvceEdgeFld4D<Real> ec);
  void UnpackBuffer();
  void UnpackBuffersCC(DvceArray1D<Real> packed_data, size_t offset,
                       int m, DvceArray5D<Real> a0);
  void UnpackBuffersFC(DvceArray1D<Real> packed_data, size_t offset,
                       int m, DvceFaceFld4D<Real> fc);
  void UnpackBuffersEC(DvceArray1D<Real> packed_data, size_t offset,
                       int m, DvceEdgeFld4D<Real> ec);
  void RedistZMBs(int nlmb, int lmbs,
                  HostArray1D<Real> src_buf, HostArray1D<Real> dst_buf,
                  const std::vector<int>& src_ranks, const std::vector<int>& dst_ranks,
                  const std::vector<int>* src_lids, const std::vector<int>* dst_lids);
  void SaveToStorage(int zone);
  void LoadFromStorage(int zone);
  // source term functions
  void AddSrcTermsFC(int m, int zm, DvceEdgeFld4D<Real> emf);

 private:
  CyclicZoom *pzoom;       // ptr to CyclicZoom containing this ZoomData module
  ZoomMesh   *pzmesh;      // ptr to ZoomMesh containing this ZoomData module
};

#endif // CYCLIC_ZOOM_CYCLIC_ZOOM_HPP_
