//========================================================================================
// AthenaXXX astrophysical plasma code
// Copyright(C) 2020 James M. Stone <jmstone@ias.edu> and the Athena code team
// Licensed under the 3-clause BSD License (the "LICENSE")
//========================================================================================
//! \file zoom_mesh.cpp
//! \brief Implementation of constructor and basic functions in ZoomMesh class

#include <iostream>

#include "athena.hpp"
#include "globals.hpp"
#include "parameter_input.hpp"
#include "mesh/mesh.hpp"
#include "cyclic_zoom/cyclic_zoom.hpp"

//----------------------------------------------------------------------------------------
// constructor, initializes data structures and parameters

ZoomMesh::ZoomMesh(CyclicZoom *pz, ParameterInput *pin) :
    pzoom(pz) {
  max_level = pzoom->zamr.max_level;
  min_level = pzoom->zamr.min_level;
  nlevels = max_level - min_level + 1;
  nzmb_total = 0;
  nzmb_thisdvce = 0;
  nzmb_max_perdvce = pin->GetOrAddInteger("cyclic_zoom","max_nzmb_per_dvce",
                     pzoom->pmesh->nmb_maxperrank);
  nzmb_max_perhost = pin->GetOrAddInteger("cyclic_zoom","max_nzmb_per_host",
                     pzoom->pmesh->nmb_maxperrank);
  if (nzmb_max_perdvce > pzoom->pmesh->nmb_maxperrank) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__ << std::endl
              << "max_nzmb_per_dvce exceeds max_nmb_per_rank: "
              << nzmb_max_perdvce << " > " << pzoom->pmesh->nmb_maxperrank << std::endl;
    std::exit(EXIT_FAILURE);
  }
  if (nzmb_max_perhost > pzoom->pmesh->nmb_maxperrank) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__ << std::endl
              << "max_nzmb_per_host exceeds max_nmb_per_rank: "
              << nzmb_max_perhost << " > " << pzoom->pmesh->nmb_maxperrank << std::endl;
    std::exit(EXIT_FAILURE);
  }
  gzms_eachlevel = new int[nlevels]();
  nzmb_eachlevel = new int[nlevels]();
  gzms_eachdvce = new int[global_variable::nranks]();
  nzmb_eachdvce = new int[global_variable::nranks]();
  zm_eachmb = new int[pzoom->pmesh->nmb_maxperrank]();
  rank_eachzmb.resize(1);
  lid_eachzmb.resize(1);
  mbrank_eachzmb.resize(1);
  mblid_eachzmb.resize(1);
  lloc_eachzmb.resize(1);
}

//----------------------------------------------------------------------------------------
// destructor

ZoomMesh::~ZoomMesh() {
  delete[] gzms_eachlevel;
  delete[] nzmb_eachlevel;
  delete[] gzms_eachdvce;
  delete[] nzmb_eachdvce;
  delete[] zm_eachmb;
}

//----------------------------------------------------------------------------------------
//! \fn void ZoomMesh::GatherNZMB()
//! \brief Gather number of zoom MeshBlocks across all ranks

void ZoomMesh::GatherNZMB(int zm_count, int zone) {
  // Get total number across all ranks
  nzmb_thisdvce = zm_count;
  nzmb_eachdvce[global_variable::my_rank] = nzmb_thisdvce;
#if MPI_PARALLEL_ENABLED
  // Gather counts and displacements
  MPI_Allgather(&nzmb_thisdvce, 1, MPI_INT, nzmb_eachdvce, 1, MPI_INT, MPI_COMM_WORLD);
#endif
  // assign starting global ID for each rank/device
  gzms_eachdvce[0] = gzms_eachlevel[zone];
  for (int i = 1; i < global_variable::nranks; ++i) {
    gzms_eachdvce[i] = gzms_eachdvce[i-1] + nzmb_eachdvce[i-1];
  }
  return;
}
//----------------------------------------------------------------------------------------
//! \fn void ZoomMesh::UpdateMeshStructure()
//! \brief Update ZMB structure arrays after gathering ZMBs for a new level
//! \details Called during zoom operations to update totals, resize arrays, and assign
//!          ZMBs to ranks using round-robin distribution for the current zone.

void ZoomMesh::UpdateMeshStructure() {
  // Get total number across all ranks
  int nzmb_thislevel = 0;
  for (int i = 0; i < global_variable::nranks; ++i) {
    nzmb_thislevel += nzmb_eachdvce[i];
  }
  nzmb_total = gzms_eachlevel[pzoom->zstate.zone-1] + nzmb_thislevel;
  if (nzmb_total > nzmb_max_perhost * global_variable::nranks) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__ << std::endl
              << "Total number of zoom MeshBlocks exceed maximum "
              << "allowed on host: " << nzmb_total << " > "
              << nzmb_max_perhost * global_variable::nranks << std::endl;
    std::exit(EXIT_FAILURE);
  }
  nzmb_eachlevel[pzoom->zstate.zone-1] = nzmb_thislevel;
  gzms_eachlevel[pzoom->zstate.zone] = nzmb_total;
  // resize arrays to hold all zoom MeshBlocks across all levels/ranks
  rank_eachzmb.resize(nzmb_total);
  lid_eachzmb.resize(nzmb_total);
  mbrank_eachzmb.resize(nzmb_total);
  mblid_eachzmb.resize(nzmb_total);
  lloc_eachzmb.resize(nzmb_total);
  // simultaneously assign rank and local ID of each zoom MB on host
  // using round-robin for load balancing
  int lmbs = gzms_eachlevel[pzoom->zstate.zone-1];
  for (int lm=0; lm<nzmb_eachlevel[pzoom->zstate.zone-1]; ++lm) {
    rank_eachzmb[lm+lmbs] = (lm+lmbs) % global_variable::nranks;
    lid_eachzmb[lm+lmbs] = (lm+lmbs) / global_variable::nranks;
  }
  return;
}

//----------------------------------------------------------------------------------------
//! \fn void ZoomMesh::RebuildMeshStructure()
//! \brief Rebuild derived ZMB structure arrays after reading restart file
//! \details Called during restart to reconstruct gzms_eachlevel,
//!          rank_eachzmb, lid_eachzmb, and nzmb_thisdvce from the arrays read
//!          from restart file (nzmb_total, nzmb_eachlevel, nzmb_eachdvce).

void ZoomMesh::RebuildMeshStructure() {
  // Recalculate gzms_eachlevel from nzmb_eachlevel (cumulative sum)
  gzms_eachlevel[0] = 0;
  for (int zone = 1; zone < nlevels; zone++) {
    gzms_eachlevel[zone] = gzms_eachlevel[zone-1] + nzmb_eachlevel[zone-1];
  }

  // Resize and rebuild rank_eachzmb and lid_eachzmb arrays
  // These define which rank owns each ZMB in zdata storage using round-robin
  rank_eachzmb.resize(nzmb_total);
  lid_eachzmb.resize(nzmb_total);
  mbrank_eachzmb.resize(nzmb_total);
  mblid_eachzmb.resize(nzmb_total);
  lloc_eachzmb.resize(nzmb_total);

  // Rebuild rank_eachzmb and lid_eachzmb using round-robin distribution
  for (int gzm = 0; gzm < nzmb_total; ++gzm) {
    rank_eachzmb[gzm] = gzm % global_variable::nranks;
    lid_eachzmb[gzm] = gzm / global_variable::nranks;
  }

  return;
}

//----------------------------------------------------------------------------------------
//! \fn int ZoomMesh::CountMBsToStore()
//! \brief Find the list of stored MeshBlocks for each zoom MeshBlock

int ZoomMesh::CountMBsToStore(int zone) {
  int nmb = pzoom->pmesh->pmb_pack->nmb_thispack;
  int zm_count = 0;
  for (int m=0; m<nmb; ++m) {
    if (pzoom->CheckStoreFlag(m)) {
      if (zm_count >= nzmb_max_perdvce) {
        std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__
                  << std::endl << " ZoomMesh: number of zoom MeshBlocks to store "
                  << zm_count << " exceeds maximum number of zoom MeshBlocks per device: "
                  << nzmb_max_perdvce << std::endl;
        std::exit(EXIT_FAILURE);
      }
      zm_eachmb[m] = zm_count;
      if (pzoom->verbose) {
        int mbs = pzoom->pmesh->gids_eachrank[global_variable::my_rank];
        std::cout << " Rank " << global_variable::my_rank
                  << " Stores MeshBlock " << m + mbs
                  << " with zoom MeshBlock index " << zm_eachmb[m]
                  << std::endl;
      }
      ++zm_count;
    } else {
      zm_eachmb[m] = -1; // if not stored, set to -1
    }
  }
  return zm_count;
}

//----------------------------------------------------------------------------------------
//! \fn void ZoomMesh::AssignMBLists()
//! \brief Assign mbrank_eachzmb and mblid_eachzmb using round-robin distribution

void ZoomMesh::AssignMBLists() {
  // assign rank and local ID of each MB that contains the zoom MBs
  int nmb = pzoom->pmesh->pmb_pack->nmb_thispack;
  int mbs = pzoom->pmesh->gids_eachrank[global_variable::my_rank];
  int zmbs = gzms_eachdvce[global_variable::my_rank];
  // initialize unused entries to -1 (0 is a valid rank/id for Allreduce MAX)
  int lmbs = gzms_eachlevel[pzoom->zstate.zone-1];
  int nlmb = nzmb_eachlevel[pzoom->zstate.zone-1];
  for (int lm=0; lm<nlmb; ++lm) {
    mbrank_eachzmb[lm+lmbs] = -1;
    mblid_eachzmb[lm+lmbs] = -1;
    lloc_eachzmb[lm+lmbs] = {-1, -1, -1, -1};
  }
  for (int m=0; m<nmb; ++m) {
    int zm = zm_eachmb[m];
    if (zm >= 0) {
      mbrank_eachzmb[zm+zmbs] = global_variable::my_rank;
      mblid_eachzmb[zm+zmbs] = m;
      // copy LogicalLocation of stored MeshBlocks
      lloc_eachzmb[zm+zmbs] = pzoom->pmesh->lloc_eachmb[m+mbs];
    }
  }
  return;
}

//----------------------------------------------------------------------------------------
//! \fn void ZoomMesh::SyncMBLists()
//! \brief Sync mbrank_eachzmb and mblid_eachzmb across all ranks

void ZoomMesh::SyncMBLists() {
#if MPI_PARALLEL_ENABLED
  // Allreduce by global ZMB index; unused entries must be -1
  MPI_Allreduce(MPI_IN_PLACE, mbrank_eachzmb.data(), nzmb_total,
                MPI_INT, MPI_MAX, MPI_COMM_WORLD);
  MPI_Allreduce(MPI_IN_PLACE, mblid_eachzmb.data(), nzmb_total,
                MPI_INT, MPI_MAX, MPI_COMM_WORLD);
#endif
  return;
}

//----------------------------------------------------------------------------------------
//! \fn void ZoomMesh::SyncLogicalLocations()
//! \brief Sync lloc_eachzmb across all ranks

void ZoomMesh::SyncLogicalLocations() {
#if MPI_PARALLEL_ENABLED
  // Allreduce LogicalLocation as 4 int32s by global ZMB index
  MPI_Allreduce(MPI_IN_PLACE, reinterpret_cast<std::int32_t*>(lloc_eachzmb.data()),
                4*nzmb_total, MPI_INT32_T, MPI_MAX, MPI_COMM_WORLD);
#endif
  return;
}

//----------------------------------------------------------------------------------------
//! \fn int ZoomMesh::FindMB()
//! \brief find the meshblock that cover this zoom meshblock

int ZoomMesh::FindMB(int gzm) {
  int nmb = pzoom->pmesh->pmb_pack->nmb_thispack;
  int mbs = pzoom->pmesh->gids_eachrank[global_variable::my_rank];
  auto &zlloc = lloc_eachzmb[gzm];
  // check current level (zoom MBs at same level as current AMR level)
  // TODO(@mhguo): may loop over all MBs to avoid the sync later, though it may be slower
  for (int m = 0; m < nmb; ++m) {
    auto &lloc = pzoom->pmesh->lloc_eachmb[m+mbs];
    int level_diff = zlloc.level - lloc.level;
    // if zoom MB is the same as or a child of this MB
    if (level_diff >= 0) {
      if ( (zlloc.lx1 >> level_diff == lloc.lx1) &&
          (zlloc.lx2 >> level_diff == lloc.lx2) &&
          (zlloc.lx3 >> level_diff == lloc.lx3) ) {
        return m;
      }
    }
  }
  return -1;
}

//----------------------------------------------------------------------------------------
//! \fn void ZoomMesh::FindRegion()
//! \brief Find meshblocks for certain zone

void ZoomMesh::FindRegion(int zone) {
  int mbs = pzoom->pmesh->gids_eachrank[global_variable::my_rank];
  int nlmb = nzmb_eachlevel[zone]; // number of zoom MBs on previous level
  int lmbs = gzms_eachlevel[zone]; // starting gid of zoom MBs on previous level
  // initialize unused entries to -1 for Allreduce MAX
  for (int lm=0; lm<nlmb; ++lm) {
    mbrank_eachzmb[lm+lmbs] = -1;
    mblid_eachzmb[lm+lmbs] = -1;
  }
  // note that now the zoom state has been updated
  // use the updated zoom region parameters
  int zm_count = 0;
  for (int lm=0; lm<nlmb; ++lm) {
    int m = FindMB(lm+lmbs);
    if (m >= 0) {
      mbrank_eachzmb[lm+lmbs] = global_variable::my_rank;
      mblid_eachzmb[lm+lmbs] = m;
      if (pzoom->verbose) {
        std::cout << " Rank " << global_variable::my_rank
                  << " finds MeshBlock " << m+mbs << " for zoom MeshBlock "
                  << lm+lmbs << std::endl;
      }
      ++zm_count;
    }
  }
  if (pzoom->verbose && zm_count > 0) {
    std::cout << " Rank " << global_variable::my_rank << " found "
              << zm_count << " zoom MeshBlocks" << std::endl;
  }
  GatherNZMB(zm_count, zone);
  int lm_total = 0;
  for (int i = 0; i < global_variable::nranks; ++i) {
    lm_total += nzmb_eachdvce[i];
  }
  if (lm_total != nlmb) {
    std::cout << "### FATAL ERROR in " << __FILE__ << " at line " << __LINE__ << std::endl
              << "Inconsistent total number of zoom MeshBlocks across all ranks: "
              << "found " << lm_total << " vs. stored " << nlmb << std::endl;
    std::exit(EXIT_FAILURE);
  }
  return;
}
