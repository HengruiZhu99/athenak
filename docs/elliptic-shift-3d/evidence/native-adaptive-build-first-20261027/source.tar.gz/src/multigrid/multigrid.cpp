//========================================================================================
// Athena++ astrophysical MHD code
// Copyright(C) 2014 James M. Stone <jmstone@princeton.edu> and other code contributors
// Licensed under the 3-clause BSD License, see LICENSE file for details
//========================================================================================
//! \file multigrid.cpp
//! \brief implementation of the functions commonly used in Multigrid

// C headers

// C++ headers
#include <algorithm>
#include <cmath>
#include <cstring>    // memset, memcpy
#include <iostream>
#include <sstream>    // stringstream
#include <stdexcept>  // runtime_error
#include <string>     // c_str()
#include <iomanip>    // setprecision
#include <vector>

// Athena++ headers
#include "../athena.hpp"
#include "../coordinates/coordinates.hpp"
#include "../coordinates/cell_locations.hpp"
#include "../mesh/mesh.hpp"
#include "../mesh/nghbr_index.hpp"
#include "../parameter_input.hpp"
#include "multigrid.hpp"

//namespace multigrid{ // NOLINT (build/namespace)
//----------------------------------------------------------------------------------------
//! \fn Multigrid::Multigrid(MultigridDriver *pmd, MeshBlock *pmb, int nghost)
//  \brief Multigrid constructor

Multigrid::Multigrid(MultigridDriver *pmd, MeshBlockPack *pmbp, int nghost,
                     bool on_host):
  pmy_driver_(pmd), pmy_pack_(pmbp), pmy_mesh_(pmd->pmy_mesh_), ngh_(nghost),
  nvar_(pmd->nvar_), defscale_(1.0), on_host_(on_host) {
  if (pmy_pack_ != nullptr) {
    //Meshblock levels
    indcs_ = pmy_mesh_->mb_indcs;
    nmmb_  = pmy_pack_->nmb_thispack;
    nmmbx1_ = pmy_mesh_->nmb_rootx1;
    nmmbx2_ = pmy_mesh_->nmb_rootx2;
    nmmbx3_ = pmy_mesh_->nmb_rootx3;
    if (global_variable::my_rank == 0) {
      std::cout << "Number of MeshBlocks in the pack: " << nmmb_ << std::endl;
      std::cout << "MeshBlock size: "
               << indcs_.nx1 << " x " << indcs_.nx2 << " x " << indcs_.nx3 << std::endl;
    }
    if (indcs_.nx1 != indcs_.nx2 || indcs_.nx1 != indcs_.nx3) {
      std::cout << "### FATAL ERROR in Multigrid::Multigrid" << std::endl
         << "The Multigrid solver requires logically cubic MeshBlock." << std::endl;
      std::exit(EXIT_FAILURE);
      return;
     }

     // initialize loc/size from the first meshblock
     // in the pack (needs to be adapted for AMR)
    loc_ = pmy_pack_->pmesh->lloc_eachmb[0];
    size_ = pmy_pack_->pmb->mb_size.h_view(0);
  } else {
    //Root levels
    indcs_.nx1 = pmy_mesh_->nmb_rootx1;
    indcs_.nx2 = pmy_mesh_->nmb_rootx2;
    indcs_.nx3 = pmy_mesh_->nmb_rootx3;
    size_ = pmy_mesh_->mesh_size;
    nmmbx1_ = 1;
    nmmbx2_ = 1;
    nmmbx3_ = 1;
    // Root grid should be a single meshblock
    nmmb_ = 1;
    loc_  = pmy_mesh_->lloc_eachmb[0];
  }

  rdx_ = (size_.x1max-size_.x1min)/static_cast<Real>(indcs_.nx1);
  rdy_ = (size_.x2max-size_.x2min)/static_cast<Real>(indcs_.nx2);
  rdz_ = (size_.x3max-size_.x3min)/static_cast<Real>(indcs_.nx3);

  block_rdx_ = DualArray1D<Real>("block_rdx", nmmb_);
  Kokkos::realloc(fc_childx_, nmmb_);
  Kokkos::realloc(fc_childy_, nmmb_);
  Kokkos::realloc(fc_childz_, nmmb_);
  {
    auto brdx_h = block_rdx_.h_view;
    if (pmy_pack_ != nullptr) {
      auto &mb_size = pmy_pack_->pmb->mb_size;
      Real rnx1 = static_cast<Real>(indcs_.nx1);
      for (int m = 0; m < nmmb_; ++m) {
        brdx_h(m) = (mb_size.h_view(m).x1max - mb_size.h_view(m).x1min) / rnx1;
      }
    } else {
      brdx_h(0) = rdx_;
    }
    Kokkos::deep_copy(block_rdx_.d_view, brdx_h);
  }

  nlevel_ = 0;
  if (pmy_pack_ == nullptr) {
    // Root grid levels
    int nbx = 0, nby = 0, nbz = 0;
    for (int l = 0; l < 20; l++) {
      if (indcs_.nx1%(1<<l) == 0 && indcs_.nx2%(1<<l) == 0 && indcs_.nx3%(1<<l) == 0) {
        nbx = indcs_.nx1/(1<<l), nby = indcs_.nx2/(1<<l), nbz = indcs_.nx3/(1<<l);
        nlevel_ = l+1;
      }
    }
    int nmaxr = std::max(nbx, std::max(nby, nbz));
    if (global_variable::my_rank == 0) {
      std::cout << "Multigrid root grid levels: " << nlevel_ << std::endl;
    }
    // int nminr=std::min(nbx, std::min(nby, nbz)); // unused variable
    if (nmaxr != 1 && global_variable::my_rank == 0) {
      std::cout
          << "### Warning in Multigrid::Multigrid" << std::endl
          << "The root grid can not be reduced to a single cell." << std::endl
          << "Multigrid should still work, but this is not the"
          << " most efficient configuration"
          << " as the coarsest level is not solved exactly but iteratively." << std::endl;
    }
    if (nbx*nby*nbz>100 && global_variable::my_rank==0) {
      std::cout << "### Warning in Multigrid::Multigrid" << std::endl
                << "The degrees of freedom on the coarsest level is very large: "
                << nbx << " x " << nby << " x " << nbz
                << " = " << nbx*nby*nbz << std::endl
                << "Multigrid should still work, but this is not efficient configuration "
                << "as the coarsest level solver costs considerably." << std::endl
                << "We recommend to reconsider grid configuration." << std::endl;
    }
  } else {
    // MeshBlock levels
    for (int l = 0; l < 20; l++) {
      if ((1<<l) == indcs_.nx1) {
        nlevel_=l+1;
        break;
      }
    }
    if (nlevel_ == 0) {
      std::cout << "### FATAL ERROR in Multigrid::Multigrid" << std::endl
          << "The MeshBlock size must be power of two." << std::endl;
      std::exit(EXIT_FAILURE);
      return;
    }
  }

  current_level_ = nlevel_-1;

  // allocate arrays
  u_ = new DualArray5D<Real>[nlevel_];
  src_ = new DualArray5D<Real>[nlevel_];
  def_ = new DualArray5D<Real>[nlevel_];
  coeff_ = new DualArray5D<Real>[nlevel_];
  matrix_ = new DualArray5D<Real>[nlevel_];
  uold_ = new DualArray5D<Real>[nlevel_];

  for (int l = 0; l < nlevel_; l++) {
    int ll=nlevel_-1-l;
    int ncx=(indcs_.nx1>>ll)+2*ngh_;
    int ncy=(indcs_.nx2>>ll)+2*ngh_;
    int ncz=(indcs_.nx3>>ll)+2*ngh_;
    Kokkos::realloc(u_[l]  , nmmb_, nvar_, ncz, ncy, ncx);
    Kokkos::realloc(src_[l], nmmb_, nvar_, ncz, ncy, ncx);
    Kokkos::realloc(def_[l], nmmb_, nvar_, ncz, ncy, ncx);

    if (!((pmy_pack_ != nullptr) && (l == nlevel_-1)))
      Kokkos::realloc(uold_[l], nmmb_, nvar_, ncz, ncy, ncx);

    ncx=(indcs_.nx1>>(ll+1))+2*ngh_;
    ncy=(indcs_.nx2>>(ll+1))+2*ngh_;
    ncz=(indcs_.nx3>>(ll+1))+2*ngh_;
  }
}


//----------------------------------------------------------------------------------------
//! \fn Multigrid::~Multigrid
//! \brief Multigrid destroctor

Multigrid::~Multigrid() {
  delete [] u_;
  delete [] src_;
  delete [] def_;
  delete [] uold_;
  delete [] coeff_;
  delete [] matrix_;
  delete [] coord_;
  delete [] ccoord_;
}


//----------------------------------------------------------------------------------------
//! \fn void Multigrid::ReallocateForAMR()
//! \brief Reallocate MG arrays when the number of MeshBlocks changes (AMR)

void Multigrid::UpdateBlockDx() {
  if (pmy_pack_ == nullptr) return;
  auto &mb_size = pmy_pack_->pmb->mb_size;
  Real rnx1 = static_cast<Real>(indcs_.nx1);

  // Refresh reference block size and cell widths from the first MeshBlock
  size_ = mb_size.h_view(0);
  rdx_ = (size_.x1max - size_.x1min) / static_cast<Real>(indcs_.nx1);
  rdy_ = (size_.x2max - size_.x2min) / static_cast<Real>(indcs_.nx2);
  rdz_ = (size_.x3max - size_.x3min) / static_cast<Real>(indcs_.nx3);

  auto brdx_h = block_rdx_.h_view;
  for (int m = 0; m < nmmb_; ++m) {
    brdx_h(m) = (mb_size.h_view(m).x1max - mb_size.h_view(m).x1min) / rnx1;
  }
  Kokkos::deep_copy(block_rdx_.d_view, brdx_h);

  // Compute per-block child octant positions for FC ghost fills
  auto &mbgid = pmy_pack_->pmb->mb_gid;
  auto *lloc = pmy_mesh_->lloc_eachmb;
  int root_level = pmy_mesh_->root_level;
  auto cx_h = Kokkos::create_mirror_view(fc_childx_);
  auto cy_h = Kokkos::create_mirror_view(fc_childy_);
  auto cz_h = Kokkos::create_mirror_view(fc_childz_);
  for (int m = 0; m < nmmb_; ++m) {
    int gid = mbgid.h_view(m);
    LogicalLocation &loc = lloc[gid];
    cx_h(m) = (loc.level > root_level) ? static_cast<int>(loc.lx1 & 1) : 0;
    cy_h(m) = (loc.level > root_level) ? static_cast<int>(loc.lx2 & 1) : 0;
    cz_h(m) = (loc.level > root_level) ? static_cast<int>(loc.lx3 & 1) : 0;
  }
  Kokkos::deep_copy(fc_childx_, cx_h);
  Kokkos::deep_copy(fc_childy_, cy_h);
  Kokkos::deep_copy(fc_childz_, cz_h);
}

void Multigrid::ReallocateForAMR() {
  if (pmy_pack_ == nullptr) return;
  int new_nmmb = pmy_pack_->nmb_thispack;
  if (new_nmmb == nmmb_) return;
  nmmb_ = new_nmmb;

  Kokkos::realloc(block_rdx_, nmmb_);
  Kokkos::realloc(fc_childx_, nmmb_);
  Kokkos::realloc(fc_childy_, nmmb_);
  Kokkos::realloc(fc_childz_, nmmb_);
  UpdateBlockDx();

  for (int l = 0; l < nlevel_; l++) {
    int ll = nlevel_ - 1 - l;
    int ncx = (indcs_.nx1 >> ll) + 2 * ngh_;
    int ncy = (indcs_.nx2 >> ll) + 2 * ngh_;
    int ncz = (indcs_.nx3 >> ll) + 2 * ngh_;
    Kokkos::realloc(u_[l],   nmmb_, nvar_, ncz, ncy, ncx);
    Kokkos::realloc(src_[l], nmmb_, nvar_, ncz, ncy, ncx);
    Kokkos::realloc(def_[l], nmmb_, nvar_, ncz, ncy, ncx);
    if (l != nlevel_ - 1)
      Kokkos::realloc(uold_[l], nmmb_, nvar_, ncz, ncy, ncx);
  }
}


//! \fn void Multigrid::LoadFinestData(const DvceArray5D<Real> &src, int ns, int ngh)
//! \brief Fill the inital guess in the active zone of the finest level

void Multigrid::LoadFinestData(const DvceArray5D<Real> &src, int ns, int ngh) {
  auto &dst = u_[nlevel_-1].d_view;
  int is, ie, js, je, ks, ke;
  is = js = ks = ngh_;
  ie = is + indcs_.nx1 - 1; je = js + indcs_.nx2 - 1; ke = ks + indcs_.nx3 - 1;

  const int lns = ns;
  const int lks = ks, ljs = js, lis = is, lngh = ngh;

  par_for("Multigrid::LoadFinestData", DevExeSpace(),0, nmmb_-1,
          0, nvar_-1, ks, ke, js, je, is, ie,
  KOKKOS_LAMBDA(const int m, const int v, const int mk, const int mj, const int mi) {
    const int nsrc = lns + v;
    const int k = mk - lks + lngh;
    const int j = mj - ljs + lngh;
    const int i = mi - lis + lngh;
    dst(m, v, mk, mj, mi) = src(m, nsrc, k, j, i);
  });

  return;
}


//----------------------------------------------------------------------------------------
//! \fn void Multigrid::LoadSource(const DvceArray5D<Real> &src, int ns, int ngh,
//!                                Real fac)
//! \brief Fill the source in the active zone of the finest level

void Multigrid::LoadSource(const DvceArray5D<Real> &src, int ns, int ngh, Real fac) {
  auto &dst = src_[nlevel_-1].d_view;
  int sngh = std::min(ngh_, ngh);
  int is, ie, js, je, ks, ke;
  is = js = ks = ngh_ - sngh;
  ie = is + indcs_.nx1 + 2*sngh - 1;
  je = js + indcs_.nx2 + 2*sngh - 1;
  ke = ks + indcs_.nx3 + 2*sngh - 1;

  // local copies for device lambda capture
  const Real lfac = fac;
  const int m0 = 0, m1 = nmmb_ - 1;
  const int v0 = 0, v1 = nvar_ - 1;
  const int src_off = ngh - ngh_;

  par_for("Multigrid::LoadSource", DevExeSpace(),
          m0, m1, v0, v1, ks, ke, js, je, is, ie,
  KOKKOS_LAMBDA(const int m, const int v, const int mk, const int mj, const int mi) {
    const int nsrc = ns + v;
    const int k = mk + src_off;
    const int j = mj + src_off;
    const int i = mi + src_off;
    if (lfac == (Real)1.0) {
      dst(m, v, mk, mj, mi) = src(m, nsrc, k, j, i);
    } else {
      dst(m, v, mk, mj, mi) = src(m, nsrc, k, j, i) * lfac;
    }
  });

  current_level_ = nlevel_-1;
  return;
}


//----------------------------------------------------------------------------------------
//! \fn void Multigrid::LoadCoefficients(const DvceArray5D<Real> &coeff, int ngh)
//! \brief Load coefficients of the diffusion and source terms

void Multigrid::LoadCoefficients(const DvceArray5D<Real> &coeff, int ngh) {
  auto &cm = coeff_[nlevel_-1].d_view;
  int is, ie, js, je, ks, ke;
  is = js = ks = 0;
  ie = indcs_.nx1 + 2*ngh_ - 1;
  je = indcs_.nx2 + 2*ngh_ - 1;
  ke = indcs_.nx3 + 2*ngh_ - 1;

  // copy locals for device lambda capture
  const int coeff_off = ngh - ngh_;
  const int m0 = 0, m1 = nmmb_ - 1;
  const int v0 = 0, v1 = ncoeff_ - 1;

  auto cm_ = cm;
  auto coeff_ = coeff;

  par_for("Multigrid::LoadCoefficients", DevExeSpace(),
          m0, m1, v0, v1, ks, ke, js, je, is, ie,
  KOKKOS_LAMBDA(const int m, const int v, const int mk, const int mj, const int mi) {
    const int k = mk + coeff_off;
    const int j = mj + coeff_off;
    const int i = mi + coeff_off;
    cm_(m, v, mk, mj, mi) = coeff_(m, v, k, j, i);
  });

  return;
}


//----------------------------------------------------------------------------------------
//! \fn void Multigrid::ApplyMask()
//  \brief Apply the user-defined source mask function on the finest level

void Multigrid::ApplyMask() {
  Real mask_r = pmy_driver_->mask_radius_;
  if (mask_r <= 0.0) return;

  int ngh = ngh_;
  int nx1 = indcs_.nx1, nx2 = indcs_.nx2, nx3 = indcs_.nx3;
  int nmb = nmmb_;
  Real mask_r2 = mask_r * mask_r;
  Real ox = pmy_driver_->mask_origin_[0];
  Real oy = pmy_driver_->mask_origin_[1];
  Real oz = pmy_driver_->mask_origin_[2];

  auto src = src_[nlevel_-1].d_view;
  auto &mb_size = pmy_pack_->pmb->mb_size;
  auto &indcs = pmy_pack_->pmesh->mb_indcs;
  int is = indcs.is, js = indcs.js, ks = indcs.ks;

  par_for("Multigrid::ApplyMask", DevExeSpace(), 0, nmb-1,
          ngh, ngh+nx3-1, ngh, ngh+nx2-1, ngh, ngh+nx1-1,
  KOKKOS_LAMBDA(const int m, const int k, const int j, const int i) {
    Real x = CellCenterX(i - ngh, nx1, mb_size.d_view(m).x1min, mb_size.d_view(m).x1max);
    Real y = CellCenterX(j - ngh, nx2, mb_size.d_view(m).x2min, mb_size.d_view(m).x2max);
    Real z = CellCenterX(k - ngh, nx3, mb_size.d_view(m).x3min, mb_size.d_view(m).x3max);
    Real r2 = (x-ox)*(x-ox) + (y-oy)*(y-oy) + (z-oz)*(z-oz);
    if (r2 > mask_r2) {
      src(m, 0, k, j, i) = 0.0;
    }
  });
}


//----------------------------------------------------------------------------------------
//! \fn void Multigrid::RestrictCoefficients()
//! \brief restrict coefficients within a Multigrid object

void Multigrid::RestrictCoefficients() {
  int is, ie, js, je, ks, ke;
  is=js=ks=ngh_;
  if (on_host_) {
    for (int lev = nlevel_ - 1; lev > 0; lev--) {
      int ll = nlevel_ - lev;
      ie=is+(indcs_.nx1>>ll)-1, je=js+(indcs_.nx2>>ll)-1, ke=ks+(indcs_.nx3>>ll)-1;
      Restrict(coeff_[lev-1].h_view, coeff_[lev].h_view, ncoeff_,
               is, ie, js, je, ks, ke, false);
    }
  } else {
    for (int lev = nlevel_ - 1; lev > 0; lev--) {
      int ll = nlevel_ - lev;
      ie=is+(indcs_.nx1>>ll)-1, je=js+(indcs_.nx2>>ll)-1, ke=ks+(indcs_.nx3>>ll)-1;
      Restrict(coeff_[lev-1].d_view, coeff_[lev].d_view, ncoeff_,
               is, ie, js, je, ks, ke, false);
    }
  }
}


//----------------------------------------------------------------------------------------
//! \fn void Multigrid::RetrieveResult(DvceArray5D<Real> &dst, int ns, int ngh)
//! \brief Set the result, including the ghost zone

void Multigrid::RetrieveResult(DvceArray5D<Real> &dst, int ns, int ngh) {
  const auto &src = u_[nlevel_-1].d_view;
  int sngh = std::min(ngh_,ngh);

  if (ns == 0 && ngh_ == ngh && nvar_ == 1
      && src.extent(0) == dst.extent(0)
      && src.extent(2) == dst.extent(2)
      && src.extent(3) == dst.extent(3)
      && src.extent(4) == dst.extent(4)) {
    Kokkos::deep_copy(dst, src);
  } else {
    int is, ie, js, je, ks, ke;
    is = js = ks = ngh_ - sngh;
    ie = indcs_.nx1 + ngh_ + sngh - 1;
    je = indcs_.nx2 + ngh_ + sngh - 1;
    ke = indcs_.nx3 + ngh_ + sngh - 1;

    const int dst_off = ngh - ngh_;

    par_for("Multigrid::RetrieveResult", DevExeSpace(),
            0, nmmb_-1, 0, nvar_-1, ks, ke, js, je, is, ie,
    KOKKOS_LAMBDA(const int m, const int v, const int mk, const int mj, const int mi) {
      const int ndst = ns + v;
      const int k = mk + dst_off;
      const int j = mj + dst_off;
      const int i = mi + dst_off;
      dst(m, ndst, k, j, i) = src(m, v, mk, mj, mi);
    });
  }

  return;
}


//----------------------------------------------------------------------------------------
//! \fn void Multigrid::RetrieveDefect(DvceArray5D<Real> &dst, int ns, int ngh)
//! \brief Set the defect, including the ghost zone

void Multigrid::RetrieveDefect(DvceArray5D<Real> &dst, int ns, int ngh) {
  const auto &src = def_[nlevel_-1].d_view;
  int sngh = std::min(ngh_,ngh);
  int ie = indcs_.nx1 + ngh_ + sngh - 1;
  int je = indcs_.nx2 + ngh_ + sngh - 1;
  int ke = indcs_.nx3 + ngh_ + sngh - 1;

  // local copies for device lambda capture
  const int m0 = 0, m1 = nmmb_ - 1;
  const int v0 = 0, v1 = nvar_ - 1;
  const int mk0 = ngh_ - sngh, mk1 = ke;
  const int mj0 = ngh_ - sngh, mj1 = je;
  const int mi0 = ngh_ - sngh, mi1 = ie;
  const Real scale = defscale_;
  const int dst_off = ngh - ngh_;

  auto dst_ = dst;
  auto src_ = src;

  par_for("Multigrid::RetrieveDefect", DevExeSpace(),
          m0, m1, v0, v1, mk0, mk1, mj0, mj1, mi0, mi1,
  KOKKOS_LAMBDA(const int m, const int v, const int mk, const int mj, const int mi) {
    const int ndst = ns + v;
    const int k = mk + dst_off;
    const int j = mj + dst_off;
    const int i = mi + dst_off;
    dst_(m, ndst, k, j, i) = src_(m, v, mk, mj, mi) * scale;
  });

  return;
}


//----------------------------------------------------------------------------------------
//! \fn void Multigrid::ZeroClearData()
//! \brief Clear the data array with zero

void Multigrid::ZeroClearData() {
  if (on_host_) {
    Kokkos::deep_copy(u_[current_level_].h_view, 0.0);
  } else {
    Kokkos::deep_copy(u_[current_level_].d_view, 0.0);
  }
}

void Multigrid::CopySourceToData() {
  if (on_host_) {
    Kokkos::deep_copy(u_[nlevel_-1].h_view, src_[nlevel_-1].h_view);
  } else {
    Kokkos::deep_copy(u_[nlevel_-1].d_view, src_[nlevel_-1].d_view);
  }
}

//----------------------------------------------------------------------------------------
//! \fn void Multigrid::RestrictPack()
//! \brief Restrict the defect to the source

void Multigrid::RestrictPack() {
  int ll=nlevel_-current_level_;
  int is, ie, js, je, ks, ke;
  CalculateDefectPack();
  is=js=ks= ngh_;
  ie = is + (indcs_.nx1>>ll) - 1;
  je = js + (indcs_.nx2>>ll) - 1;
  ke = ks + (indcs_.nx3>>ll) - 1;
  if (on_host_) {
    Restrict(src_[current_level_-1].h_view, def_[current_level_].h_view,
             nvar_, is, ie, js, je, ks, ke, false);
    Restrict(u_[current_level_-1].h_view, u_[current_level_].h_view,
             nvar_, is, ie, js, je, ks, ke, false);
  } else {
    Restrict(src_[current_level_-1].d_view, def_[current_level_].d_view,
             nvar_, is, ie, js, je, ks, ke, false);
    Restrict(u_[current_level_-1].d_view, u_[current_level_].d_view,
             nvar_, is, ie, js, je, ks, ke, false);
  }
  current_level_--;
}

//----------------------------------------------------------------------------------------
//! \fn void Multigrid::RestrictSourcePack()
//! \brief Restrict the source (and solution) without forming defect

void Multigrid::RestrictSourcePack() {
  int ll=nlevel_-current_level_;
  int is, ie, js, je, ks, ke;
  is=js=ks= ngh_;
  ie = is+(indcs_.nx1>>ll) - 1;
  je = js+(indcs_.nx2>>ll) - 1;
  ke = ks+(indcs_.nx3>>ll) - 1;
  if (on_host_) {
    Restrict(src_[current_level_-1].h_view, src_[current_level_].h_view,
             nvar_, is, ie, js, je, ks, ke, false);
  } else {
    Restrict(src_[current_level_-1].d_view, src_[current_level_].d_view,
             nvar_, is, ie, js, je, ks, ke, false);
  }
  current_level_--;
}


//----------------------------------------------------------------------------------------
//! \fn void Multigrid::ProlongateAndCorrectPack()
//! \brief Prolongate the potential using tri-linear interpolation

void Multigrid::ProlongateAndCorrectPack() {
  int ll=nlevel_-1-current_level_;
  int is, ie, js, je, ks, ke;
  is=js=ks=ngh_;
  ie=is+(indcs_.nx1>>ll)-1;
  je=js+(indcs_.nx2>>ll)-1;
  ke=ks+(indcs_.nx3>>ll)-1;

  ComputeCorrection();

  if (on_host_) {
    ProlongateAndCorrect(u_[current_level_+1].h_view, u_[current_level_].h_view,
                         is, ie, js, je, ks, ke, ngh_, ngh_, ngh_, false);
  } else {
    ProlongateAndCorrect(u_[current_level_+1].d_view, u_[current_level_].d_view,
                         is, ie, js, je, ks, ke, ngh_, ngh_, ngh_, false);
  }

  current_level_++;
}

//----------------------------------------------------------------------------------------
//! \fn void Multigrid::FMGProlongatePack()
//! \brief Prolongate the solution for FMG (direct overwrite, always tricubic)

void Multigrid::FMGProlongatePack() {
  int ll=nlevel_-1-current_level_;
  int is, ie, js, je, ks, ke;
  is=js=ks=ngh_;
  ie=is+(indcs_.nx1>>ll)-1;
  je=js+(indcs_.nx2>>ll)-1;
  ke=ks+(indcs_.nx3>>ll)-1;

  if (on_host_) {
    FMGProlongate(u_[current_level_+1].h_view, u_[current_level_].h_view,
                  is, ie, js, je, ks, ke, ngh_, ngh_, ngh_);
  } else {
    FMGProlongate(u_[current_level_+1].d_view, u_[current_level_].d_view,
                  is, ie, js, je, ks, ke, ngh_, ngh_, ngh_);
  }

  current_level_++;
}


//----------------------------------------------------------------------------------------
//! \fn  void Multigrid::SmoothPack(int color)
//! \brief Apply Smoother on the Pack


//----------------------------------------------------------------------------------------
//! \fn void Multigrid::SetFromRootGrid(bool folddata)
//! \brief Load the data from the root grid or octets (Athena++ style per-cell octets)

void Multigrid::SetFromRootGrid(bool folddata) {
  current_level_ = 0;
  auto dst_h = u_[current_level_].h_view;
  auto odst_h = uold_[current_level_].h_view;

  auto src_h = pmy_driver_->GetRootData_h();
  auto osrc_h = pmy_driver_->GetRootOldData_h();
  int padding = pmy_mesh_->gids_eachrank[global_variable::my_rank];

  for (int m = 0; m < nmmb_; ++m) {
    auto loc = pmy_mesh_->lloc_eachmb[m + padding];
    int lev = loc.level - pmy_driver_->locrootlevel_;
    if (lev == 0) {
      int ci = static_cast<int>(loc.lx1);
      int cj = static_cast<int>(loc.lx2);
      int ck = static_cast<int>(loc.lx3);
      for (int v = 0; v < nvar_; ++v) {
        for (int k = 0; k <= 2*ngh_; ++k) {
          for (int j = 0; j <= 2*ngh_; ++j) {
            for (int i = 0; i <= 2*ngh_; ++i) {
              dst_h(m, v, k, j, i) = src_h(0, v, ck+k, cj+j, ci+i);
              if (folddata)
                odst_h(m, v, k, j, i) = osrc_h(0, v, ck+k, cj+j, ci+i);
            }
          }
        }
      }
    } else {
      LogicalLocation oloc;
      oloc.lx1 = (loc.lx1 >> 1);
      oloc.lx2 = (loc.lx2 >> 1);
      oloc.lx3 = (loc.lx3 >> 1);
      oloc.level = loc.level - 1;
      int olev = oloc.level - pmy_driver_->locrootlevel_;
      int oid = pmy_driver_->octetmap_[olev][oloc];
      int ci = (static_cast<int>(loc.lx1) & 1);
      int cj = (static_cast<int>(loc.lx2) & 1);
      int ck = (static_cast<int>(loc.lx3) & 1);
      const MGOctet &oct = pmy_driver_->octets_[olev][oid];
      for (int v = 0; v < nvar_; ++v) {
        for (int k = 0; k <= 2*ngh_; ++k) {
          for (int j = 0; j <= 2*ngh_; ++j) {
            for (int i = 0; i <= 2*ngh_; ++i) {
              dst_h(m, v, k, j, i) = oct.U(v, ck+k, cj+j, ci+i);
              if (folddata)
                odst_h(m, v, k, j, i) = oct.Uold(v, ck+k, cj+j, ci+i);
            }
          }
        }
      }
    }
  }
  u_[current_level_].template modify<HostExeSpace>();
  u_[current_level_].template sync<DevExeSpace>();
  if (folddata) {
    uold_[current_level_].template modify<HostExeSpace>();
    uold_[current_level_].template sync<DevExeSpace>();
  }
  return;
}


//----------------------------------------------------------------------------------------
//! \fn Real Multigrid::CalculateDefectNorm(MGNormType nrm, int n)
//! \brief calculate the residual norm

Real Multigrid::CalculateDefectNorm(MGNormType nrm, int n) {
  int ll=nlevel_-1-current_level_;
  int is, ie, js, je, ks, ke;
  is=js=ks=ngh_;
  ie=is+(indcs_.nx1>>ll)-1, je=js+(indcs_.nx2>>ll)-1, ke=ks+(indcs_.nx3>>ll)-1;
  Real dx = rdx_ * static_cast<Real>(1 << ll);
  Real dy = rdy_ * static_cast<Real>(1 << ll);
  Real dz = rdz_ * static_cast<Real>(1 << ll);
  Real dV = dx * dy * dz;
  CalculateDefectPack();

  Real norm = 0.0;

  if (on_host_) {
    auto &def = def_[current_level_].h_view;
    if (nrm == MGNormType::max) {
      Kokkos::parallel_reduce("MG::DefectNorm_Linf",
        Kokkos::MDRangePolicy<HostExeSpace, Kokkos::Rank<5>>(
            {0, n, ks, js, is}, {nmmb_, n+1, ke+1, je+1, ie+1}),
        KOKKOS_LAMBDA(const int m, const int v, const int k, const int j,
                       const int i, Real &local_max) {
          local_max = std::max(local_max, std::abs(def(m, v, k, j, i)));
        }, Kokkos::Max<Real>(norm));
      return norm;
    } else if (nrm == MGNormType::l1) {
      Kokkos::parallel_reduce("MG::DefectNorm_L1",
        Kokkos::MDRangePolicy<HostExeSpace, Kokkos::Rank<5>>(
            {0, n, ks, js, is}, {nmmb_, n+1, ke+1, je+1, ie+1}),
        KOKKOS_LAMBDA(const int m, const int v, const int k, const int j,
                       const int i, Real &local_sum) {
          local_sum += std::abs(def(m, v, k, j, i));
        }, Kokkos::Sum<Real>(norm));
    } else {
      Kokkos::parallel_reduce("MG::DefectNorm_L2",
        Kokkos::MDRangePolicy<HostExeSpace, Kokkos::Rank<5>>(
            {0, n, ks, js, is}, {nmmb_, n+1, ke+1, je+1, ie+1}),
        KOKKOS_LAMBDA(const int m, const int v, const int k, const int j,
                       const int i, Real &local_sum) {
          Real val = def(m, v, k, j, i);
          local_sum += val * val;
        }, Kokkos::Sum<Real>(norm));
    }
  } else {
    auto &def = def_[current_level_].d_view;
    if (nrm == MGNormType::max) {
      Kokkos::parallel_reduce("MG::DefectNorm_Linf",
        Kokkos::MDRangePolicy<DevExeSpace, Kokkos::Rank<5>>(
            {0, n, ks, js, is}, {nmmb_, n+1, ke+1, je+1, ie+1}),
        KOKKOS_LAMBDA(const int m, const int v, const int k, const int j,
                       const int i, Real &local_max) {
          local_max = std::max(local_max, std::abs(def(m, v, k, j, i)));
        }, Kokkos::Max<Real>(norm));
      return norm;
    } else if (nrm == MGNormType::l1) {
      Kokkos::parallel_reduce("MG::DefectNorm_L1",
        Kokkos::MDRangePolicy<DevExeSpace, Kokkos::Rank<5>>(
            {0, n, ks, js, is}, {nmmb_, n+1, ke+1, je+1, ie+1}),
        KOKKOS_LAMBDA(const int m, const int v, const int k, const int j,
                       const int i, Real &local_sum) {
          local_sum += std::abs(def(m, v, k, j, i));
        }, Kokkos::Sum<Real>(norm));
    } else {
      Kokkos::parallel_reduce("MG::DefectNorm_L2",
        Kokkos::MDRangePolicy<DevExeSpace, Kokkos::Rank<5>>(
            {0, n, ks, js, is}, {nmmb_, n+1, ke+1, je+1, ie+1}),
        KOKKOS_LAMBDA(const int m, const int v, const int k, const int j,
                       const int i, Real &local_sum) {
          Real val = def(m, v, k, j, i);
          local_sum += val * val;
        }, Kokkos::Sum<Real>(norm));
    }
  }
  norm *= defscale_;
  return norm;
}

//----------------------------------------------------------------------------------------
//! \fn Real Multigrid::CalculateAverage(MGVariable type)
//! \brief Calculate volume-weighted average of variable 0 on current level

Real Multigrid::CalculateAverage(MGVariable type) {
  int ll = nlevel_ - 1 - current_level_;
  int is, ie, js, je, ks, ke;
  is = js = ks = ngh_;
  ie = is + (indcs_.nx1 >> ll) - 1;
  je = js + (indcs_.nx2 >> ll) - 1;
  ke = ks + (indcs_.nx3 >> ll) - 1;
  int ll_l = ll;

  Real sum = 0.0;
  if (on_host_) {
    auto data = (type == MGVariable::src) ? src_[current_level_].h_view
                                          : u_[current_level_].h_view;
    auto brdx = block_rdx_.h_view;
    Kokkos::parallel_reduce("MG::Average",
      Kokkos::MDRangePolicy<HostExeSpace, Kokkos::Rank<4>>({0, ks, js, is},
                                                            {nmmb_, ke+1, je+1, ie+1}),
      KOKKOS_LAMBDA(const int m, const int k, const int j, const int i, Real &local_sum) {
        Real dx_m = brdx(m) * static_cast<Real>(1 << ll_l);
        Real dV_m = dx_m * dx_m * dx_m;
        local_sum += data(m, 0, k, j, i) * dV_m;
      }, Kokkos::Sum<Real>(sum));
  } else {
    auto data = (type == MGVariable::src) ? src_[current_level_].d_view
                                          : u_[current_level_].d_view;
    auto brdx = block_rdx_.d_view;
    Kokkos::parallel_reduce("MG::Average",
      Kokkos::MDRangePolicy<DevExeSpace, Kokkos::Rank<4>>({0, ks, js, is},
                                                           {nmmb_, ke+1, je+1, ie+1}),
      KOKKOS_LAMBDA(const int m, const int k, const int j, const int i, Real &local_sum) {
        Real dx_m = brdx(m) * static_cast<Real>(1 << ll_l);
        Real dV_m = dx_m * dx_m * dx_m;
        local_sum += data(m, 0, k, j, i) * dV_m;
      }, Kokkos::Sum<Real>(sum));
  }

  Real volume = 0.0;
  {
    Real nx = static_cast<Real>(indcs_.nx1);
    for (int m = 0; m < nmmb_; ++m) {
      Real len = block_rdx_.h_view(m) * nx;
      volume += len * len * len;
    }
  }

  #if MPI_PARALLEL_ENABLED
  Real global_sum = 0.0;
  Real global_volume = 0.0;
  MPI_Allreduce(&sum, &global_sum, 1, MPI_ATHENA_REAL, MPI_SUM, MPI_COMM_WORLD);
  MPI_Allreduce(&volume, &global_volume, 1, MPI_ATHENA_REAL, MPI_SUM, MPI_COMM_WORLD);
  sum = global_sum;
  volume = global_volume;
  #endif

  return (volume > 0.0) ? (sum / volume) : 0.0;
}

//----------------------------------------------------------------------------------------
//! \fn Real Multigrid::SubtractAverage(MGVariable type, int v, Real ave)
//! \brief subtract the average value (type: 0=src, 1=u)

void Multigrid::SubtractAverage(MGVariable type, int n, Real ave) {
  int is, ie, js, je, ks, ke;
  is = js = ks = 0;
  ie = is + indcs_.nx1 + 2*ngh_ - 1;
  je = js + indcs_.nx2 + 2*ngh_ - 1;
  ke = ks + indcs_.nx3 + 2*ngh_ - 1;

  const int m0 = 0, m1 = nmmb_ - 1;
  const int vn = n;
  const Real lave = ave;

  if (on_host_) {
    auto dst = (type == MGVariable::src) ? src_[nlevel_-1].h_view
                                         : u_[nlevel_-1].h_view;
    par_for("Multigrid::SubtractAverage", HostExeSpace(),
            m0, m1, ks, ke, js, je, is, ie,
    KOKKOS_LAMBDA(const int m, const int mk, const int mj, const int mi) {
      dst(m, vn, mk, mj, mi) -= lave;
    });
  } else {
    auto dst = (type == MGVariable::src) ? src_[nlevel_-1].d_view
                                         : u_[nlevel_-1].d_view;
    par_for("Multigrid::SubtractAverage", DevExeSpace(),
            m0, m1, ks, ke, js, je, is, ie,
    KOKKOS_LAMBDA(const int m, const int mk, const int mj, const int mi) {
      dst(m, vn, mk, mj, mi) -= lave;
    });
  }
}


//----------------------------------------------------------------------------------------
//! \fn void Multigrid::StoreOldData()
//! \brief store the old u data in the uold array

void Multigrid::StoreOldData() {
  if (on_host_) {
    Kokkos::deep_copy(HostExeSpace(), uold_[current_level_].h_view,
                      u_[current_level_].h_view);
  } else {
    Kokkos::deep_copy(DevExeSpace(), uold_[current_level_].d_view,
                      u_[current_level_].d_view);
  }
}

//----------------------------------------------------------------------------------------
//! \fn void Multigrid::Restrict(...)
//  \brief Actual implementation of restriction (templated on view type)

template <typename ViewType>
void Multigrid::Restrict(ViewType &dst, const ViewType &src,
                int nvar, int i0, int i1, int j0, int j1, int k0, int k1, bool th) {
  using ExeSpace = typename ViewType::execution_space;
  const int m0 = 0, m1 = nmmb_ - 1;
  const int v0 = 0, v1 = nvar - 1;
  const int ngh = ngh_;

  par_for("Multigrid::Restrict", ExeSpace(),
          m0, m1, v0, v1, k0, k1, j0, j1, i0, i1,
  KOKKOS_LAMBDA(const int m, const int v, const int k, const int j, const int i) {
    const int fk = 2*k - ngh;
    const int fj = 2*j - ngh;
    const int fi = 2*i - ngh;
    dst(m, v, k, j, i) = 0.125 * (
        src(m, v, fk,   fj,   fi)   + src(m, v, fk,   fj,   fi+1)
      + src(m, v, fk,   fj+1, fi)   + src(m, v, fk,   fj+1, fi+1)
      + src(m, v, fk+1, fj,   fi)   + src(m, v, fk+1, fj,   fi+1)
      + src(m, v, fk+1, fj+1, fi)   + src(m, v, fk+1, fj+1, fi+1));
  });
  return;
}

//----------------------------------------------------------------------------------------
//! \fn void Multigrid::ComputeCorrection(DvceArray5D<Real> &correction, int level)
//! \brief Compute the correction as u_[level] - uold_[level]

void Multigrid::ComputeCorrection() {
  const int m0 = 0, m1 = nmmb_ - 1;
  const int v0 = 0, v1 = nvar_ - 1;
  int ll = nlevel_ - 1 - current_level_;
  int is = 0, ie = is + (indcs_.nx1 >> ll) + 2*ngh_ - 1;
  int js = 0, je = js + (indcs_.nx2 >> ll) + 2*ngh_ - 1;
  int ks = 0, ke = ks + (indcs_.nx3 >> ll) + 2*ngh_ - 1;

  if (on_host_) {
    auto u = u_[current_level_].h_view;
    auto uold = uold_[current_level_].h_view;
    par_for("Multigrid::ComputeCorrection", HostExeSpace(),
            m0, m1, v0, v1, ks, ke, js, je, is, ie,
    KOKKOS_LAMBDA(const int m, const int v, const int k, const int j, const int i) {
      u(m, v, k, j, i) -= uold(m, v, k, j, i);
    });
  } else {
    auto u = u_[current_level_].d_view;
    auto uold = uold_[current_level_].d_view;
    par_for("Multigrid::ComputeCorrection", DevExeSpace(),
            m0, m1, v0, v1, ks, ke, js, je, is, ie,
    KOKKOS_LAMBDA(const int m, const int v, const int k, const int j, const int i) {
      u(m, v, k, j, i) -= uold(m, v, k, j, i);
    });
  }
}

//----------------------------------------------------------------------------------------
//! \fn void Multigrid::ProlongateAndCorrect(...)
//! \brief Actual implementation of prolongation and correction (templated on view type)

template <typename ViewType>
void Multigrid::ProlongateAndCorrect(ViewType &dst, const ViewType &src,
     int il, int iu, int jl, int ju, int kl, int ku, int fil, int fjl, int fkl, bool th) {
  using ExeSpace = typename ViewType::execution_space;
  const int m0 = 0, m1 = nmmb_ - 1;
  const int v0 = 0, v1 = nvar_ - 1;
  const int k0 = kl, k1 = ku;
  const int j0 = jl, j1 = ju;
  const int i0 = il, i1 = iu;

  const int ll = pmy_driver_->fprolongation_; // copy host flag for capture

  auto dst_ = dst;
  auto src_ = src;

  if (ll == 1) { // tricubic
    par_for("Multigrid::ProlongateAndCorrect_tricubic", ExeSpace(),
            m0, m1, v0, v1, k0, k1, j0, j1, i0, i1,
    KOKKOS_LAMBDA(const int m, const int v, const int k, const int j, const int i) {
      const int fk = 2*(k-kl) + fkl;
      const int fj = 2*(j-jl) + fjl;
      const int fi = 2*(i-il) + fil;

      // For brevity: local references to src entries
      // compute and add to 8 target cells as in original implementation
      dst_(m,v,fk  ,fj  ,fi  ) += (
      +125.*src_(m,v,k-1,j-1,i-1)+750.*src_(m,v,k-1,j-1,i)-75.*src_(m,v,k-1,j-1,i+1)
      +750.*src_(m,v,k-1,j,i-1)+4500.*src_(m,v,k-1,j,i)-450.*src_(m,v,k-1,j,i+1)
      -75.*src_(m,v,k-1,j+1,i-1)-450.*src_(m,v,k-1,j+1,i)+45.*src_(m,v,k-1,j+1,i+1)
      +750.*src_(m,v,k,j-1,i-1)+4500.*src_(m,v,k,j-1,i)-450.*src_(m,v,k,j-1,i+1)
      +4500.*src_(m,v,k,j,i-1)+27000.*src_(m,v,k,j,i)-2700.*src_(m,v,k,j,i+1)
      -450.*src_(m,v,k,j+1,i-1)-2700.*src_(m,v,k,j+1,i)+270.*src_(m,v,k,j+1,i+1)
      -75.*src_(m,v,k+1,j-1,i-1)-450.*src_(m,v,k+1,j-1,i)+45.*src_(m,v,k+1,j-1,i+1)
      -450.*src_(m,v,k+1,j,i-1)-2700.*src_(m,v,k+1,j,i)+270.*src_(m,v,k+1,j,i+1)
      +45.*src_(m,v,k+1,j+1,i-1)+270.*src_(m,v,k+1,j+1,i)-27.*src_(m,v,k+1,j+1,i+1)
      ) / 32768.0;

      dst_(m,v,fk,  fj,  fi+1) += (
      -75.*src_(m,v,k-1,j-1,i-1)+750.*src_(m,v,k-1,j-1,i)+125.*src_(m,v,k-1,j-1,i+1)
      -450.*src_(m,v,k-1,j,i-1)+4500.*src_(m,v,k-1,j,i)+750.*src_(m,v,k-1,j,i+1)
      +45.*src_(m,v,k-1,j+1,i-1)-450.*src_(m,v,k-1,j+1,i)-75.*src_(m,v,k-1,j+1,i+1)
      -450.*src_(m,v,k,j-1,i-1)+4500.*src_(m,v,k,j-1,i)+750.*src_(m,v,k,j-1,i+1)
      -2700.*src_(m,v,k,j,i-1)+27000.*src_(m,v,k,j,i)+4500.*src_(m,v,k,j,i+1)
      +270.*src_(m,v,k,j+1,i-1)-2700.*src_(m,v,k,j+1,i)-450.*src_(m,v,k,j+1,i+1)
      +45.*src_(m,v,k+1,j-1,i-1)-450.*src_(m,v,k+1,j-1,i)-75.*src_(m,v,k+1,j-1,i+1)
      +270.*src_(m,v,k+1,j,i-1)-2700.*src_(m,v,k+1,j,i)-450.*src_(m,v,k+1,j,i+1)
      -27.*src_(m,v,k+1,j+1,i-1)+270.*src_(m,v,k+1,j+1,i)+45.*src_(m,v,k+1,j+1,i+1)
      ) / 32768.0;

      dst_(m,v,fk  ,fj+1,fi  ) += (
      -75.*src_(m,v,k-1,j-1,i-1)-450.*src_(m,v,k-1,j-1,i)+45.*src_(m,v,k-1,j-1,i+1)
      +750.*src_(m,v,k-1,j,i-1)+4500.*src_(m,v,k-1,j,i)-450.*src_(m,v,k-1,j,i+1)
      +125.*src_(m,v,k-1,j+1,i-1)+750.*src_(m,v,k-1,j+1,i)-75.*src_(m,v,k-1,j+1,i+1)
      -450.*src_(m,v,k,j-1,i-1)-2700.*src_(m,v,k,j-1,i)+270.*src_(m,v,k,j-1,i+1)
      +4500.*src_(m,v,k,j,i-1)+27000.*src_(m,v,k,j,i)-2700.*src_(m,v,k,j,i+1)
      +750.*src_(m,v,k,j+1,i-1)+4500.*src_(m,v,k,j+1,i)-450.*src_(m,v,k,j+1,i+1)
      +45.*src_(m,v,k+1,j-1,i-1)+270.*src_(m,v,k+1,j-1,i)-27.*src_(m,v,k+1,j-1,i+1)
      -450.*src_(m,v,k+1,j,i-1)-2700.*src_(m,v,k+1,j,i)+270.*src_(m,v,k+1,j,i+1)
      -75.*src_(m,v,k+1,j+1,i-1)-450.*src_(m,v,k+1,j+1,i)+45.*src_(m,v,k+1,j+1,i+1)
      ) / 32768.0;

      dst_(m,v,fk,  fj+1,fi+1) += (
      +45.*src_(m,v,k-1,j-1,i-1)-450.*src_(m,v,k-1,j-1,i)-75.*src_(m,v,k-1,j-1,i+1)
      -450.*src_(m,v,k-1,j,i-1)+4500.*src_(m,v,k-1,j,i)+750.*src_(m,v,k-1,j,i+1)
      -75.*src_(m,v,k-1,j+1,i-1)+750.*src_(m,v,k-1,j+1,i)+125.*src_(m,v,k-1,j+1,i+1)
      +270.*src_(m,v,k,j-1,i-1)-2700.*src_(m,v,k,j-1,i)-450.*src_(m,v,k,j-1,i+1)
      -2700.*src_(m,v,k,j,i-1)+27000.*src_(m,v,k,j,i)+4500.*src_(m,v,k,j,i+1)
      -450.*src_(m,v,k,j+1,i-1)+4500.*src_(m,v,k,j+1,i)+750.*src_(m,v,k,j+1,i+1)
      -27.*src_(m,v,k+1,j-1,i-1)+270.*src_(m,v,k+1,j-1,i)+45.*src_(m,v,k+1,j-1,i+1)
      +270.*src_(m,v,k+1,j,i-1)-2700.*src_(m,v,k+1,j,i)-450.*src_(m,v,k+1,j,i+1)
      +45.*src_(m,v,k+1,j+1,i-1)-450.*src_(m,v,k+1,j+1,i)-75.*src_(m,v,k+1,j+1,i+1)
      ) / 32768.0;

      dst_(m,v,fk+1,fj,  fi  ) += (
      -75.*src_(m,v,k-1,j-1,i-1)-450.*src_(m,v,k-1,j-1,i)+45.*src_(m,v,k-1,j-1,i+1)
      -450.*src_(m,v,k-1,j,i-1)-2700.*src_(m,v,k-1,j,i)+270.*src_(m,v,k-1,j,i+1)
      +45.*src_(m,v,k-1,j+1,i-1)+270.*src_(m,v,k-1,j+1,i)-27.*src_(m,v,k-1,j+1,i+1)
      +750.*src_(m,v,k,j-1,i-1)+4500.*src_(m,v,k,j-1,i)-450.*src_(m,v,k,j-1,i+1)
      +4500.*src_(m,v,k,j,i-1)+27000.*src_(m,v,k,j,i)-2700.*src_(m,v,k,j,i+1)
      -450.*src_(m,v,k,j+1,i-1)-2700.*src_(m,v,k,j+1,i)+270.*src_(m,v,k,j+1,i+1)
      +125.*src_(m,v,k+1,j-1,i-1)+750.*src_(m,v,k+1,j-1,i)-75.*src_(m,v,k+1,j-1,i+1)
      +750.*src_(m,v,k+1,j,i-1)+4500.*src_(m,v,k+1,j,i)-450.*src_(m,v,k+1,j,i+1)
      -75.*src_(m,v,k+1,j+1,i-1)-450.*src_(m,v,k+1,j+1,i)+45.*src_(m,v,k+1,j+1,i+1)
      ) / 32768.0;

      dst_(m,v,fk+1,fj,  fi+1) += (
      +45.*src_(m,v,k-1,j-1,i-1)-450.*src_(m,v,k-1,j-1,i)-75.*src_(m,v,k-1,j-1,i+1)
      +270.*src_(m,v,k-1,j,i-1)-2700.*src_(m,v,k-1,j,i)-450.*src_(m,v,k-1,j,i+1)
      -27.*src_(m,v,k-1,j+1,i-1)+270.*src_(m,v,k-1,j+1,i)+45.*src_(m,v,k-1,j+1,i+1)
      -450.*src_(m,v,k,j-1,i-1)+4500.*src_(m,v,k,j-1,i)+750.*src_(m,v,k,j-1,i+1)
      -2700.*src_(m,v,k,j,i-1)+27000.*src_(m,v,k,j,i)+4500.*src_(m,v,k,j,i+1)
      +270.*src_(m,v,k,j+1,i-1)-2700.*src_(m,v,k,j+1,i)-450.*src_(m,v,k,j+1,i+1)
      -75.*src_(m,v,k+1,j-1,i-1)+750.*src_(m,v,k+1,j-1,i)+125.*src_(m,v,k+1,j-1,i+1)
      -450.*src_(m,v,k+1,j,i-1)+4500.*src_(m,v,k+1,j,i)+750.*src_(m,v,k+1,j,i+1)
      +45.*src_(m,v,k+1,j+1,i-1)-450.*src_(m,v,k+1,j+1,i)-75.*src_(m,v,k+1,j+1,i+1)
      ) / 32768.0;

      dst_(m,v,fk+1,fj+1,fi  ) += (
      +45.*src_(m,v,k-1,j-1,i-1)+270.*src_(m,v,k-1,j-1,i)-27.*src_(m,v,k-1,j-1,i+1)
      -450.*src_(m,v,k-1,j,i-1)-2700.*src_(m,v,k-1,j,i)+270.*src_(m,v,k-1,j,i+1)
      -75.*src_(m,v,k-1,j+1,i-1)-450.*src_(m,v,k-1,j+1,i)+45.*src_(m,v,k-1,j+1,i+1)
      -450.*src_(m,v,k,j-1,i-1)-2700.*src_(m,v,k,j-1,i)+270.*src_(m,v,k,j-1,i+1)
      +4500.*src_(m,v,k,j,i-1)+27000.*src_(m,v,k,j,i)-2700.*src_(m,v,k,j,i+1)
      +750.*src_(m,v,k,j+1,i-1)+4500.*src_(m,v,k,j+1,i)-450.*src_(m,v,k,j+1,i+1)
      -75.*src_(m,v,k+1,j-1,i-1)-450.*src_(m,v,k+1,j-1,i)+45.*src_(m,v,k+1,j-1,i+1)
      +750.*src_(m,v,k+1,j,i-1)+4500.*src_(m,v,k+1,j,i)-450.*src_(m,v,k+1,j,i+1)
      +125.*src_(m,v,k+1,j+1,i-1)+750.*src_(m,v,k+1,j+1,i)-75.*src_(m,v,k+1,j+1,i+1)
      ) / 32768.0;

      dst_(m,v,fk+1,fj+1,fi+1) += (
      -27.*src_(m,v,k-1,j-1,i-1)+270.*src_(m,v,k-1,j-1,i)+45.*src_(m,v,k-1,j-1,i+1)
      +270.*src_(m,v,k-1,j,i-1)-2700.*src_(m,v,k-1,j,i)-450.*src_(m,v,k-1,j,i+1)
      +45.*src_(m,v,k-1,j+1,i-1)-450.*src_(m,v,k-1,j+1,i)-75.*src_(m,v,k-1,j+1,i+1)
      +270.*src_(m,v,k,j-1,i-1)-2700.*src_(m,v,k,j-1,i)-450.*src_(m,v,k,j-1,i+1)
      -2700.*src_(m,v,k,j,i-1)+27000.*src_(m,v,k,j,i)+4500.*src_(m,v,k,j,i+1)
      -450.*src_(m,v,k,j+1,i-1)+4500.*src_(m,v,k,j+1,i)+750.*src_(m,v,k,j+1,i+1)
      +45.*src_(m,v,k+1,j-1,i-1)-450.*src_(m,v,k+1,j-1,i)-75.*src_(m,v,k+1,j-1,i+1)
      -450.*src_(m,v,k+1,j,i-1)+4500.*src_(m,v,k+1,j,i)+750.*src_(m,v,k+1,j,i+1)
      -75.*src_(m,v,k+1,j+1,i-1)+750.*src_(m,v,k+1,j+1,i)+125.*src_(m,v,k+1,j+1,i+1)
      ) / 32768.0;
    });
  } else { // trilinear
    par_for("Multigrid::ProlongateAndCorrect_trilinear", ExeSpace(),
            m0, m1, v0, v1, k0, k1, j0, j1, i0, i1,
    KOKKOS_LAMBDA(const int m, const int v, const int k, const int j, const int i) {
      const int fk = 2*(k-kl) + fkl;
      const int fj = 2*(j-jl) + fjl;
      const int fi = 2*(i-il) + fil;

      dst_(m,v,fk  ,fj  ,fi  ) +=
          0.015625*(27.0*src_(m,v,k,j,i) + src_(m,v,k-1,j-1,i-1)
                    +9.0*(src_(m,v,k,j,i-1)+src_(m,v,k,j-1,i)+src_(m,v,k-1,j,i))
                    +3.0*(src_(m,v,k-1,j-1,i)+src_(m,v,k-1,j,i-1)+src_(m,v,k,j-1,i-1)));
      dst_(m,v,fk  ,fj  ,fi+1) +=
          0.015625*(27.0*src_(m,v,k,j,i) + src_(m,v,k-1,j-1,i+1)
                    +9.0*(src_(m,v,k,j,i+1)+src_(m,v,k,j-1,i)+src_(m,v,k-1,j,i))
                    +3.0*(src_(m,v,k-1,j-1,i)+src_(m,v,k-1,j,i+1)+src_(m,v,k,j-1,i+1)));
      dst_(m,v,fk  ,fj+1,fi  ) +=
          0.015625*(27.0*src_(m,v,k,j,i) + src_(m,v,k-1,j+1,i-1)
                    +9.0*(src_(m,v,k,j,i-1)+src_(m,v,k,j+1,i)+src_(m,v,k-1,j,i))
                    +3.0*(src_(m,v,k-1,j+1,i)+src_(m,v,k-1,j,i-1)+src_(m,v,k,j+1,i-1)));
      dst_(m,v,fk+1,fj  ,fi  ) +=
          0.015625*(27.0*src_(m,v,k,j,i) + src_(m,v,k+1,j-1,i-1)
                    +9.0*(src_(m,v,k,j,i-1)+src_(m,v,k,j-1,i)+src_(m,v,k+1,j,i))
                    +3.0*(src_(m,v,k+1,j-1,i)+src_(m,v,k+1,j,i-1)+src_(m,v,k,j-1,i-1)));
      dst_(m,v,fk+1,fj+1,fi  ) +=
          0.015625*(27.0*src_(m,v,k,j,i) + src_(m,v,k+1,j+1,i-1)
                    +9.0*(src_(m,v,k,j,i-1)+src_(m,v,k,j+1,i)+src_(m,v,k+1,j,i))
                    +3.0*(src_(m,v,k+1,j+1,i)+src_(m,v,k+1,j,i-1)+src_(m,v,k,j+1,i-1)));
      dst_(m,v,fk+1,fj  ,fi+1) +=
          0.015625*(27.0*src_(m,v,k,j,i) + src_(m,v,k+1,j-1,i+1)
                    +9.0*(src_(m,v,k,j,i+1)+src_(m,v,k,j-1,i)+src_(m,v,k+1,j,i))
                    +3.0*(src_(m,v,k+1,j-1,i)+src_(m,v,k+1,j,i+1)+src_(m,v,k,j-1,i+1)));
      dst_(m,v,fk  ,fj+1,fi+1) +=
          0.015625*(27.0*src_(m,v,k,j,i) + src_(m,v,k-1,j+1,i+1)
                    +9.0*(src_(m,v,k,j,i+1)+src_(m,v,k,j+1,i)+src_(m,v,k-1,j,i))
                    +3.0*(src_(m,v,k-1,j+1,i)+src_(m,v,k-1,j,i+1)+src_(m,v,k,j+1,i+1)));
      dst_(m,v,fk+1,fj+1,fi+1) +=
          0.015625*(27.0*src_(m,v,k,j,i) + src_(m,v,k+1,j+1,i+1)
                    +9.0*(src_(m,v,k,j,i+1)+src_(m,v,k,j+1,i)+src_(m,v,k+1,j,i))
                    +3.0*(src_(m,v,k+1,j+1,i)+src_(m,v,k+1,j,i+1)+src_(m,v,k,j+1,i+1)));
    });
  }
  return;
}


//----------------------------------------------------------------------------------------
//! \fn void Multigrid::FMGProlongate(...)
//! \brief FMG prolongation: direct overwrite (=) with tricubic interpolation.
//! Unlike ProlongateAndCorrect (+=), this overwrites the destination array.

template <typename ViewType>
void Multigrid::FMGProlongate(ViewType &dst, const ViewType &src,
     int il, int iu, int jl, int ju, int kl, int ku, int fil, int fjl, int fkl) {
  using ExeSpace = typename ViewType::execution_space;
  const int m0 = 0, m1 = nmmb_ - 1;
  const int v0 = 0, v1 = nvar_ - 1;
  const int k0 = kl, k1 = ku;
  const int j0 = jl, j1 = ju;
  const int i0 = il, i1 = iu;

  auto dst_ = dst;
  auto src_ = src;

  par_for("Multigrid::FMGProlongate", ExeSpace(),
          m0, m1, v0, v1, k0, k1, j0, j1, i0, i1,
  KOKKOS_LAMBDA(const int m, const int v, const int k, const int j, const int i) {
    const int fk = 2*(k-kl) + fkl;
    const int fj = 2*(j-jl) + fjl;
    const int fi = 2*(i-il) + fil;

    dst_(m,v,fk  ,fj  ,fi  ) = (
    +125.*src_(m,v,k-1,j-1,i-1)+750.*src_(m,v,k-1,j-1,i)-75.*src_(m,v,k-1,j-1,i+1)
    +750.*src_(m,v,k-1,j,i-1)+4500.*src_(m,v,k-1,j,i)-450.*src_(m,v,k-1,j,i+1)
    -75.*src_(m,v,k-1,j+1,i-1)-450.*src_(m,v,k-1,j+1,i)+45.*src_(m,v,k-1,j+1,i+1)
    +750.*src_(m,v,k,j-1,i-1)+4500.*src_(m,v,k,j-1,i)-450.*src_(m,v,k,j-1,i+1)
    +4500.*src_(m,v,k,j,i-1)+27000.*src_(m,v,k,j,i)-2700.*src_(m,v,k,j,i+1)
    -450.*src_(m,v,k,j+1,i-1)-2700.*src_(m,v,k,j+1,i)+270.*src_(m,v,k,j+1,i+1)
    -75.*src_(m,v,k+1,j-1,i-1)-450.*src_(m,v,k+1,j-1,i)+45.*src_(m,v,k+1,j-1,i+1)
    -450.*src_(m,v,k+1,j,i-1)-2700.*src_(m,v,k+1,j,i)+270.*src_(m,v,k+1,j,i+1)
    +45.*src_(m,v,k+1,j+1,i-1)+270.*src_(m,v,k+1,j+1,i)-27.*src_(m,v,k+1,j+1,i+1)
    ) / 32768.0;

    dst_(m,v,fk,  fj,  fi+1) = (
    -75.*src_(m,v,k-1,j-1,i-1)+750.*src_(m,v,k-1,j-1,i)+125.*src_(m,v,k-1,j-1,i+1)
    -450.*src_(m,v,k-1,j,i-1)+4500.*src_(m,v,k-1,j,i)+750.*src_(m,v,k-1,j,i+1)
    +45.*src_(m,v,k-1,j+1,i-1)-450.*src_(m,v,k-1,j+1,i)-75.*src_(m,v,k-1,j+1,i+1)
    -450.*src_(m,v,k,j-1,i-1)+4500.*src_(m,v,k,j-1,i)+750.*src_(m,v,k,j-1,i+1)
    -2700.*src_(m,v,k,j,i-1)+27000.*src_(m,v,k,j,i)+4500.*src_(m,v,k,j,i+1)
    +270.*src_(m,v,k,j+1,i-1)-2700.*src_(m,v,k,j+1,i)-450.*src_(m,v,k,j+1,i+1)
    +45.*src_(m,v,k+1,j-1,i-1)-450.*src_(m,v,k+1,j-1,i)-75.*src_(m,v,k+1,j-1,i+1)
    +270.*src_(m,v,k+1,j,i-1)-2700.*src_(m,v,k+1,j,i)-450.*src_(m,v,k+1,j,i+1)
    -27.*src_(m,v,k+1,j+1,i-1)+270.*src_(m,v,k+1,j+1,i)+45.*src_(m,v,k+1,j+1,i+1)
    ) / 32768.0;

    dst_(m,v,fk  ,fj+1,fi  ) = (
    -75.*src_(m,v,k-1,j-1,i-1)-450.*src_(m,v,k-1,j-1,i)+45.*src_(m,v,k-1,j-1,i+1)
    +750.*src_(m,v,k-1,j,i-1)+4500.*src_(m,v,k-1,j,i)-450.*src_(m,v,k-1,j,i+1)
    +125.*src_(m,v,k-1,j+1,i-1)+750.*src_(m,v,k-1,j+1,i)-75.*src_(m,v,k-1,j+1,i+1)
    -450.*src_(m,v,k,j-1,i-1)-2700.*src_(m,v,k,j-1,i)+270.*src_(m,v,k,j-1,i+1)
    +4500.*src_(m,v,k,j,i-1)+27000.*src_(m,v,k,j,i)-2700.*src_(m,v,k,j,i+1)
    +750.*src_(m,v,k,j+1,i-1)+4500.*src_(m,v,k,j+1,i)-450.*src_(m,v,k,j+1,i+1)
    +45.*src_(m,v,k+1,j-1,i-1)+270.*src_(m,v,k+1,j-1,i)-27.*src_(m,v,k+1,j-1,i+1)
    -450.*src_(m,v,k+1,j,i-1)-2700.*src_(m,v,k+1,j,i)+270.*src_(m,v,k+1,j,i+1)
    -75.*src_(m,v,k+1,j+1,i-1)-450.*src_(m,v,k+1,j+1,i)+45.*src_(m,v,k+1,j+1,i+1)
    ) / 32768.0;

    dst_(m,v,fk,  fj+1,fi+1) = (
    +45.*src_(m,v,k-1,j-1,i-1)-450.*src_(m,v,k-1,j-1,i)-75.*src_(m,v,k-1,j-1,i+1)
    -450.*src_(m,v,k-1,j,i-1)+4500.*src_(m,v,k-1,j,i)+750.*src_(m,v,k-1,j,i+1)
    -75.*src_(m,v,k-1,j+1,i-1)+750.*src_(m,v,k-1,j+1,i)+125.*src_(m,v,k-1,j+1,i+1)
    +270.*src_(m,v,k,j-1,i-1)-2700.*src_(m,v,k,j-1,i)-450.*src_(m,v,k,j-1,i+1)
    -2700.*src_(m,v,k,j,i-1)+27000.*src_(m,v,k,j,i)+4500.*src_(m,v,k,j,i+1)
    -450.*src_(m,v,k,j+1,i-1)+4500.*src_(m,v,k,j+1,i)+750.*src_(m,v,k,j+1,i+1)
    -27.*src_(m,v,k+1,j-1,i-1)+270.*src_(m,v,k+1,j-1,i)+45.*src_(m,v,k+1,j-1,i+1)
    +270.*src_(m,v,k+1,j,i-1)-2700.*src_(m,v,k+1,j,i)-450.*src_(m,v,k+1,j,i+1)
    +45.*src_(m,v,k+1,j+1,i-1)-450.*src_(m,v,k+1,j+1,i)-75.*src_(m,v,k+1,j+1,i+1)
    ) / 32768.0;

    dst_(m,v,fk+1,fj,  fi  ) = (
    -75.*src_(m,v,k-1,j-1,i-1)-450.*src_(m,v,k-1,j-1,i)+45.*src_(m,v,k-1,j-1,i+1)
    -450.*src_(m,v,k-1,j,i-1)-2700.*src_(m,v,k-1,j,i)+270.*src_(m,v,k-1,j,i+1)
    +45.*src_(m,v,k-1,j+1,i-1)+270.*src_(m,v,k-1,j+1,i)-27.*src_(m,v,k-1,j+1,i+1)
    +750.*src_(m,v,k,j-1,i-1)+4500.*src_(m,v,k,j-1,i)-450.*src_(m,v,k,j-1,i+1)
    +4500.*src_(m,v,k,j,i-1)+27000.*src_(m,v,k,j,i)-2700.*src_(m,v,k,j,i+1)
    -450.*src_(m,v,k,j+1,i-1)-2700.*src_(m,v,k,j+1,i)+270.*src_(m,v,k,j+1,i+1)
    +125.*src_(m,v,k+1,j-1,i-1)+750.*src_(m,v,k+1,j-1,i)-75.*src_(m,v,k+1,j-1,i+1)
    +750.*src_(m,v,k+1,j,i-1)+4500.*src_(m,v,k+1,j,i)-450.*src_(m,v,k+1,j,i+1)
    -75.*src_(m,v,k+1,j+1,i-1)-450.*src_(m,v,k+1,j+1,i)+45.*src_(m,v,k+1,j+1,i+1)
    ) / 32768.0;

    dst_(m,v,fk+1,fj,  fi+1) = (
    +45.*src_(m,v,k-1,j-1,i-1)-450.*src_(m,v,k-1,j-1,i)-75.*src_(m,v,k-1,j-1,i+1)
    +270.*src_(m,v,k-1,j,i-1)-2700.*src_(m,v,k-1,j,i)-450.*src_(m,v,k-1,j,i+1)
    -27.*src_(m,v,k-1,j+1,i-1)+270.*src_(m,v,k-1,j+1,i)+45.*src_(m,v,k-1,j+1,i+1)
    -450.*src_(m,v,k,j-1,i-1)+4500.*src_(m,v,k,j-1,i)+750.*src_(m,v,k,j-1,i+1)
    -2700.*src_(m,v,k,j,i-1)+27000.*src_(m,v,k,j,i)+4500.*src_(m,v,k,j,i+1)
    +270.*src_(m,v,k,j+1,i-1)-2700.*src_(m,v,k,j+1,i)-450.*src_(m,v,k,j+1,i+1)
    -75.*src_(m,v,k+1,j-1,i-1)+750.*src_(m,v,k+1,j-1,i)+125.*src_(m,v,k+1,j-1,i+1)
    -450.*src_(m,v,k+1,j,i-1)+4500.*src_(m,v,k+1,j,i)+750.*src_(m,v,k+1,j,i+1)
    +45.*src_(m,v,k+1,j+1,i-1)-450.*src_(m,v,k+1,j+1,i)-75.*src_(m,v,k+1,j+1,i+1)
    ) / 32768.0;

    dst_(m,v,fk+1,fj+1,fi  ) = (
    +45.*src_(m,v,k-1,j-1,i-1)+270.*src_(m,v,k-1,j-1,i)-27.*src_(m,v,k-1,j-1,i+1)
    -450.*src_(m,v,k-1,j,i-1)-2700.*src_(m,v,k-1,j,i)+270.*src_(m,v,k-1,j,i+1)
    -75.*src_(m,v,k-1,j+1,i-1)-450.*src_(m,v,k-1,j+1,i)+45.*src_(m,v,k-1,j+1,i+1)
    -450.*src_(m,v,k,j-1,i-1)-2700.*src_(m,v,k,j-1,i)+270.*src_(m,v,k,j-1,i+1)
    +4500.*src_(m,v,k,j,i-1)+27000.*src_(m,v,k,j,i)-2700.*src_(m,v,k,j,i+1)
    +750.*src_(m,v,k,j+1,i-1)+4500.*src_(m,v,k,j+1,i)-450.*src_(m,v,k,j+1,i+1)
    -75.*src_(m,v,k+1,j-1,i-1)-450.*src_(m,v,k+1,j-1,i)+45.*src_(m,v,k+1,j-1,i+1)
    +750.*src_(m,v,k+1,j,i-1)+4500.*src_(m,v,k+1,j,i)-450.*src_(m,v,k+1,j,i+1)
    +125.*src_(m,v,k+1,j+1,i-1)+750.*src_(m,v,k+1,j+1,i)-75.*src_(m,v,k+1,j+1,i+1)
    ) / 32768.0;

    dst_(m,v,fk+1,fj+1,fi+1) = (
    -27.*src_(m,v,k-1,j-1,i-1)+270.*src_(m,v,k-1,j-1,i)+45.*src_(m,v,k-1,j-1,i+1)
    +270.*src_(m,v,k-1,j,i-1)-2700.*src_(m,v,k-1,j,i)-450.*src_(m,v,k-1,j,i+1)
    +45.*src_(m,v,k-1,j+1,i-1)-450.*src_(m,v,k-1,j+1,i)-75.*src_(m,v,k-1,j+1,i+1)
    +270.*src_(m,v,k,j-1,i-1)-2700.*src_(m,v,k,j-1,i)-450.*src_(m,v,k,j-1,i+1)
    -2700.*src_(m,v,k,j,i-1)+27000.*src_(m,v,k,j,i)+4500.*src_(m,v,k,j,i+1)
    -450.*src_(m,v,k,j+1,i-1)+4500.*src_(m,v,k,j+1,i)+750.*src_(m,v,k,j+1,i+1)
    +45.*src_(m,v,k+1,j-1,i-1)-450.*src_(m,v,k+1,j-1,i)-75.*src_(m,v,k+1,j-1,i+1)
    -450.*src_(m,v,k+1,j,i-1)+4500.*src_(m,v,k+1,j,i)+750.*src_(m,v,k+1,j,i+1)
    -75.*src_(m,v,k+1,j+1,i-1)+750.*src_(m,v,k+1,j+1,i)+125.*src_(m,v,k+1,j+1,i+1)
    ) / 32768.0;
  });
  return;
}
