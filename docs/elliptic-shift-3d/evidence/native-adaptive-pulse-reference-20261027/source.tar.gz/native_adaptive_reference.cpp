// Copyright(C) 2026 AthenaK contributors. BSD-3-Clause; see LICENSE.
// Same-engine dispatch control replaying ACTUAL native topology and RK receipts.
#define main native_static_reference_main_unused
#include "native_static_reference.cpp"
#undef main
#include "z4c/hyperboloidal/composite_regrid.hpp"
int main(int argc,char **argv){Kokkos::initialize(argc,argv);int code=0;try{
 if(argc!=9)throw std::invalid_argument("adaptive reference initialmesh rk dt prefix refinedmesh coarsenedmesh amplitude angular");
 std::ifstream receipt(argv[2]);std::string magic;h::NativeCompositeRK rk;receipt>>magic>>rk.integrator>>rk.stages;if(magic!="NATIVE_COMPOSITE_RK_V1")throw std::runtime_error("actual RK receipt");for(auto *a:{&rk.gam0,&rk.gam1,&rk.beta,&rk.delta})for(Real &x:*a)receipt>>x;rk.Validate();
 std::ifstream clock(argv[3]);std::vector<Real>dts;Real dt;while(clock>>dt)dts.push_back(dt);if(dts.size()!=4)throw std::runtime_error("four cycle reference only");
 auto engine=std::make_unique<Engine>(ReadMesh(argv[1]),true,1e-11,4,true,false,0,6,true,0,.24,false,true,true);engine->Initialize(std::stod(argv[7]),std::stoi(argv[8])!=0);State stage({engine->state,engine->scri->values,{}},engine->beta_delta.size());
 auto load=[&]{engine->state=stage.Coefficients().volume;engine->scri->values=stage.Coefficients().scri;engine->beta_delta=stage.ShiftWarmStart();};
 auto solve=[&]{load();engine->RHS(engine->state,0);stage.InstallShift(stage.CurrentEpoch(),engine->beta_delta);};
 auto write=[&](const std::string &prefix,size_t cycle){std::ostringstream number;number<<std::setw(5)<<std::setfill('0')<<cycle;std::ofstream out(prefix+"."+number.str()+".csv");out<<std::setprecision(17)<<"x,y,z";for(int f=0;f<22;++f)out<<",state_"<<f;for(int a=0;a<3;++a)out<<",delta_beta_"<<a;out<<'\n';
  for(size_t p=0;p<engine->shift.grid.active.size();++p){const auto &x=engine->shift.grid.geometry[p].x;out<<x[0]<<','<<x[1]<<','<<x[2];for(int f=0;f<22;++f)out<<','<<engine->state[22*p+f];for(int a=0;a<3;++a)out<<','<<engine->beta_delta[3*p+a];out<<'\n';}
  std::ofstream surface(prefix+"."+number.str()+".scri.csv");surface<<std::setprecision(17)<<"x,y,z";for(int f=0;f<22;++f)surface<<",state_"<<f;for(int a=0;a<3;++a)surface<<",delta_beta_"<<a;surface<<'\n';for(size_t p=0;p<engine->scri->rows.size();++p){const auto &x=engine->scri->rows[p].geometry.x;surface<<x[0]<<','<<x[1]<<','<<x[2];for(int f=0;f<22;++f)surface<<','<<engine->scri->values[22*p+f];for(int a=0;a<3;++a)surface<<','<<engine->scri->beta[3*p+a];surface<<'\n';}
  std::ofstream shift(prefix+"."+number.str()+".shift.bin",std::ios::binary);const uint64_t count=engine->beta_delta.size();shift.write(reinterpret_cast<const char*>(&count),8);shift.write(reinterpret_cast<const char*>(engine->beta_delta.data()),8*count);
  if(!out||!surface||!shift)throw std::runtime_error("adaptive reference write");};
 solve();write(argv[4],0);Real time=0;for(size_t cycle=1;cycle<=4;++cycle){stage.BeginCycle(rk,dts[cycle-1],time);for(int s=1;s<=rk.stages;++s){const auto epoch=stage.BeginStage(s);load();State::Values rate{engine->RHS(engine->state,dts[cycle-1]),engine->boundary_rhs,{}};stage.InstallShift(epoch,engine->beta_delta);stage.AdvanceStage(epoch,rate);load();if(!stage.Active())solve();}time+=dts[cycle-1];write(argv[4],cycle);
  if(cycle==1||cycle==3){auto mesh=ReadMesh(cycle==1?argv[5]:argv[6]);mesh.revision=engine->shift.grid.mesh.revision+1;auto rebuilt=h::RebuildCompositeAtAcceptedState(*engine,std::move(mesh));engine=std::move(rebuilt.engine);engine->RHS(engine->state,0);stage.ReplaceAcceptedState({engine->state,engine->scri->values,{}},engine->beta_delta,stage.GeometryMetadata());stage.InstallShift(stage.CurrentEpoch(),engine->beta_delta);write(std::string(argv[4])+".regrid-"+(cycle==1?"1":"2"),cycle);}
 }
 std::cout<<"{\"actual_native_RK_topology_receipts\":true,\"cycles\":4,\"regrids\":2,\"qualification\":\"same-engine recurrence/transaction control only\"}\n";
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';code=1;}Kokkos::finalize();return code;}
