// Copyright(C) 2026 AthenaK contributors. BSD-3-Clause; see LICENSE.
// Read-only pole localization: no time advance, shift solve, projection or BC change.
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include "mesh/cubed_sphere/composite_checkpoint.hpp"
#include "mesh/cubed_sphere/scri_surface.hpp"
#include "z4c/hyperboloidal/composite_state.hpp"
#include "z4c/hyperboloidal/tensor_scri.hpp"
#include "z4c/hyperboloidal/elliptic_shift.hpp"
namespace h=z4c::hyperboloidal;
using V=std::vector<Real>;
h::OmegaJet<Real> Omega(const Real *x,const h::Z4cJet<Real>&u){h::OmegaJet<Real> o{};for(int a=0;a<3;++a){o.gradient[a]=-x[a];o.hessian[a][a]=-1;}h::SetStationaryOmegaNormal(u.alpha.value,u.beta.value,u.alpha.d,u.beta.d,o);return o;}
std::array<Real,13> Poles(const h::Z4cJet<Real>&u,const Real*x){const Real b[3]={-x[0],-x[1],-x[2]};auto p=h::TensorPoleSources(u,Omega(x,u),Real(1),b,Real(4),Real(-.99),Real(1),Real(1),true,true);std::array<Real,13> out{p.geometry.chi,p.geometry.trace,p.geometry.theta,p.lapse};for(int t=0;t<6;++t)out[4+t]=p.geometry.a[h::kCompositeTensorI[t]][h::kCompositeTensorJ[t]];for(int i=0;i<3;++i)out[10+i]=p.geometry.lambda[i];return out;}
int main(int argc,char**argv){Kokkos::initialize(argc,argv);int code=0;try{
 if(argc!=5)throw std::runtime_error("checkpoint source_tag initial.dat output.csv");auto snap=cubed_sphere::CompositeCheckpoint::Read(argv[1],argv[2]);cubed_sphere::CompositeDifference g(snap.mesh,4,snap.radial_interface_stencils);if(g.active.size()>50000||g.n!=6)throw std::runtime_error("bounded N6 <=50000");
 V initial(g.active.size()*22,0);std::ifstream f(argv[3]);std::string magic;size_t size;f>>magic>>size;if(magic!="ISOTROPIC_M1_3"||size!=g.active.size())throw std::runtime_error("initial mismatch");
 for(size_t p=0;p<size;++p){Real r,chi,alpha,a,k;f>>r>>chi>>alpha>>a>>k;const auto &x=g.geometry[p].x;if(!f||std::abs(r-std::sqrt(x[0]*x[0]+x[1]*x[1]+x[2]*x[2]))>1e-13)throw std::runtime_error("initial geometry mismatch");initial[22*p]=std::log(chi);initial[22*p+18]=std::log(alpha/((1+r*r)/2));initial[22*p+13]=3+k;for(int t=0;t<6;++t){int i=h::kCompositeTensorI[t],j=h::kCompositeTensorJ[t];initial[22*p+7+t]=1.5*a*(x[i]*x[j]/(r*r)-(i==j?1./3:0));}}
 std::ofstream out(argv[4]);out<<std::setprecision(17)<<"state,nodes,row,face,j,k,x,y,z,chi,alpha,Khat,Theta,chi_dn,chi_dt_norm,metric_d_norm";const char*names[]={"chi","Khat","Theta","alpha","Axx","Axy","Axz","Ayy","Ayz","Azz","LambdaX","LambdaY","LambdaZ"};const char*modes[]={"full","chi_no_derivative","chi_radial_derivative","metric_no_derivative","trace_no_derivative","oracle_initial_first_jet"};for(auto m:modes)for(auto n:names)out<<','<<m<<'_'<<n;out<<'\n';
 Real helper_agreement=0;size_t ghost_terms=0;
 for(int state=0;state<2;++state){const auto &data=state?snap.fields:initial;V padded(22*g.count,0);for(size_t p=0;p<g.active.size();++p)for(int v=0;v<22;++v)padded[v*g.count+g.active[p]]=data[22*p+v];
 for(int nodes:{6,7}){cubed_sphere::ScriSurface surface(g,22,nodes);V boundary=state?snap.boundary_fields:V(surface.values.size(),0);
 for(size_t p=0;p<surface.rows.size();++p){const auto &row=surface.rows[p];for(const auto&t:row.terms)if(!t.boundary){int i=t.point%g.padded-g.ng,j=t.point/g.padded%g.padded-g.ng,k=t.point/(g.padded*g.padded)%g.padded-g.ng;if(i<0||i>=g.n||j<0||j>=g.n||k<0||k>=g.n)++ghost_terms;}
 auto sample=surface.Sample(p,padded,boundary,22);const auto &x=row.geometry.x;auto u=h::UnpackComposite(x,sample.value,sample.d,sample.dd,true,0,2);Real beta[3];if(!h::FixedAngleScriShift(h::Geometry(u.metric),Real(1),u.chi.value,x,beta))throw std::runtime_error("null datum failed");for(int i=0;i<3;++i)u.beta.value[i]=beta[i];auto original=Poles(u,x);auto parts=h::ConformalRHS(u,Omega(x,u),Real(4),Real(-.99),true);helper_agreement=std::max(helper_agreement,std::abs(original[4]-parts.pole.a[0][0]));
 Real dn=0,dt=0,md=0;for(int i=0;i<3;++i)dn+=x[i]*u.chi.d[i];for(int i=0;i<3;++i){dt+=std::pow(u.chi.d[i]-x[i]*dn,2);for(int j=0;j<3;++j)for(int a=0;a<3;++a)md+=u.metric.dg[a][i][j]*u.metric.dg[a][i][j];}
 out<<state<<','<<nodes<<','<<p<<','<<g.mesh.blocks[row.block].face<<','<<row.j<<','<<row.k<<','<<x[0]<<','<<x[1]<<','<<x[2]<<','<<u.chi.value<<','<<u.alpha.value<<','<<u.trace.value<<','<<u.theta.value<<','<<dn<<','<<std::sqrt(dt)<<','<<std::sqrt(md);
 for(int mode=0;mode<6;++mode){auto v=u;if(mode==1)for(auto &a:v.chi.d)a=0;if(mode==2)for(int i=0;i<3;++i)v.chi.d[i]=x[i]*dn;if(mode==3)for(auto &a:v.metric.dg)for(auto &b:a)for(auto &c:b)c=0;if(mode==4)for(int i=0;i<3;++i){v.trace.d[i]=0;v.theta.d[i]=0;}if(mode==5){for(int i=0;i<3;++i){v.chi.d[i]=0;v.trace.d[i]=0;v.theta.d[i]=0;for(int j=0;j<3;++j)for(int a=0;a<3;++a)v.metric.dg[a][i][j]=0;}}for(auto value:Poles(v,x))out<<','<<value;}out<<'\n';
 }}}
 std::cout<<std::setprecision(17)<<"{\"cells\":"<<g.active.size()<<",\"checkpoint_time\":"<<snap.step*snap.dt<<",\"surface_rows\":216,\"ghost_terms\":"<<ghost_terms<<",\"pole_helper_Axx_agreement\":"<<helper_agreement<<",\"no_solve\":true,\"no_evolution\":true}\n";if(ghost_terms||helper_agreement>1e-12)throw std::runtime_error("local diagnostic consistency failed");
 }catch(const std::exception&e){std::cerr<<e.what()<<'\n';code=2;}Kokkos::finalize();return code;}
